# Plan — Solar + Strategic Oil Supply Intelligence Application

## Interpretation
The user wants to expand their data/services scope from "strategic oil supply" to also cover solar energy, and needs an application demonstrating where they would be needed (i.e., a product that showcases the value of their data/services across both oil and solar energy domains). Brand context: wealthyexpress ($WEX) from prior project memory — will keep branding neutral-but-extensible.

## Deliverable
A polished web application: **"Energy Intelligence Platform"** covering:
- Strategic oil supply data/services (reserves, supply chains, pricing, risk)
- Solar energy data/services (capacity, generation, project pipeline, integration with oil supply strategy)
- A "Where We're Needed" section mapping service opportunities at the oil↔solar intersection (transition analytics, hybrid infrastructure, data provision)

## Stage 1 — Skill loading & architecture
- Load `vibecoding-webapp-swarm` (orchestration) and follow its workflow.
- Determine workspace setup (swarm-workspace) and whether subagents are required per skill rules.

## Stage 2 — Design
- Define visual direction per skill guidance: low-saturation, warm, ample whitespace, clear hierarchy.
- App structure: Dashboard (oil + solar KPIs), Oil Supply module, Solar Energy module, Services/Opportunity map, About.

## Stage 3 — Build
- Implement React + TypeScript + Tailwind + shadcn/ui app with realistic sample data (clearly labeled), charts, and service-offering pages.

## Stage 4 — Validate & Deliver
- Build the project, verify it compiles and renders.
- Save website version via `website_version_manager` (build_version) for preview.

## Sub-agent assignments
- Per vibecoding-webapp-swarm guidance: design agent → build agent(s) → verify. Adjust after reading the skill.
