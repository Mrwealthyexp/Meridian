import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
} from "drizzle-orm/mysql-core";

// Meridian Energy Intelligence — form submissions

export const accessRequests = mysqlTable("access_requests", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  organization: varchar("organization", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  interest: varchar("interest", { length: 64 }).notNull(),
  message: text("message"),
  refCode: varchar("ref_code", { length: 32 }).notNull().unique(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const newsletterSubscribers = mysqlTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  source: varchar("source", { length: 32 }).notNull().default("footer"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type AccessRequest = typeof accessRequests.$inferSelect;
export type InsertAccessRequest = typeof accessRequests.$inferInsert;
export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;
