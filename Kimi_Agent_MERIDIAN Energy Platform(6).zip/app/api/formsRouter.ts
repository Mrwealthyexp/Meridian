import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { createAccessRequest, createNewsletterSubscriber } from "./queries/forms";

export const formsRouter = createRouter({
  submitAccessRequest: publicQuery
    .input(
      z.object({
        name: z.string().min(2, "Name is required").max(255),
        organization: z.string().min(2, "Organization is required").max(255),
        email: z.string().email("A valid email is required").max(320),
        interest: z.string().min(1).max(64),
        message: z.string().max(5000).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const refCode = `MER-${new Date().getFullYear()}-${Math.floor(
        1000 + Math.random() * 9000,
      )}`;
      await createAccessRequest({ ...input, refCode });
      return { ok: true, refCode };
    }),

  subscribe: publicQuery
    .input(
      z.object({
        email: z.string().email("A valid email is required").max(320),
        source: z.string().max(32).default("footer"),
      }),
    )
    .mutation(async ({ input }) => {
      await createNewsletterSubscriber(input);
      return { ok: true };
    }),
});
