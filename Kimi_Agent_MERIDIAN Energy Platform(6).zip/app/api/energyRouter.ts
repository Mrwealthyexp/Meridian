import { createRouter, publicQuery } from "./middleware";

/**
 * Live benchmark quotes fetched server-side from stooq.com's free public
 * CSV endpoint (no API key required). Results are cached in-memory for 60s.
 * If the upstream fetch fails, the affected quote is returned as null and the
 * frontend keeps displaying its canonical sample figure — the UI never breaks.
 */

type Quote = {
  symbol: string;
  label: string;
  price: number;
  changePct: number;
  asOf: string; // ISO timestamp of the upstream quote
};

const SYMBOLS: { symbol: string; label: string }[] = [
  { symbol: "cl.f", label: "WTI" }, // NYMEX WTI crude front-month future
  { symbol: "cb.f", label: "BRENT" }, // ICE Brent crude front-month future
];

let cache: { at: number; quotes: (Quote | null)[] } | null = null;
const CACHE_TTL_MS = 60_000;

async function fetchQuote(symbol: string, label: string): Promise<Quote | null> {
  try {
    const url = `https://stooq.com/q/l/?s=${encodeURIComponent(symbol)}&f=sd2t2ohlcv&h&e=csv`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const text = await res.text();
    // CSV header: Symbol,Date,Time,Open,High,Low,Close,Volume
    const lines = text.trim().split("\n");
    if (lines.length < 2) return null;
    const cols = lines[1].split(",");
    const close = Number(cols[6]);
    const open = Number(cols[3]);
    if (!Number.isFinite(close) || close <= 0) return null;
    const changePct =
      Number.isFinite(open) && open > 0 ? ((close - open) / open) * 100 : 0;
    const date = cols[1];
    const time = cols[2];
    return {
      symbol,
      label,
      price: Math.round(close * 100) / 100,
      changePct: Math.round(changePct * 100) / 100,
      asOf: new Date(`${date}T${time}Z`).toISOString(),
    };
  } catch {
    return null;
  }
}

export const energyRouter = createRouter({
  quotes: publicQuery.query(async () => {
    const now = Date.now();
    if (cache && now - cache.at < CACHE_TTL_MS) {
      return { quotes: cache.quotes, cached: true, live: true };
    }
    const quotes = await Promise.all(
      SYMBOLS.map((s) => fetchQuote(s.symbol, s.label)),
    );
    cache = { at: now, quotes };
    return {
      quotes,
      cached: false,
      live: quotes.some((q) => q !== null),
    };
  }),
});
