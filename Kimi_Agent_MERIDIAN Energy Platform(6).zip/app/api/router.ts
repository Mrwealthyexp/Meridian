import { createRouter, publicQuery } from "./middleware";
import { formsRouter } from "./formsRouter";
import { energyRouter } from "./energyRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  forms: formsRouter,
  energy: energyRouter,
});

export type AppRouter = typeof appRouter;
