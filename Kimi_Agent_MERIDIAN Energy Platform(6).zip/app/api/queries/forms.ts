import { getDb } from "./connection";
import { accessRequests, newsletterSubscribers } from "@db/schema";

export async function createAccessRequest(data: {
  name: string;
  organization: string;
  email: string;
  interest: string;
  message?: string;
  refCode: string;
}) {
  await getDb().insert(accessRequests).values(data);
}

export async function createNewsletterSubscriber(data: {
  email: string;
  source: string;
}) {
  // Upsert: subscribing twice with the same email just updates the source
  await getDb()
    .insert(newsletterSubscribers)
    .values(data)
    .onDuplicateKeyUpdate({ set: { source: data.source } });
}
