import { format } from 'date-fns'

/* ------------------------------------------------------------------ */
/* Regions & ranges                                                    */
/* ------------------------------------------------------------------ */

export type RegionKey = 'global' | 'na' | 'me' | 'eu' | 'ap'

export const REGIONS: { key: RegionKey; label: string }[] = [
  { key: 'global', label: 'Global' },
  { key: 'na', label: 'North America' },
  { key: 'me', label: 'Middle East' },
  { key: 'eu', label: 'Europe' },
  { key: 'ap', label: 'Asia-Pacific' },
]

export type RangeKey = '1M' | '6M' | '1Y' | '5Y'

export const RANGES: { key: RangeKey; points: number }[] = [
  { key: '1M', points: 4 },
  { key: '6M', points: 26 },
  { key: '1Y', points: 52 },
  { key: '5Y', points: 260 },
]

/* ------------------------------------------------------------------ */
/* Deterministic PRNG (mulberry32) so sample data is stable per seed   */
/* ------------------------------------------------------------------ */

export function mulberry32(seed: number) {
  let a = seed >>> 0
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const REGION_SEED: Record<RegionKey, number> = { global: 11, na: 23, me: 37, eu: 53, ap: 71 }

/** Approximate share of the global total each region represents. */
const SUPPLY_FACTOR: Record<RegionKey, number> = { global: 1, na: 0.27, me: 0.46, eu: 0.13, ap: 0.38 }
const SOLAR_FACTOR: Record<RegionKey, number> = { global: 1, na: 0.18, me: 0.06, eu: 0.14, ap: 0.55 }

/* ------------------------------------------------------------------ */
/* Weekly series (260 weeks ending Sep 2025)                           */
/* ------------------------------------------------------------------ */

export interface WeeklyPoint {
  label: string
  opec: number
  nonOpec: number
  solar: number
  oil: number
  gas: number
  solarShare: number
  wind: number
  other: number
}

const SERIES_WEEKS = 260
const SERIES_END = new Date(2025, 8, 26)

export function getSeries(region: RegionKey, jitter: number): WeeklyPoint[] {
  const rand = mulberry32(REGION_SEED[region] * 100003 + jitter * 7919 + 5)
  const sf = SUPPLY_FACTOR[region]
  const pv = SOLAR_FACTOR[region]
  const points: WeeklyPoint[] = []

  for (let i = 0; i < SERIES_WEEKS; i++) {
    const t = i / (SERIES_WEEKS - 1)
    const date = new Date(SERIES_END.getTime() - (SERIES_WEEKS - 1 - i) * 7 * 86400000)

    const opec = 41.2 * sf * (0.94 + 0.1 * t + (rand() - 0.5) * 0.05)
    const nonOpec = 60.4 * sf * (0.86 + 0.18 * t + (rand() - 0.5) * 0.04)
    const solar = 152 * pv * (0.32 + 0.95 * Math.pow(t, 1.35) + (rand() - 0.5) * 0.05)

    // 100% mix shares
    const oilS = Math.max(20, 33.5 - 6 * t + (rand() - 0.5) * 1.2)
    const gasS = 22.4 - 1.2 * t + (rand() - 0.5) * 0.8
    const solarS = 8.6 + 13.5 * t + (rand() - 0.5) * 0.8
    const windS = 11.4 + 3.4 * t + (rand() - 0.5) * 0.6
    const otherS = Math.max(2, 100 - oilS - gasS - solarS - windS)

    points.push({
      label: format(date, 'MMM yy'),
      opec: +opec.toFixed(1),
      nonOpec: +nonOpec.toFixed(1),
      solar: +solar.toFixed(1),
      oil: +oilS.toFixed(1),
      gas: +gasS.toFixed(1),
      solarShare: +solarS.toFixed(1),
      wind: +windS.toFixed(1),
      other: +otherS.toFixed(1),
    })
  }
  return points
}

export function sliceForRange(series: WeeklyPoint[], range: RangeKey): WeeklyPoint[] {
  const n = RANGES.find((r) => r.key === range)?.points ?? 52
  return series.slice(-n)
}

/* ------------------------------------------------------------------ */
/* KPI band                                                            */
/* ------------------------------------------------------------------ */

export interface KpiDef {
  id: string
  label: string
  base: number
  prefix: string
  suffix: string
  decimals: number
  delta: string
  direction: 'up' | 'down'
  sparkColor: string
  domain: 'oil' | 'solar'
  seed: number
}

export const KPIS: KpiDef[] = [
  { id: 'wti', label: 'WTI Crude', base: 78.42, prefix: '$', suffix: '', decimals: 2, delta: '0.8%', direction: 'up', sparkColor: '#0E5A50', domain: 'oil', seed: 101 },
  { id: 'brent', label: 'Brent', base: 82.11, prefix: '$', suffix: '', decimals: 2, delta: '0.3%', direction: 'down', sparkColor: '#0E5A50', domain: 'oil', seed: 103 },
  { id: 'spr', label: 'US SPR', base: 372, prefix: '', suffix: 'M BBL', decimals: 0, delta: '0.4% WK', direction: 'up', sparkColor: '#9A6A33', domain: 'oil', seed: 107 },
  { id: 'pvcap', label: 'Global PV Capacity', base: 1610, prefix: '', suffix: ' GW', decimals: 0, delta: '24% YOY', direction: 'up', sparkColor: '#E9A319', domain: 'solar', seed: 109 },
  { id: 'pipeline', label: 'PV Pipeline', base: 612, prefix: '', suffix: ' GW', decimals: 0, delta: '9% QOQ', direction: 'up', sparkColor: '#E9A319', domain: 'solar', seed: 113 },
  { id: 'pvx', label: 'Meridian PV Index', base: 142.6, prefix: '', suffix: '', decimals: 1, delta: '1.9%', direction: 'up', sparkColor: '#B57309', domain: 'solar', seed: 127 },
]

/** Region-scoped KPI value: base perturbed ±3% per region, ±0.4% per refresh. */
export function kpiValue(def: KpiDef, region: RegionKey, jitter: number): number {
  const rand = mulberry32(def.seed * 131 + REGION_SEED[region] * 17 + 7)
  const regionFactor = region === 'global' ? 1 : 0.97 + rand() * 0.06
  const j = jitter === 0 ? 1 : 1 + (rand() - 0.5) * 0.008 * Math.min(jitter, 5)
  return def.base * regionFactor * j
}

/** 20-point sparkline series, deterministic per KPI/region/jitter. */
export function kpiSpark(def: KpiDef, region: RegionKey, jitter: number): number[] {
  const rand = mulberry32(def.seed * 733 + REGION_SEED[region] * 29 + jitter * 41 + 3)
  const pts: number[] = []
  let v = 0.55
  for (let i = 0; i < 20; i++) {
    v += (rand() - 0.46) * 0.14
    v = Math.min(0.98, Math.max(0.08, v))
    pts.push(v)
  }
  return pts
}

/* ------------------------------------------------------------------ */
/* Stress gauge                                                        */
/* ------------------------------------------------------------------ */

export const GAUGE_VALUE = 72

export const SUB_METERS = [
  { label: 'Chokepoint Risk', value: 38, color: '#C2462B' },
  { label: 'Reserve Adequacy', value: 81, color: '#2E7D4F' },
  { label: 'Solar Ramp Readiness', value: 64, color: '#E9A319' },
  { label: 'Grid Flexibility', value: 57, color: '#0E5A50' },
] as const

/* ------------------------------------------------------------------ */
/* Hotspots (positions on the 2000×1000 world-dots viewBox)            */
/* ------------------------------------------------------------------ */

export interface Hotspot {
  id: string
  name: string
  x: number
  y: number
  domain: 'oil' | 'solar'
  region: RegionKey
  stats: [string, string]
}

export const HOTSPOTS: Hotspot[] = [
  { id: 'gulf', name: 'Gulf Coast, US', x: 500, y: 345, domain: 'oil', region: 'na', stats: ['SPR 372M BBL · 52% CAP', 'REFINING 9.8M BBL/D'] },
  { id: 'hormuz', name: 'Strait of Hormuz', x: 1314, y: 353, domain: 'oil', region: 'me', stats: ['17.3M BBL/D TRANSIT', 'RISK: ELEVATED'] },
  { id: 'rotterdam', name: 'Rotterdam, NL', x: 1025, y: 218, domain: 'oil', region: 'eu', stats: ['ARA STOCKS 54.1M BBL', 'HUB UTILIZATION 88%'] },
  { id: 'singapore', name: 'Singapore', x: 1578, y: 495, domain: 'oil', region: 'ap', stats: ['BUNKER HUB 4.2M T/MO', 'STORAGE 93% FULL'] },
  { id: 'ningxia', name: 'Ningxia, CN', x: 1589, y: 292, domain: 'solar', region: 'ap', stats: ['PV PIPELINE 38.4 GW', 'IRRADIANCE 1,890 KWH/M²'] },
  { id: 'gujarat', name: 'Gujarat, IN', x: 1398, y: 375, domain: 'solar', region: 'ap', stats: ['TENDER 4.5 GW HYBRID', 'CAPACITY ▲31% YOY'] },
  { id: 'atacama', name: 'Atacama, CL', x: 640, y: 630, domain: 'solar', region: 'na', stats: ['IRRADIANCE 2,500 KWH/M²', 'PIPELINE 6.1 GW'] },
  { id: 'bavaria', name: 'Bavaria, DE', x: 1064, y: 232, domain: 'solar', region: 'eu', stats: ['ROOFTOP PV 14.2 GW', 'GRID FLEX ▲ RECORD'] },
]

/* ------------------------------------------------------------------ */
/* Watchlist                                                           */
/* ------------------------------------------------------------------ */

export interface WatchRow {
  symbol: string
  name: string
  last: number
  decimals: number
  delta: number
  spark: number[]
  series: { label: string; v: number }[]
  seed: number
}

function sparkSeries(rand: () => number, n: number, drift: number): number[] {
  const pts: number[] = []
  let v = 0.5
  for (let i = 0; i < n; i++) {
    v += (rand() - 0.5 + drift) * 0.12
    v = Math.min(0.97, Math.max(0.06, v))
    pts.push(v)
  }
  return pts
}

export function makeWatchRow(symbol: string, name: string, last: number, decimals: number, delta: number, seed: number): WatchRow {
  const rand = mulberry32(seed * 9377 + 13)
  const series: { label: string; v: number }[] = []
  let v = last * (0.9 + rand() * 0.06)
  for (let i = 0; i < 60; i++) {
    v += last * (rand() - 0.485) * 0.012
    series.push({
      label: format(new Date(SERIES_END.getTime() - (59 - i) * 86400000), 'd MMM'),
      v: +v.toFixed(decimals),
    })
  }
  return { symbol, name, last, decimals, delta, spark: sparkSeries(rand, 16, delta > 0 ? 0.03 : -0.03), series, seed }
}

export const WATCHLIST_SEED: WatchRow[] = [
  makeWatchRow('WTI', 'WTI Crude', 78.42, 2, 0.8, 201),
  makeWatchRow('BRENT', 'Brent Crude', 82.11, 2, -0.3, 203),
  makeWatchRow('DUBAI', 'Dubai Crude', 80.64, 2, 0.4, 207),
  makeWatchRow('PVX', 'Meridian PV Index', 142.6, 1, 1.9, 211),
  makeWatchRow('POLY-SI', 'Polysilicon $/kg', 8.9, 2, -2.1, 213),
  makeWatchRow('TTF GAS', 'TTF Nat Gas €/MWh', 34.18, 2, 1.2, 217),
]

/** Deterministic row for a user-added symbol. */
export function rowFromSymbol(raw: string): WatchRow {
  const symbol = raw.toUpperCase().replace(/[^A-Z0-9.\-]/g, '').slice(0, 10)
  let hash = 0
  for (const ch of symbol) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0
  const rand = mulberry32(hash + 1)
  const last = +(8 + rand() * 180).toFixed(2)
  const delta = +((rand() - 0.45) * 6).toFixed(1)
  return makeWatchRow(symbol, `${symbol} · User added`, last, 2, delta, (hash % 1000) + 501)
}

/* ------------------------------------------------------------------ */
/* Alerts feed                                                         */
/* ------------------------------------------------------------------ */

export interface AlertItem {
  time: string
  headline: string
  tag: 'OIL' | 'SOLAR' | 'GRID'
  dot: string
}

export const ALERTS: AlertItem[] = [
  { time: '09:12 UTC', headline: 'SPR tender announced — 3.2M bbl solicitation, delivery Q4', tag: 'OIL', dot: '#0E5A50' },
  { time: '08:47 UTC', headline: 'Gujarat tenders 4.5 GW solar + storage hybrid', tag: 'SOLAR', dot: '#E9A319' },
  { time: '08:20 UTC', headline: 'Hormuz transit risk upgraded to ELEVATED', tag: 'OIL', dot: '#C2462B' },
  { time: '07:55 UTC', headline: 'Polysilicon spot falls 2.1% on inventory build', tag: 'SOLAR', dot: '#E9A319' },
  { time: '07:31 UTC', headline: 'European grid flexibility index hits record', tag: 'GRID', dot: '#0E5A50' },
]

/* ------------------------------------------------------------------ */
/* Shared chart chrome                                                 */
/* ------------------------------------------------------------------ */

export const CHART_TOOLTIP_STYLE = {
  background: '#FCFAF5',
  border: '1px solid #E2DACB',
  borderRadius: 10,
  fontFamily: "'IBM Plex Mono', ui-monospace, monospace",
  fontSize: 12,
  color: '#171410',
  boxShadow: '0 8px 24px -12px rgba(23,20,16,0.25)',
} as const

export const AXIS_TICK = {
  fontFamily: "'IBM Plex Mono', ui-monospace, monospace",
  fontSize: 11,
  fill: '#6E675B',
} as const
