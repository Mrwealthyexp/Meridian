import { useEffect, useMemo, useState } from 'react'
import { cn } from '@/lib/utils'
import { useCountUp, useInView } from '@/lib/animation'
import { DomainBadge, DeltaChip } from '@/components/badges'
import { kpiSpark, kpiValue } from '@/components/dashboard/data'
import type { KpiDef, RegionKey } from '@/components/dashboard/data'

const nf = (decimals: number) =>
  new Intl.NumberFormat('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })

/** Sparkline path from normalized 0..1 points, viewBox 100×32. */
function sparkPath(points: number[]): string {
  const w = 100
  const h = 32
  const step = w / (points.length - 1)
  return points
    .map((p, i) => `${i === 0 ? 'M' : 'L'}${(i * step).toFixed(1)},${(h - p * h).toFixed(1)}`)
    .join(' ')
}

function Sparkline({ points, color, active, delay }: { points: number[]; color: string; active: boolean; delay: number }) {
  const d = useMemo(() => sparkPath(points), [points])
  const LEN = 260
  return (
    <svg viewBox="0 0 100 32" preserveAspectRatio="none" className="h-12 w-full" aria-hidden>
      <path
        d={d}
        fill="none"
        stroke={color}
        strokeWidth={2}
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
        style={{
          strokeDasharray: LEN,
          strokeDashoffset: active ? 0 : LEN,
          transition: `stroke-dashoffset 900ms ease-out ${delay}ms`,
        }}
      />
    </svg>
  )
}

export default function KpiCard({
  def,
  region,
  jitter,
  index,
  bandActive,
}: {
  def: KpiDef
  region: RegionKey
  jitter: number
  index: number
  bandActive: boolean
}) {
  const [ref, inView] = useInView<HTMLDivElement>(0.4)
  const active = bandActive && inView
  const stagger = index * 70

  // Count-up starts 200ms after the card lands
  const [countGo, setCountGo] = useState(false)
  useEffect(() => {
    if (!active) return
    const t = window.setTimeout(() => setCountGo(true), stagger + 200)
    return () => window.clearTimeout(t)
  }, [active, stagger])

  const value = kpiValue(def, region, jitter)
  const counted = useCountUp(value, countGo, 1200)
  const spark = useMemo(() => kpiSpark(def, region, jitter), [def, region, jitter])

  return (
    <div
      ref={ref}
      className={cn(
        'card-lift rounded-xl border border-border bg-card p-5 transition-all duration-[600ms] ease-out',
        active ? 'translate-y-0 opacity-100' : 'translate-y-5 opacity-0',
      )}
      style={{ transitionDelay: `${stagger}ms` }}
    >
      <div className="flex items-start justify-between gap-2">
        <p className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          {def.label}
        </p>
        <DomainBadge domain={def.domain} />
      </div>

      <div className="mt-3 flex items-baseline gap-2">
        <span className="font-mono text-[26px] font-medium leading-[1.1] tracking-[-0.01em] tabular-nums text-foreground xl:text-[24px]">
          {def.prefix}
          {nf(def.decimals).format(counted)}
          {def.suffix && <span className="text-[15px] text-muted-foreground"> {def.suffix.trim()}</span>}
        </span>
      </div>
      <div className="mt-1.5">
        <DeltaChip value={def.delta} direction={def.direction} />
      </div>

      <div className="mt-3">
        <Sparkline points={spark} color={def.sparkColor} active={active} delay={stagger + 150} />
      </div>
    </div>
  )
}
