import { useEffect, useMemo, useState } from 'react'
import { cn } from '@/lib/utils'
import { useInView } from '@/lib/animation'
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card'
import { HOTSPOTS } from '@/components/dashboard/data'
import type { RegionKey } from '@/components/dashboard/data'

interface Dot {
  x: number
  y: number
  r: number
}

/** Parse circle coordinates out of the generated world-dots.svg asset. */
function parseDots(svgText: string): Dot[] {
  const dots: Dot[] = []
  const re = /<circle\s+cx="([\d.]+)"\s+cy="([\d.]+)"\s+r="([\d.]+)"/g
  let m: RegExpExecArray | null
  while ((m = re.exec(svgText)) !== null) {
    dots.push({ x: parseFloat(m[1]), y: parseFloat(m[2]), r: parseFloat(m[3]) })
  }
  return dots
}

export default function RegionMap({
  region,
  onSelectRegion,
}: {
  region: RegionKey
  onSelectRegion: (r: RegionKey) => void
}) {
  const [dots, setDots] = useState<Dot[]>([])
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  useEffect(() => {
    let cancelled = false
    fetch('/world-dots.svg')
      .then((res) => res.text())
      .then((text) => {
        if (!cancelled) setDots(parseDots(text))
      })
      .catch(() => undefined)
    return () => {
      cancelled = true
    }
  }, [])

  const visibleHotspots = useMemo(
    () => (region === 'global' ? HOTSPOTS : HOTSPOTS.filter((h) => h.region === region)),
    [region],
  )

  return (
    <div
      ref={ref}
      className={`rounded-xl border border-border bg-card p-6 transition-all duration-700 ease-out ${
        inView ? 'translate-y-0 opacity-100' : 'translate-y-7 opacity-0'
      }`}
    >
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-sans text-lg font-semibold leading-[1.25] text-foreground md:text-[22px]">
          Regional Snapshot
        </h3>
        <span className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          {region === 'global' ? 'Global view' : `Filtered · ${region.toUpperCase()}`}
        </span>
      </div>

      <div className="relative mt-4 overflow-hidden rounded-lg border border-border bg-muted/40">
        <div className="relative aspect-[2/1] w-full">
          {/* Dot-grid map, tinted crude-bronze at 30% alpha */}
          <svg viewBox="0 0 2000 1000" className="absolute inset-0 h-full w-full" aria-hidden>
            {dots.map((d, i) => (
              <circle
                key={i}
                cx={d.x}
                cy={d.y}
                r={d.r}
                fill="#9A6A33"
                opacity={0.3}
                style={{
                  transformBox: 'fill-box',
                  transformOrigin: 'center',
                  transform: inView ? 'scale(1)' : 'scale(0)',
                  transition: 'transform 400ms ease-out',
                  transitionDelay: `${(i % 8) * 55}ms`,
                }}
              />
            ))}
          </svg>

          {/* Hotspots */}
          {HOTSPOTS.map((h, i) => {
            const dimmed = region !== 'global' && h.region !== region
            const selected = region !== 'global' && h.region === region
            const color = h.domain === 'oil' ? '#0E5A50' : '#E9A319'
            return (
              <HoverCard key={h.id} openDelay={120} closeDelay={80}>
                <HoverCardTrigger asChild>
                  <button
                    type="button"
                    aria-label={`${h.name} — filter map to region`}
                    onClick={() => onSelectRegion(h.region)}
                    className={cn(
                      'group absolute z-10 flex h-8 w-8 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full transition-opacity duration-300',
                      dimmed && 'pointer-events-none opacity-20',
                    )}
                    style={{ left: `${(h.x / 2000) * 100}%`, top: `${(h.y / 1000) * 100}%` }}
                  >
                    {/* pulse ring (transform/opacity only) */}
                    <span
                      aria-hidden
                      className="absolute inset-0 animate-pulse-ring rounded-full"
                      style={{ backgroundColor: color, opacity: 0.3, animationDelay: `${i * 0.3}s` }}
                    />
                    {/* persistent ring when this hotspot's region is selected */}
                    {selected && (
                      <span
                        aria-hidden
                        className="absolute inset-[3px] rounded-full border-2"
                        style={{ borderColor: color }}
                      />
                    )}
                    <span
                      className="relative h-2.5 w-2.5 rounded-full transition-transform duration-200 group-hover:scale-125"
                      style={{ backgroundColor: color }}
                    />
                  </button>
                </HoverCardTrigger>
                <HoverCardContent side="top" className="w-56 rounded-lg border-border bg-card p-3">
                  <p className="font-sans text-sm font-semibold text-foreground">{h.name}</p>
                  <div className="mt-2 space-y-1">
                    {h.stats.map((s) => (
                      <p key={s} className="font-mono text-[10px] font-medium uppercase tracking-[0.1em] text-muted-foreground">
                        {s}
                      </p>
                    ))}
                  </div>
                  <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground/70">
                    Click to filter dashboard
                  </p>
                </HoverCardContent>
              </HoverCard>
            )
          })}

          {/* Legend overlay */}
          <div className="absolute left-3 top-3 rounded-md border border-border bg-card/85 px-3 py-2 backdrop-blur-sm">
            {visibleHotspots.length === 0 ? (
              <p className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                No hotspots in filter
              </p>
            ) : (
              <div className="space-y-1.5">
                <p className="flex items-center gap-2 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                  <span className="h-2 w-2 rounded-full bg-oil" /> Oil critical
                </p>
                <p className="flex items-center gap-2 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                  <span className="h-2 w-2 rounded-full bg-solar" /> Solar growth
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      <p className="mt-4 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        8 tracked hotspots · Click a marker to filter · Sample data
      </p>
    </div>
  )
}
