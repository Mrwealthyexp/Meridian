import { useMemo, useState } from 'react'
import type { FormEvent } from 'react'
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ChartLine, Plus, X } from 'lucide-react'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useInView } from '@/lib/animation'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import {
  AXIS_TICK,
  CHART_TOOLTIP_STYLE,
  rowFromSymbol,
  WATCHLIST_SEED,
} from '@/components/dashboard/data'
import type { WatchRow } from '@/components/dashboard/data'

/** 40×16 inline sparkline for table cells. */
function MiniSpark({ points, positive }: { points: number[]; positive: boolean }) {
  const d = useMemo(() => {
    const step = 40 / (points.length - 1)
    return points
      .map((p, i) => `${i === 0 ? 'M' : 'L'}${(i * step).toFixed(1)},${(16 - p * 16).toFixed(1)}`)
      .join(' ')
  }, [points])
  return (
    <svg viewBox="0 0 40 16" className="h-4 w-10" aria-hidden>
      <path
        d={d}
        fill="none"
        stroke={positive ? '#2E7D4F' : '#C2462B'}
        strokeWidth={1.5}
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  )
}

export default function Watchlist() {
  const [rows, setRows] = useState<WatchRow[]>(WATCHLIST_SEED)
  const [addOpen, setAddOpen] = useState(false)
  const [symbol, setSymbol] = useState('')
  const [selected, setSelected] = useState<WatchRow | null>(null)
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  const addSymbol = (e: FormEvent) => {
    e.preventDefault()
    const raw = symbol.trim()
    if (!raw) return
    const row = rowFromSymbol(raw)
    if (rows.some((r) => r.symbol === row.symbol)) {
      toast.error(`${row.symbol} is already tracked.`)
      return
    }
    setRows((prev) => [...prev, row])
    setSymbol('')
    setAddOpen(false)
    toast.success(`${row.symbol} added to watchlist · sample data`)
  }

  const removeRow = (sym: string) => {
    setRows((prev) => prev.filter((r) => r.symbol !== sym))
    if (selected?.symbol === sym) setSelected(null)
  }

  return (
    <div
      ref={ref}
      className={`rounded-xl border border-border bg-card p-6 transition-all duration-700 ease-out ${
        inView ? 'translate-y-0 opacity-100' : 'translate-y-7 opacity-0'
      }`}
      style={{ transitionDelay: '150ms' }}
    >
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-sans text-lg font-semibold leading-[1.25] text-foreground md:text-[22px]">
          Watchlist
        </h3>
        <Popover open={addOpen} onOpenChange={setAddOpen}>
          <PopoverTrigger asChild>
            <button
              type="button"
              className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-background px-3 py-1.5 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-foreground transition-colors hover:border-solar hover:text-solar-deep"
            >
              <Plus className="h-3.5 w-3.5" /> Add symbol
            </button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-64 rounded-lg border-border bg-card p-3">
            <form onSubmit={addSymbol} className="flex gap-2">
              <Input
                autoFocus
                value={symbol}
                onChange={(e) => setSymbol(e.target.value)}
                placeholder="e.g. NG-LNG"
                className="h-9 font-mono text-xs uppercase tracking-[0.08em]"
              />
              <Button type="submit" size="sm" className="h-9 bg-solar font-mono text-[11px] uppercase tracking-[0.1em] text-foreground hover:bg-solar-deep hover:text-white">
                Add
              </Button>
            </form>
            <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
              Client-side only · sample data
            </p>
          </PopoverContent>
        </Popover>
      </div>

      <div className="mt-4">
        {rows.length === 0 ? (
          <Empty className="border border-dashed border-solar/50">
            <EmptyHeader>
              <EmptyMedia variant="icon" className="border border-dashed border-solar/60 bg-solar/10 text-solar-deep">
                <ChartLine />
              </EmptyMedia>
              <EmptyTitle className="font-sans text-base">No symbols tracked.</EmptyTitle>
              <EmptyDescription className="font-mono text-[11px] uppercase tracking-[0.12em]">
                Add your first symbol.
              </EmptyDescription>
            </EmptyHeader>
            <button
              type="button"
              onClick={() => setAddOpen(true)}
              className="inline-flex items-center gap-1.5 rounded-lg bg-solar px-3 py-2 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-foreground transition-colors hover:bg-solar-deep hover:text-white"
            >
              <Plus className="h-3.5 w-3.5" /> Add symbol
            </button>
          </Empty>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Symbol</TableHead>
                <TableHead className="text-right font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Last</TableHead>
                <TableHead className="text-right font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">24h</TableHead>
                <TableHead className="font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Spark</TableHead>
                <TableHead className="w-8" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((row, i) => (
                <TableRow
                  key={row.symbol}
                  onClick={() => setSelected(row)}
                  className={cn(
                    'cursor-pointer border-border transition-all duration-500 hover:bg-muted/50',
                    inView ? 'translate-x-0 opacity-100' : '-translate-x-3 opacity-0',
                  )}
                  style={{ transitionDelay: inView ? `${Math.min(i, 10) * 60}ms` : '0ms' }}
                >
                  <TableCell className="py-2.5">
                    <span className="font-mono text-xs font-semibold tracking-[0.04em] text-foreground">{row.symbol}</span>
                    <span className="block font-mono text-[9px] uppercase tracking-[0.1em] text-muted-foreground">{row.name}</span>
                  </TableCell>
                  <TableCell className="py-2.5 text-right font-mono text-xs tabular-nums text-foreground">
                    {row.last.toFixed(row.decimals)}
                  </TableCell>
                  <TableCell
                    className={cn(
                      'py-2.5 text-right font-mono text-xs tabular-nums',
                      row.delta >= 0 ? 'text-positive' : 'text-critical',
                    )}
                  >
                    {row.delta >= 0 ? '▲' : '▼'} {Math.abs(row.delta).toFixed(1)}%
                  </TableCell>
                  <TableCell className="py-2.5">
                    <MiniSpark points={row.spark} positive={row.delta >= 0} />
                  </TableCell>
                  <TableCell className="py-2.5 pr-1 text-right">
                    <button
                      type="button"
                      aria-label={`Remove ${row.symbol}`}
                      onClick={(e) => {
                        e.stopPropagation()
                        removeRow(row.symbol)
                      }}
                      className="inline-flex h-6 w-6 items-center justify-center rounded-md text-muted-foreground/50 transition-colors hover:bg-critical/10 hover:text-critical"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      {/* Detail drawer */}
      <Sheet open={selected !== null} onOpenChange={(open) => !open && setSelected(null)}>
        <SheetContent side="right" className="w-[420px] max-w-[92vw] overflow-y-auto bg-card sm:max-w-[420px]">
          {selected && (
            <>
              <SheetHeader>
                <SheetTitle className="flex items-baseline gap-3 font-sans text-xl">
                  <span className="font-mono">{selected.symbol}</span>
                  <span
                    className={cn(
                      'font-mono text-sm tabular-nums',
                      selected.delta >= 0 ? 'text-positive' : 'text-critical',
                    )}
                  >
                    {selected.delta >= 0 ? '▲' : '▼'} {Math.abs(selected.delta).toFixed(1)}%
                  </span>
                </SheetTitle>
                <SheetDescription className="font-mono text-[10px] uppercase tracking-[0.14em]">
                  {selected.name} · 60D history
                </SheetDescription>
              </SheetHeader>

              <div className="mt-6 h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={selected.series} margin={{ top: 4, right: 4, bottom: 0, left: -14 }}>
                    <defs>
                      <linearGradient id="watchFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={selected.delta >= 0 ? '#E9A319' : '#C2462B'} stopOpacity={0.4} />
                        <stop offset="100%" stopColor={selected.delta >= 0 ? '#E9A319' : '#C2462B'} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="label" tick={{ ...AXIS_TICK, fontSize: 10 }} tickLine={false} axisLine={{ stroke: '#E2DACB' }} minTickGap={32} />
                    <YAxis tick={{ ...AXIS_TICK, fontSize: 10 }} tickLine={false} axisLine={false} width={56} domain={['auto', 'auto']} />
                    <Tooltip contentStyle={CHART_TOOLTIP_STYLE} cursor={{ stroke: '#E2DACB' }} />
                    <Area
                      dataKey="v"
                      name={selected.symbol}
                      stroke={selected.delta >= 0 ? '#E9A319' : '#C2462B'}
                      strokeWidth={2}
                      fill="url(#watchFill)"
                      isAnimationActive
                      animationDuration={900}
                      animationEasing="ease-out"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-6 divide-y divide-border rounded-lg border border-border">
                {[
                  { label: '24h High', value: (selected.last * 1.014).toFixed(selected.decimals) },
                  { label: '24h Low', value: (selected.last * 0.982).toFixed(selected.decimals) },
                  { label: '30d Volatility', value: `${(4 + (selected.seed % 9)).toFixed(1)}%` },
                ].map((s) => (
                  <div key={s.label} className="flex items-center justify-between px-4 py-3">
                    <span className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                      {s.label}
                    </span>
                    <span className="font-mono text-sm tabular-nums text-foreground">{s.value}</span>
                  </div>
                ))}
              </div>

              <p className="mt-6 font-mono text-[10px] uppercase leading-relaxed tracking-[0.12em] text-muted-foreground/70">
                All figures are sample data for demonstration purposes only.
              </p>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  )
}
