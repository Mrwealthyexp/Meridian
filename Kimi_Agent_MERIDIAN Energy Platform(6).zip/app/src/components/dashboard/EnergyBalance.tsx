import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import {
  Area,
  AreaChart,
  Bar,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { AXIS_TICK, CHART_TOOLTIP_STYLE, getSeries, sliceForRange } from '@/components/dashboard/data'
import type { RangeKey, RegionKey } from '@/components/dashboard/data'

type TabKey = 'supply' | 'generation' | 'mix'

const TAB_LABELS: { key: TabKey; label: string }[] = [
  { key: 'supply', label: 'Supply' },
  { key: 'generation', label: 'Generation' },
  { key: 'mix', label: 'Net Mix' },
]

export default function EnergyBalance({
  region,
  range,
  jitter,
  active,
}: {
  region: RegionKey
  range: RangeKey
  jitter: number
  active: boolean
}) {
  const [tab, setTab] = useState<TabKey>('supply')
  const mountedOnce = useRef(false)
  const [animDuration, setAnimDuration] = useState(1200)

  useEffect(() => {
    if (mountedOnce.current) setAnimDuration(600)
    mountedOnce.current = true
  }, [region, range, jitter, tab])

  const data = useMemo(() => sliceForRange(getSeries(region, jitter), range), [region, range, jitter])
  const sparse = data.length <= 8

  // Sliding tab underline indicator
  const listRef = useRef<HTMLDivElement>(null)
  const [indicator, setIndicator] = useState({ left: 0, width: 0 })
  useLayoutEffect(() => {
    const list = listRef.current
    if (!list) return
    const measure = () => {
      const el = list.querySelector<HTMLElement>('[data-state="active"]')
      if (el) setIndicator({ left: el.offsetLeft, width: el.offsetWidth })
    }
    measure()
    const ro = new ResizeObserver(measure)
    ro.observe(list)
    return () => ro.disconnect()
  }, [tab])

  return (
    <div
      className={`rounded-xl border border-border bg-card p-6 transition-all duration-700 ease-out ${
        active ? 'translate-y-0 opacity-100' : 'translate-y-7 opacity-0'
      }`}
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-sans text-lg font-semibold leading-[1.25] text-foreground md:text-[22px]">
          Energy Balance — Oil Supply vs Solar Generation
        </h3>

        <Tabs value={tab} onValueChange={(v) => setTab(v as TabKey)}>
          <div ref={listRef} className="relative">
            <TabsList className="h-9 rounded-lg bg-muted p-1">
              {TAB_LABELS.map((t) => (
                <TabsTrigger
                  key={t.key}
                  value={t.key}
                  className="rounded-md px-3 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-muted-foreground data-[state=active]:bg-transparent data-[state=active]:text-foreground data-[state=active]:shadow-none"
                >
                  {t.label}
                </TabsTrigger>
              ))}
            </TabsList>
            <span
              aria-hidden
              className="absolute -bottom-1 h-0.5 rounded-full bg-solar transition-all duration-300 ease-out"
              style={{ left: indicator.left, width: indicator.width }}
            />
          </div>
        </Tabs>
      </div>

      <div className="mt-5 h-[320px]">
        {tab === 'supply' && (
          <ResponsiveContainer key={`supply-${region}-${range}-${jitter}`} width="100%" height="100%">
            <ComposedChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: -8 }}>
              <CartesianGrid stroke="#E2DACB" strokeDasharray="3 6" vertical={false} />
              <XAxis dataKey="label" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: '#E2DACB' }} minTickGap={sparse ? 10 : 40} />
              <YAxis tick={AXIS_TICK} tickLine={false} axisLine={false} width={48} />
              <Tooltip contentStyle={CHART_TOOLTIP_STYLE} cursor={{ fill: 'rgba(23,20,16,0.04)' }} />
              <Bar
                dataKey="opec"
                name="OPEC+ output (M bbl/d)"
                fill="#0E5A50"
                radius={[4, 4, 0, 0]}
                isAnimationActive
                animationDuration={animDuration}
                animationEasing="ease-out"
              />
              <Line
                dataKey="nonOpec"
                name="Non-OPEC supply (M bbl/d)"
                stroke="#9A6A33"
                strokeWidth={2}
                strokeDasharray="6 4"
                dot={false}
                isAnimationActive
                animationDuration={animDuration}
                animationEasing="ease-out"
              />
            </ComposedChart>
          </ResponsiveContainer>
        )}

        {tab === 'generation' && (
          <ResponsiveContainer key={`gen-${region}-${range}-${jitter}`} width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: -8 }}>
              <defs>
                <linearGradient id="solarFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#F7C948" stopOpacity={0.55} />
                  <stop offset="100%" stopColor="#F7C948" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#E2DACB" strokeDasharray="3 6" vertical={false} />
              <XAxis dataKey="label" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: '#E2DACB' }} minTickGap={sparse ? 10 : 40} />
              <YAxis tick={AXIS_TICK} tickLine={false} axisLine={false} width={48} />
              <Tooltip contentStyle={CHART_TOOLTIP_STYLE} cursor={{ stroke: '#E2DACB' }} />
              <Area
                dataKey="solar"
                name="Solar generation (TWh)"
                stroke="#E9A319"
                strokeWidth={2}
                fill="url(#solarFill)"
                isAnimationActive
                animationDuration={animDuration}
                animationEasing="ease-out"
              />
            </AreaChart>
          </ResponsiveContainer>
        )}

        {tab === 'mix' && (
          <ResponsiveContainer key={`mix-${region}-${range}-${jitter}`} width="100%" height="100%">
            <AreaChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: -8 }} stackOffset="expand">
              <CartesianGrid stroke="#E2DACB" strokeDasharray="3 6" vertical={false} />
              <XAxis dataKey="label" tick={AXIS_TICK} tickLine={false} axisLine={{ stroke: '#E2DACB' }} minTickGap={sparse ? 10 : 40} />
              <YAxis
                tick={AXIS_TICK}
                tickLine={false}
                axisLine={false}
                width={48}
                tickFormatter={(v: number) => `${Math.round(v * 100)}%`}
              />
              <Tooltip
                contentStyle={CHART_TOOLTIP_STYLE}
                cursor={{ stroke: '#E2DACB' }}
                formatter={(value: number | string, name: number | string) => [`${value}%`, String(name).toUpperCase()]}
              />
              <Area dataKey="oil" name="oil" stackId="1" stroke="#0E5A50" fill="#0E5A50" fillOpacity={0.85} isAnimationActive animationDuration={animDuration} animationEasing="ease-out" />
              <Area dataKey="gas" name="gas" stackId="1" stroke="#9A6A33" fill="#9A6A33" fillOpacity={0.8} isAnimationActive animationDuration={animDuration} animationEasing="ease-out" />
              <Area dataKey="solarShare" name="solar" stackId="1" stroke="#E9A319" fill="#E9A319" fillOpacity={0.85} isAnimationActive animationDuration={animDuration} animationEasing="ease-out" />
              <Area dataKey="wind" name="wind" stackId="1" stroke="#7FA98C" fill="#7FA98C" fillOpacity={0.8} isAnimationActive animationDuration={animDuration} animationEasing="ease-out" />
              <Area dataKey="other" name="other" stackId="1" stroke="#B9AF9E" fill="#B9AF9E" fillOpacity={0.8} isAnimationActive animationDuration={animDuration} animationEasing="ease-out" />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>

      <p className="mt-4 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        Monthly · Indexed 2019=100 · Sample data
      </p>
    </div>
  )
}
