import { useEffect, useState } from 'react'
import { useCountUp, useInView } from '@/lib/animation'
import { Progress } from '@/components/ui/progress'
import { GAUGE_VALUE, SUB_METERS } from '@/components/dashboard/data'

/* Gauge geometry: 240° sweep arc from 210° → -30° (clockwise). */
const CX = 110
const CY = 110
const R = 84
const START = 210
const SWEEP = 240
const ARC_LEN = (SWEEP / 360) * 2 * Math.PI * R

function polar(angleDeg: number, r: number): [number, number] {
  const a = (angleDeg * Math.PI) / 180
  return [CX + r * Math.cos(a), CY - r * Math.sin(a)]
}

function arcPath(fromDeg: number, sweepDeg: number, r: number): string {
  const [x1, y1] = polar(fromDeg, r)
  const [x2, y2] = polar(fromDeg - sweepDeg, r)
  return `M ${x1.toFixed(2)} ${y1.toFixed(2)} A ${r} ${r} 0 ${sweepDeg > 180 ? 1 : 0} 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`
}

const METER_BAR_CLASS: Record<string, string> = {
  '#C2462B': '[&_[data-slot=progress-indicator]]:bg-[#C2462B]',
  '#2E7D4F': '[&_[data-slot=progress-indicator]]:bg-[#2E7D4F]',
  '#E9A319': '[&_[data-slot=progress-indicator]]:bg-[#E9A319]',
  '#0E5A50': '[&_[data-slot=progress-indicator]]:bg-[#0E5A50]',
}

export default function StressGauge({ active }: { active: boolean }) {
  const [ref, inView] = useInView<HTMLDivElement>(0.4)
  const on = active && inView

  const value = useCountUp(GAUGE_VALUE, on, 1400)
  const offset = ARC_LEN * (1 - value / 100)

  // Sub-meter staggered fills: value 0 → N%, 120ms stagger
  const [meters, setMeters] = useState<number[]>(SUB_METERS.map(() => 0))
  useEffect(() => {
    if (!on) return
    const timers = SUB_METERS.map((m, i) =>
      window.setTimeout(
        () => setMeters((prev) => prev.map((p, j) => (j === i ? m.value : p))),
        200 + i * 120,
      ),
    )
    return () => timers.forEach((t) => window.clearTimeout(t))
  }, [on])

  return (
    <div
      ref={ref}
      className={`rounded-xl border border-border bg-card p-6 transition-all duration-700 ease-out ${
        active ? 'translate-y-0 opacity-100' : 'translate-y-7 opacity-0'
      }`}
      style={{ transitionDelay: '150ms' }}
    >
      <h3 className="font-sans text-lg font-semibold leading-[1.25] text-foreground md:text-[22px]">
        System Stress Gauge
      </h3>
      <p className="mt-1 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        Composite supply security index
      </p>

      <div className="relative mx-auto mt-2 max-w-[240px]">
        <svg viewBox="0 0 220 150" className="w-full">
          <defs>
            <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#0E5A50" />
              <stop offset="100%" stopColor="#E9A319" />
            </linearGradient>
          </defs>

          {/* needle-style tick marks */}
          {Array.from({ length: 13 }, (_, i) => {
            const a = START - (SWEEP / 12) * i
            const [x1, y1] = polar(a, R + 9)
            const [x2, y2] = polar(a, R + 14)
            return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#B9AF9E" strokeWidth={1.4} />
          })}

          {/* track */}
          <path d={arcPath(START, SWEEP, R)} fill="none" stroke="#EDE7DA" strokeWidth={13} strokeLinecap="round" />

          {/* value arc — stroke-dashoffset animated via count-up value */}
          <path
            d={arcPath(START, SWEEP, R)}
            fill="none"
            stroke="url(#gaugeGrad)"
            strokeWidth={13}
            strokeLinecap="round"
            strokeDasharray={ARC_LEN}
            strokeDashoffset={offset}
          />
        </svg>

        <div className="absolute inset-x-0 bottom-1 text-center">
          <span className="font-mono text-4xl font-medium tabular-nums text-foreground">
            {Math.round(value)}
          </span>
          <span className="font-mono text-sm text-muted-foreground"> / 100</span>
        </div>
      </div>

      <div className="mt-5 space-y-3.5">
        {SUB_METERS.map((m, i) => (
          <div key={m.label}>
            <div className="mb-1.5 flex items-center justify-between font-mono text-[10px] font-medium uppercase tracking-[0.14em]">
              <span className="text-muted-foreground">{m.label}</span>
              <span className="tabular-nums text-foreground">{m.value}%</span>
            </div>
            <Progress
              value={meters[i]}
              className={`h-2 bg-muted [&_[data-slot=progress-indicator]]:duration-[900ms] [&_[data-slot=progress-indicator]]:ease-out ${METER_BAR_CLASS[m.color] ?? ''}`}
            />
          </div>
        ))}
      </div>
    </div>
  )
}
