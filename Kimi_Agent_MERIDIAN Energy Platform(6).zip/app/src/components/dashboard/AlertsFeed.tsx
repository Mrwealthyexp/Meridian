import { cn } from '@/lib/utils'
import { useInView } from '@/lib/animation'
import { ALERTS } from '@/components/dashboard/data'

const TAG_STYLES: Record<string, string> = {
  OIL: 'bg-oil/12 text-oil',
  SOLAR: 'bg-solar/12 text-solar-deep',
  GRID: 'bg-muted text-muted-foreground',
}

export default function AlertsFeed() {
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <div
      ref={ref}
      className={cn(
        'rounded-xl border border-border bg-card p-6 transition-all duration-700 ease-out',
        inView ? 'translate-y-0 opacity-100' : 'translate-y-7 opacity-0',
      )}
    >
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-sans text-lg font-semibold leading-[1.25] text-foreground md:text-[22px]">
          Signals &amp; Alerts
        </h3>
        <span className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-3 py-1">
          <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-solar" />
          <span className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
            Live · Sample
          </span>
        </span>
      </div>

      <div className="relative mt-5">
        {/* 2px amber line drawing down the left edge */}
        <span
          aria-hidden
          className="absolute left-0 top-0 h-full w-0.5 origin-top rounded-full bg-solar transition-transform duration-[900ms] ease-out"
          style={{ transform: inView ? 'scaleY(1)' : 'scaleY(0)' }}
        />

        <ul className="divide-y divide-border">
          {ALERTS.map((a, i) => (
            <li
              key={a.time}
              className={cn(
                'flex flex-wrap items-center gap-x-4 gap-y-1 py-3.5 pl-5 transition-all duration-500 ease-out',
                inView ? 'translate-x-0 opacity-100' : '-translate-x-4 opacity-0',
              )}
              style={{ transitionDelay: `${200 + i * 80}ms` }}
            >
              <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: a.dot }} />
              <span className="font-mono text-[11px] font-medium tabular-nums tracking-[0.06em] text-muted-foreground">
                {a.time}
              </span>
              <span className="min-w-0 flex-1 font-sans text-[15px] font-medium leading-snug text-foreground">
                {a.headline}
              </span>
              <span
                className={cn(
                  'inline-flex shrink-0 items-center rounded-full px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em]',
                  TAG_STYLES[a.tag],
                )}
              >
                {a.tag}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
