import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'
import { useReveal } from '@/lib/animation'

const EYEBROW_COLORS = {
  neutral: 'text-muted-foreground',
  solar: 'text-solar-deep',
  oil: 'text-oil',
} as const

/** §5.3 — eyebrow + H2 (Fraunces, italic phrase) + lede, left or centered. */
export default function SectionHeader({
  eyebrow,
  eyebrowTone = 'neutral',
  title,
  lede,
  align = 'left',
  className,
}: {
  eyebrow: string
  eyebrowTone?: keyof typeof EYEBROW_COLORS
  title: ReactNode
  lede?: ReactNode
  align?: 'left' | 'center'
  className?: string
}) {
  const ref = useReveal<HTMLDivElement>()

  return (
    <div
      ref={ref}
      data-reveal
      className={cn(align === 'center' && 'text-center', className)}
    >
      <p
        className={cn(
          'font-mono text-xs font-semibold uppercase tracking-[0.18em]',
          EYEBROW_COLORS[eyebrowTone],
        )}
      >
        {eyebrow}
      </p>
      <h2 className="mt-3 font-display text-3xl font-medium leading-[1.1] tracking-[-0.01em] text-foreground md:text-[42px]">
        {title}
      </h2>
      {lede && (
        <p
          className={cn(
            'mt-4 max-w-2xl text-[17px] leading-[1.6] text-muted-foreground md:text-lg',
            align === 'center' && 'mx-auto',
          )}
        >
          {lede}
        </p>
      )}
    </div>
  )
}
