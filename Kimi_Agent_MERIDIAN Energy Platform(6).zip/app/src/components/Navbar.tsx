import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router'
import { Menu } from 'lucide-react'
import { cn } from '@/lib/utils'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'

export const NAV_LINKS = [
  { to: '/dashboard', label: 'Dashboard', accent: '#171410' },
  { to: '/oil-supply', label: 'Oil Supply', accent: '#0E5A50' },
  { to: '/solar-energy', label: 'Solar Energy', accent: '#E9A319' },
  { to: '/services', label: 'Services', accent: '#171410' },
  { to: '/insights', label: 'Insights', accent: '#171410' },
  { to: '/about', label: 'About', accent: '#171410' },
] as const

export function Logo({ dark = false }: { dark?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <img src="/logo.svg" alt="Meridian logo" className={cn('h-[22px] w-[22px]', dark && 'invert')} />
      <span
        className={cn(
          'font-sans text-base font-bold tracking-[0.02em]',
          dark ? 'text-terminal-text' : 'text-foreground',
        )}
      >
        MERIDIAN
      </span>
      <span
        className={cn(
          'hidden font-mono text-[10px] font-medium tracking-[0.14em] lg:inline',
          dark ? 'text-terminal-text/50' : 'text-muted-foreground',
        )}
      >
        // ENERGY INTELLIGENCE
      </span>
      <span
        className={cn(
          'hidden rounded-full border px-2 py-0.5 font-mono text-[10px] font-semibold tracking-[0.12em] sm:inline-flex',
          dark
            ? 'border-terminal-amber/40 bg-terminal-amber/10 text-terminal-amber'
            : 'border-solar/50 bg-solar/10 text-solar-deep',
        )}
      >
        PRESENTED BY $WEX
      </span>
    </Link>
  )
}

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    setOpen(false)
  }, [location.pathname])

  return (
    <nav className="h-16 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-full max-w-[1360px] items-center justify-between px-6 md:px-10">
        <Logo />

        {/* Center links */}
        <div className="hidden items-center gap-7 lg:flex">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                cn(
                  'font-sans text-sm font-medium transition-colors',
                  isActive ? 'text-foreground' : 'text-muted-foreground hover:text-foreground',
                )
              }
            >
              {({ isActive }) => (
                <span
                  className="nav-link"
                  data-active={isActive}
                  style={{ ['--nav-accent' as string]: link.accent }}
                >
                  {link.label}
                </span>
              )}
            </NavLink>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <span className="hidden rounded-full border border-border bg-card px-3 py-1.5 font-mono text-[11px] font-medium tracking-[0.08em] text-muted-foreground md:inline-flex">
            Q3 · ENERGY MIX 34% RENEWABLE
          </span>
          <Link
            to="/about#contact"
            className="hidden rounded-lg bg-solar px-4 py-2 font-sans text-sm font-semibold text-foreground transition-all hover:-translate-y-px hover:bg-solar-deep hover:text-white active:scale-[0.97] sm:inline-flex"
          >
            Request Access
          </Link>

          {/* Mobile menu */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <button
                aria-label="Open menu"
                className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-card lg:hidden"
              >
                <Menu className="h-5 w-5" />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] bg-card">
              <SheetHeader>
                <SheetTitle className="text-left">
                  <Logo />
                </SheetTitle>
              </SheetHeader>
              <div className="mt-8 flex flex-col gap-1">
                {NAV_LINKS.map((link, i) => (
                  <NavLink
                    key={link.to}
                    to={link.to}
                    style={{ transitionDelay: `${i * 60}ms` }}
                    className={({ isActive }) =>
                      cn(
                        'rounded-lg px-4 py-3 font-sans text-base font-medium transition-all',
                        open && 'translate-x-0 opacity-100',
                        isActive
                          ? 'bg-muted text-foreground'
                          : 'text-muted-foreground hover:bg-muted/60 hover:text-foreground',
                      )
                    }
                  >
                    {link.label}
                  </NavLink>
                ))}
                <Link
                  to="/about#contact"
                  className="mt-6 rounded-lg bg-solar px-4 py-3 text-center font-sans text-base font-semibold text-foreground transition-colors hover:bg-solar-deep hover:text-white"
                >
                  Request Access
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  )
}
