import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import MaskedWords from '@/components/services/MaskedWords'

/**
 * Section 1 — full-bleed hero band over hybrid-infrastructure.jpg with a
 * heavy warm scrim that dissolves into the page background.
 */
export default function ServicesHero() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    const raf = requestAnimationFrame(() => setMounted(true))
    return () => cancelAnimationFrame(raf)
  }, [])

  return (
    <section className="relative h-[420px] overflow-hidden">
      {/* Background image: 1.08 -> 1 on mount, then slow Ken Burns drift */}
      <img
        src="/hybrid-infrastructure.jpg"
        alt="Solar panels installed alongside a pipeline corridor in split amber and teal light"
        className="svc-hero-img absolute inset-0 h-full w-full object-cover"
      />
      {/* Warm scrim, fading to page background at the bottom */}
      <div
        className="svc-hero-scrim absolute inset-0"
        style={{
          background:
            'linear-gradient(180deg, rgba(23,20,16,0.72), rgba(23,20,16,0.55) 60%, #F6F2EA 100%)',
        }}
      />

      <div className="relative z-10 mx-auto flex h-[300px] max-w-[1200px] flex-col justify-center px-6 md:px-10">
        <nav aria-label="Breadcrumb" className="svc-hero-rise font-mono text-[11px] font-medium tracking-[0.14em] text-terminal-text/60">
          <Link to="/" className="transition-colors hover:text-terminal-amber">
            HOME
          </Link>
          <span className="mx-2">/</span>
          <span>SERVICES</span>
        </nav>

        <p
          className="svc-hero-rise mt-4 font-mono text-xs font-semibold uppercase tracking-[0.18em] text-terminal-amber"
          style={{ animationDelay: '150ms' }}
        >
          {"// WHERE WE'RE NEEDED"}
        </p>

        <h1 className="mt-4 font-display text-[36px] font-medium leading-[1.05] tracking-[-0.015em] text-white md:text-[56px]">
          <MaskedWords
            active={mounted}
            baseDelay={200}
            stagger={60}
            segments={[
              { text: 'Needed at the' },
              { text: 'intersection', italic: true },
              { text: 'of oil and sun.' },
            ]}
          />
        </h1>

        <p
          className="svc-hero-rise mt-5 max-w-2xl text-[17px] leading-[1.6] text-white/80 md:text-lg"
          style={{ animationDelay: '600ms' }}
        >
          Six service lines, four regions, one mandate: give decision-makers the
          data and expertise the dual-energy era demands.
        </p>
      </div>
    </section>
  )
}
