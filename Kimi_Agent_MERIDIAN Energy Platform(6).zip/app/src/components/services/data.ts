import {
  Database,
  GitMerge,
  PanelsTopLeft,
  Radio,
  ShieldCheck,
  TrendingUpDown,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

/* ------------------------------------------------------------------ */
/* Service catalog (Section 2)                                         */
/* ------------------------------------------------------------------ */

export type Service = {
  id: string
  title: string
  icon: LucideIcon
  blurb: string
  deliverables: string[]
  expanded: string
  timeline: { step: string; detail: string }[]
}

export const SERVICES: Service[] = [
  {
    id: 'transition-analytics',
    title: 'Transition Analytics',
    icon: TrendingUpDown,
    blurb:
      'Model the shift from crude dependence to solar supply at national or portfolio scale.',
    deliverables: ['SCENARIO MODELS', 'MIX FORECASTS', 'POLICY BRIEFS'],
    expanded:
      'We quantify how fast oil demand erodes and solar supply ramps for your specific exposure — a ministry planning 2040 capacity, or a fund repricing a crude-heavy portfolio. Every model ships with the assumptions exposed, so your analysts can stress our work, not just cite it.',
    timeline: [
      { step: 'WEEK 0', detail: 'Scoping workshop — exposure map & mandate' },
      { step: 'WEEK 2', detail: 'Data integration — national/portfolio baseline' },
      { step: 'WEEK 6', detail: 'Scenario models delivered — 3 transition paths' },
      { step: 'WEEK 8+', detail: 'Quarterly forecast refresh & policy briefs' },
    ],
  },
  {
    id: 'reserve-supply-feeds',
    title: 'Reserve & Supply Data Feeds',
    icon: Database,
    blurb: 'SPR levels, flows, and chokepoint telemetry via API or dashboard.',
    deliverables: ['DAILY FEEDS', 'API ACCESS', 'ALERT RULES'],
    expanded:
      'One normalized feed for strategic reserves, seaborne flows, and chokepoint status — the 372M bbl US SPR, 94 days of IEA import cover, Hormuz transits — delivered to your terminal before the market digests it.',
    timeline: [
      { step: 'DAY 1', detail: 'API credentials & sandbox access' },
      { step: 'WEEK 1', detail: 'Feed mapping against your tickers & regions' },
      { step: 'WEEK 2', detail: 'Alert rules tuned with your desk' },
      { step: 'ONGOING', detail: 'Daily delivery · 99.9% uptime SLA' },
    ],
  },
  {
    id: 'solar-pipeline-intel',
    title: 'Solar Pipeline Intelligence',
    icon: PanelsTopLeft,
    blurb: 'Every utility-scale project tracked from permit to grid-tie.',
    deliverables: ['PIPELINE DB', 'COD ALERTS', 'MARKET SCANS'],
    expanded:
      '9,400 projects across 120 solar markets, tracked from first permit to commercial operation date. When the 612 GW global pipeline shifts, you see which projects moved, why, and what it means for module prices and grid capacity.',
    timeline: [
      { step: 'WEEK 0', detail: 'Market selection & watchlist build' },
      { step: 'WEEK 1', detail: 'Pipeline DB access & historical export' },
      { step: 'WEEK 3', detail: 'COD alert thresholds configured' },
      { step: 'MONTHLY', detail: 'Market scan — shifts, delays, cancellations' },
    ],
  },
  {
    id: 'hybrid-infrastructure',
    title: 'Hybrid Infrastructure Advisory',
    icon: GitMerge,
    blurb:
      'Site solar alongside pipelines, terminals, and refineries to compound asset value.',
    deliverables: ['SITING STUDIES', 'DUAL-USE DESIGN', 'CAPEX MODELS'],
    expanded:
      'Pipeline corridors, tank farms, and refinery perimeters are pre-cleared, grid-adjacent land. We identify where PV arrays compound the value of existing oil infrastructure — dual-use design, interconnection strategy, and capex models that survive an investment committee.',
    timeline: [
      { step: 'WEEK 0', detail: 'Asset register review & corridor screening' },
      { step: 'WEEK 4', detail: 'Siting study — irradiance, grid, land status' },
      { step: 'WEEK 8', detail: 'Dual-use design & interconnection plan' },
      { step: 'WEEK 12', detail: 'Capex model & board-ready business case' },
    ],
  },
  {
    id: 'market-signal-feeds',
    title: 'Market Signal Feeds',
    icon: Radio,
    blurb:
      'Benchmark crude prices and PV indices, normalized and delivered intraday.',
    deliverables: ['PRICE APIS', 'INDEX LICENSING', 'DESK TOOLS'],
    expanded:
      'WTI, Brent, polysilicon, module prices, and the Meridian PV Index — cleaned, normalized, and timestamped for machine consumption. License the indices or pipe the raw signals straight into your desk tools.',
    timeline: [
      { step: 'DAY 1', detail: 'Sandbox keys & schema documentation' },
      { step: 'WEEK 1', detail: 'Signal selection & latency tier' },
      { step: 'WEEK 2', detail: 'Desk tool integration support' },
      { step: 'ONGOING', detail: 'Intraday delivery · index licensing' },
    ],
  },
  {
    id: 'security-briefings',
    title: 'Energy Security Briefings',
    icon: ShieldCheck,
    blurb:
      'Analyst-written briefings connecting oil shocks to solar ramp capacity.',
    deliverables: ['WEEKLY BRIEFS', 'CRISIS NOTES', 'BOARD SESSIONS'],
    expanded:
      'When a chokepoint closes or a cartel cuts, the first question is how fast solar can backfill. Our analysts write the answer — weekly briefings, crisis notes within hours, and private board sessions for the decisions that cannot wait for a report cycle.',
    timeline: [
      { step: 'WEEK 0', detail: 'Mandate briefing — regions & risk posture' },
      { step: 'WEEK 1', detail: 'First weekly brief + distribution list' },
      { step: 'AD HOC', detail: 'Crisis notes within 6 hours of an event' },
      { step: 'QUARTERLY', detail: 'Board session with senior analysts' },
    ],
  },
]

/* ------------------------------------------------------------------ */
/* Opportunity map hotspots (Section 3)                                */
/* Coordinates snapped to the /world-dots.svg 2000x1000 dot grid.      */
/* ------------------------------------------------------------------ */

export type HotspotDomain = 'oil' | 'solar' | 'intersection'
export type Urgency = 'CRITICAL' | 'HIGH' | 'MEDIUM'

export type Hotspot = {
  id: string
  name: string
  tag: string
  domain: HotspotDomain
  /** position in the 2000x1000 map viewBox */
  x: number
  y: number
  need: string
  urgency: Urgency
  /** market size in $B (sample data) */
  marketSize: number
  mandates: number
  rationale: string
  /** pulse-ring stagger delay, ms */
  pulseDelay: number
}

export const HOTSPOTS: Hotspot[] = [
  {
    id: 'hormuz',
    name: 'Strait of Hormuz',
    tag: 'CHOKEPOINT',
    domain: 'oil',
    x: 1323,
    y: 344,
    need: 'RESERVE & SUPPLY FEEDS',
    urgency: 'CRITICAL',
    marketSize: 1800,
    mandates: 6,
    rationale:
      'Roughly a fifth of global crude transits this 33 km channel every day. Shippers, insurers, and ministries need second-by-second risk telemetry when tensions rise.',
    pulseDelay: 0,
  },
  {
    id: 'gulf-coast',
    name: 'US Gulf Coast',
    tag: 'SPR & REFINING',
    domain: 'oil',
    x: 465,
    y: 344,
    need: 'RESERVE & SUPPLY FEEDS',
    urgency: 'HIGH',
    marketSize: 640,
    mandates: 9,
    rationale:
      'Home to the bulk of the 372M bbl Strategic Petroleum Reserve and half of US refining capacity. Drawdown and refill decisions move global balances within hours.',
    pulseDelay: 480,
  },
  {
    id: 'bab-el-mandeb',
    name: 'Bab el-Mandeb',
    tag: 'CHOKEPOINT',
    domain: 'oil',
    x: 1235,
    y: 432,
    need: 'ENERGY SECURITY BRIEFINGS',
    urgency: 'CRITICAL',
    marketSize: 820,
    mandates: 4,
    rationale:
      'The Red Sea gate between Suez and the open ocean — rerouting here adds weeks and billions to supply chains. Crisis-note demand spikes with every incident.',
    pulseDelay: 960,
  },
  {
    id: 'rotterdam',
    name: 'Rotterdam',
    tag: 'EU GATEWAY',
    domain: 'oil',
    x: 1037,
    y: 212,
    need: 'MARKET SIGNAL FEEDS',
    urgency: 'MEDIUM',
    marketSize: 310,
    mandates: 7,
    rationale:
      'Europe’s largest port and the pricing heart of the Atlantic basin. As Europe backfills crude and scales renewables, signal latency here is a trading edge.',
    pulseDelay: 1440,
  },
  {
    id: 'atacama',
    name: 'Atacama, Chile',
    tag: 'SOLAR-GROWTH',
    domain: 'solar',
    x: 630,
    y: 630,
    need: 'SOLAR PIPELINE INTELLIGENCE',
    urgency: 'MEDIUM',
    marketSize: 46,
    mandates: 3,
    rationale:
      'The highest irradiance on Earth and a pipeline of utility-scale projects feeding mining demand. Tracking permit-to-grid-tie here is a full-time intelligence job.',
    pulseDelay: 240,
  },
  {
    id: 'gujarat',
    name: 'Gujarat, India',
    tag: 'SOLAR-GROWTH',
    domain: 'solar',
    x: 1400,
    y: 366,
    need: 'TRANSITION ANALYTICS',
    urgency: 'HIGH',
    marketSize: 92,
    mandates: 8,
    rationale:
      'India’s renewable workhorse state, anchoring one of the world’s most aggressive solar build-outs. Policy shifts here ripple through the entire 612 GW pipeline.',
    pulseDelay: 720,
  },
  {
    id: 'pilbara',
    name: 'Pilbara, Australia',
    tag: 'SOLAR-GROWTH',
    domain: 'solar',
    x: 1664,
    y: 630,
    need: 'HYBRID INFRASTRUCTURE',
    urgency: 'MEDIUM',
    marketSize: 38,
    mandates: 2,
    rationale:
      'Remote mining loads are switching from diesel to solar-plus-storage at scale. Dual-use siting along existing corridors is the fastest path to decarbonized ore.',
    pulseDelay: 1200,
  },
  {
    id: 'ningxia',
    name: 'Ningxia, China',
    tag: 'SOLAR-GROWTH',
    domain: 'solar',
    x: 1587,
    y: 300,
    need: 'SOLAR PIPELINE INTELLIGENCE',
    urgency: 'HIGH',
    marketSize: 74,
    mandates: 5,
    rationale:
      'A desert base of gigawatt-scale solar bases tied to ultra-high-voltage export lines. Curtailment and grid-tie data here signal module demand for all of Asia.',
    pulseDelay: 1680,
  },
  {
    id: 'saudi-arabia',
    name: 'Saudi Arabia',
    tag: 'VISION TRANSITION',
    domain: 'intersection',
    x: 1279,
    y: 344,
    need: 'TRANSITION ANALYTICS',
    urgency: 'HIGH',
    marketSize: 210,
    mandates: 4,
    rationale:
      'The world’s swing oil producer is simultaneously tendering record solar capacity. Modeling that pivot — barrels out, photons in — is exactly our mandate.',
    pulseDelay: 1920,
  },
  {
    id: 'texas',
    name: 'Texas',
    tag: 'PERMIAN + PV',
    domain: 'intersection',
    x: 432,
    y: 322,
    need: 'HYBRID INFRASTRUCTURE',
    urgency: 'HIGH',
    marketSize: 185,
    mandates: 11,
    rationale:
      'The Permian pumps more crude than any US basin while ERCOT interconnects more solar than any US grid. No region needs oil-and-solar intelligence in one feed more.',
    pulseDelay: 2160,
  },
]

export const DEFAULT_HOTSPOT_ID = 'texas'

/* ------------------------------------------------------------------ */
/* Engagement tiers (Section 4)                                        */
/* ------------------------------------------------------------------ */

export type Tier = {
  name: string
  mono: string
  blurb: string
  price: string
  features: string[]
  cta: { label: string; primary: boolean }
  emphasized?: boolean
}

export const TIERS: Tier[] = [
  {
    name: 'Data License',
    mono: 'API + DASHBOARD ACCESS',
    blurb: 'For desks and ministries that need the feed.',
    price: 'FROM $4,800/MO · SAMPLE',
    features: [
      'Full oil + solar data API',
      'Dashboard seats for 5 analysts',
      'Daily reserve & flow feeds',
      'Standard alert rules',
    ],
    cta: { label: 'Start with data', primary: false },
  },
  {
    name: 'Advisory Retainer',
    mono: 'DATA + ANALYSTS',
    blurb: 'Feeds plus a named analyst team on call.',
    price: 'FROM $18K/MO · SAMPLE',
    features: [
      'Everything in Data License',
      'Named senior analyst team',
      'Weekly security briefings',
      'Crisis notes within 6 hours',
      'Quarterly board session',
    ],
    cta: { label: 'Book a scoping call', primary: true },
    emphasized: true,
  },
  {
    name: 'Strategic Partnership',
    mono: 'EMBEDDED INTELLIGENCE',
    blurb: 'Co-built models, sovereign programs, joint ventures.',
    price: 'CUSTOM',
    features: [
      'Co-built transition models',
      'Embedded analyst residency',
      'Sovereign program support',
      'Joint venture structuring',
    ],
    cta: { label: 'Talk to us', primary: false },
  },
]
