import { Link } from 'react-router'
import { Check } from 'lucide-react'
import SectionHeader from '@/components/SectionHeader'
import { useReveal } from '@/lib/animation'
import { cn } from '@/lib/utils'
import { TIERS } from '@/components/services/data'
import type { Tier } from '@/components/services/data'

function TierCard({ tier, index }: { tier: Tier; index: number }) {
  // emphasized card rises last with the spring settle
  const baseDelay = tier.emphasized ? 240 : index * 120

  return (
    <div
      className={cn(
        // staggered rise, driven by the grid's .is-revealed class
        'translate-y-8 opacity-0 transition-all duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] [.is-revealed_&]:translate-y-0 [.is-revealed_&]:opacity-100',
        tier.emphasized && 'lg:-my-2',
      )}
      style={{ transitionDelay: `${baseDelay}ms` }}
    >
      {/* Inner wrapper handles the emphasized card's spring settle scale */}
      <div
        className={cn(
          'h-full scale-[0.97] transition-transform duration-700 [.is-revealed_&]:scale-100',
          tier.emphasized && 'lg:[.is-revealed_&]:scale-[1.03]',
        )}
        style={{
          transitionTimingFunction: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
          transitionDelay: `${baseDelay}ms`,
        }}
      >
        <article
          className={cn(
            'card-lift relative flex h-full flex-col rounded-xl border bg-card p-8',
            tier.emphasized
              ? 'border-2 border-solar hover:-translate-y-1.5'
              : 'border-border',
          )}
        >
          {tier.emphasized && (
            <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-solar px-3 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-foreground">
              Most chosen
            </span>
          )}

          <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            {tier.mono}
          </p>
          <h3 className="mt-3 font-sans text-[22px] font-semibold leading-[1.25] text-foreground">
            {tier.name}
          </h3>
          <p className="mt-2 text-[13px] leading-[1.5] text-muted-foreground">
            {tier.blurb}
          </p>

          <p
            className={cn(
              'mt-6 border-t pt-5 font-mono text-sm font-semibold tabular-nums tracking-[0.04em]',
              tier.emphasized ? 'border-solar/40 text-solar-deep' : 'border-border text-foreground',
            )}
          >
            {tier.price}
          </p>

          <ul className="mt-5 flex-1 space-y-3">
            {tier.features.map((feature, fi) => (
              <li
                key={feature}
                className="flex items-start gap-2.5 text-sm leading-[1.5] text-foreground/80 opacity-0 translate-y-2 transition-all duration-500 [.is-revealed_&]:translate-y-0 [.is-revealed_&]:opacity-100"
                style={{ transitionDelay: `${baseDelay + 400 + fi * 60}ms` }}
              >
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-solar-deep" />
                {feature}
              </li>
            ))}
          </ul>

          {tier.cta.primary ? (
            <Link
              to="/about#contact"
              className="mt-8 inline-flex items-center justify-center rounded-lg bg-solar px-4 py-2.5 font-sans text-sm font-semibold text-foreground transition-all hover:-translate-y-px hover:bg-solar-deep hover:text-white active:scale-[0.97]"
            >
              {tier.cta.label}
            </Link>
          ) : (
            <Link
              to="/about#contact"
              className="mt-8 inline-flex items-center justify-center rounded-lg border border-border bg-transparent px-4 py-2.5 font-sans text-sm font-semibold text-foreground transition-all hover:-translate-y-px hover:border-oil hover:text-oil active:scale-[0.97]"
            >
              {tier.cta.label}
            </Link>
          )}
        </article>
      </div>
    </div>
  )
}

/** Section 4 — engagement models / pricing tiers. */
export default function EngagementTiers() {
  const gridRef = useReveal<HTMLDivElement>()

  return (
    <section className="py-24">
      <div className="mx-auto max-w-[1200px] px-6 md:px-10">
        <SectionHeader
          eyebrow="// HOW TO ENGAGE"
          eyebrowTone="neutral"
          title={
            <>
              Three doors in.{' '}
              <em className="font-display italic">One partner</em> behind them.
            </>
          }
          lede="Start with the feed, add the analysts, or build something sovereign-scale together. Every path runs on the same data spine."
        />

        <div
          ref={gridRef}
          className="mt-14 grid items-stretch gap-6 lg:grid-cols-3"
        >
          {TIERS.map((tier, i) => (
            <TierCard key={tier.name} tier={tier} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
