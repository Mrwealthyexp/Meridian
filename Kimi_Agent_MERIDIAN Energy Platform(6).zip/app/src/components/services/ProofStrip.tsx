import { useEffect, useState } from 'react'
import { useCountUp, useInView } from '@/lib/animation'

const METRICS = [
  { value: 46, label: 'NATIONS COVERED', format: (v: number) => `${Math.round(v)}` },
  { value: 120, label: 'SOLAR MARKETS', format: (v: number) => `${Math.round(v)}` },
  {
    value: 9400,
    label: 'PROJECTS TRACKED',
    format: (v: number) => new Intl.NumberFormat('en-US').format(Math.round(v)),
  },
  { value: 24, label: 'SIGNAL UPTIME', format: (v: number) => `${Math.round(v)}/7` },
]

function Metric({
  value,
  label,
  format,
  active,
  delay,
}: {
  value: number
  label: string
  format: (v: number) => string
  active: boolean
  delay: number
}) {
  // per-metric stagger: delay the count-up start via a keyed remount
  const counted = useCountUp(value, active, 1400)

  return (
    <div className="text-center" style={{ transitionDelay: `${delay}ms` }}>
      <p className="font-mono text-3xl font-medium tabular-nums tracking-[-0.01em] text-foreground md:text-[40px]">
        {format(counted)}
      </p>
      <p className="mt-2 font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </p>
    </div>
  )
}

/** Section 5 — proof metrics on a muted band. */
export default function ProofStrip() {
  const [ref, inView] = useInView<HTMLDivElement>(0.4)

  return (
    <section className="bg-muted/40 py-16">
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 md:px-10">
        {/* hairline rule draws in */}
        <div
          className={
            'mx-auto mb-12 h-px w-full max-w-3xl origin-center bg-border transition-transform duration-[800ms] ease-out ' +
            (inView ? 'scale-x-100' : 'scale-x-0')
          }
        />
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {METRICS.map((m, i) => (
            <StaggeredMetric key={m.label} metric={m} index={i} active={inView} />
          ))}
        </div>
        <p className="mt-10 text-center font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground/70">
          Engagement metrics · Sample data
        </p>
      </div>
    </section>
  )
}

function StaggeredMetric({
  metric,
  index,
  active,
}: {
  metric: (typeof METRICS)[number]
  index: number
  active: boolean
}) {
  // 150ms stagger between metrics
  const delayed = useDelayedFlag(active, index * 150)
  return (
    <Metric
      value={metric.value}
      label={metric.label}
      format={metric.format}
      active={delayed}
      delay={index * 150}
    />
  )
}

function useDelayedFlag(flag: boolean, delay: number) {
  const [value, setValue] = useState(false)
  useEffect(() => {
    if (!flag) return
    const t = setTimeout(() => setValue(true), delay)
    return () => clearTimeout(t)
  }, [flag, delay])
  return value
}
