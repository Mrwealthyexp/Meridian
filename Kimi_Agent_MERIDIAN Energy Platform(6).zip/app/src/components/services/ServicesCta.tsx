import { Link } from 'react-router'
import MaskedWords from '@/components/services/MaskedWords'
import { useInView } from '@/lib/animation'
import { cn } from '@/lib/utils'

/** Section 6 — centered CTA close. */
export default function ServicesCta() {
  const [ref, inView] = useInView<HTMLDivElement>(0.4)

  return (
    <section className="py-32">
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 text-center md:px-10">
        <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-solar-deep">
          {"// REQUEST ACCESS"}
        </p>

        <h2 className="mx-auto mt-4 font-display text-3xl font-medium leading-[1.1] tracking-[-0.01em] text-foreground md:text-5xl">
          <MaskedWords
            active={inView}
            stagger={50}
            segments={[
              { text: 'Your mandate.' },
              { text: 'Our intelligence.', italic: true },
            ]}
          />
        </h2>

        {/* amber rule, center-origin draw */}
        <div
          className={cn(
            'mx-auto mt-8 h-[3px] w-24 origin-center bg-solar transition-transform duration-[600ms] ease-out',
            inView ? 'scale-x-100' : 'scale-x-0',
          )}
        />

        <p className="mx-auto mt-8 max-w-2xl text-[17px] leading-[1.6] text-muted-foreground md:text-lg">
          Tell us where your oil exposure meets your solar ambition — we'll
          show you the data behind it.
        </p>

        <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <span
            className={cn(
              'transition-all duration-500 ease-out',
              inView ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0',
            )}
            style={{ transitionDelay: '300ms' }}
          >
            <Link
              to="/about#contact"
              className="inline-flex rounded-lg bg-solar px-6 py-3 font-sans text-base font-semibold text-foreground transition-all hover:-translate-y-px hover:bg-solar-deep hover:text-white active:scale-[0.97]"
            >
              Request Access
            </Link>
          </span>
          <span
            className={cn(
              'transition-all duration-500 ease-out',
              inView ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0',
            )}
            style={{ transitionDelay: '450ms' }}
          >
            <Link
              to="/insights"
              className="inline-flex rounded-lg border border-border px-6 py-3 font-sans text-base font-semibold text-foreground transition-all hover:-translate-y-px hover:border-oil hover:text-oil active:scale-[0.97]"
            >
              Read our briefings
            </Link>
          </span>
        </div>
      </div>
    </section>
  )
}
