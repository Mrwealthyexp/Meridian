import { Link } from 'react-router'
import { ArrowRight, Check } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import SectionHeader from '@/components/SectionHeader'
import { DomainBadge } from '@/components/badges'
import { useReveal } from '@/lib/animation'
import { SERVICES } from '@/components/services/data'
import type { Service } from '@/components/services/data'

function ServiceCard({ service, index }: { service: Service; index: number }) {
  const Icon = service.icon

  return (
    <Dialog>
      <DialogTrigger asChild>
        <article
          style={{ ['--i' as string]: index }}
          className="card-lift group relative cursor-pointer overflow-hidden rounded-xl border border-border bg-card p-8 text-left hover:border-solar/40"
        >
          {/* Intersection signature: 3px teal->amber top border, draws left->right after card lands */}
          <span
            aria-hidden
            className="absolute left-0 top-0 h-[3px] w-full origin-left scale-x-0 transition-transform duration-500 ease-out [.is-revealed_&]:scale-x-100"
            style={{
              background: 'linear-gradient(90deg, #0E5A50, #E9A319)',
              transitionDelay: `calc(var(--i, 0) * 90ms + 750ms)`,
            }}
          />

          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-muted transition-all duration-[250ms] group-hover:-rotate-6 group-hover:bg-[linear-gradient(135deg,rgba(14,90,80,0.15),rgba(233,163,25,0.15))]">
            <Icon className="h-5 w-5 text-oil transition-colors group-hover:text-solar-deep" />
          </div>

          <h3 className="mt-5 font-sans text-lg font-semibold leading-[1.25] text-foreground md:text-[22px]">
            {service.title}
          </h3>
          <p className="mt-2.5 text-[13px] leading-[1.5] text-muted-foreground">
            {service.blurb}
          </p>

          <div className="mt-6 border-t border-border pt-4">
            <p className="font-mono text-[10px] font-medium uppercase leading-relaxed tracking-[0.12em] text-muted-foreground">
              {service.deliverables.join(' · ')}
            </p>
            <span className="mt-3 inline-flex items-center gap-1.5 font-sans text-sm font-medium text-oil transition-colors group-hover:text-solar-deep">
              Details
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </span>
          </div>
        </article>
      </DialogTrigger>

      <DialogContent className="bg-card sm:max-w-[560px]">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
              <Icon className="h-5 w-5 text-oil" />
            </div>
            <DomainBadge domain="intersection" />
          </div>
          <DialogTitle className="pt-3 font-display text-2xl font-medium tracking-[-0.01em]">
            {service.title}
          </DialogTitle>
          <DialogDescription className="text-[15px] leading-[1.65] text-muted-foreground">
            {service.expanded}
          </DialogDescription>
        </DialogHeader>

        <div className="mt-2 rounded-lg border border-border bg-muted/40 p-5">
          <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            Sample engagement timeline
          </p>
          <ol className="mt-3 space-y-2.5">
            {service.timeline.map((t) => (
              <li key={t.step} className="flex items-baseline gap-3">
                <Check className="h-3.5 w-3.5 shrink-0 translate-y-0.5 text-solar-deep" />
                <span className="w-20 shrink-0 font-mono text-[11px] font-semibold tracking-[0.08em] text-oil">
                  {t.step}
                </span>
                <span className="font-mono text-[12px] leading-relaxed text-foreground/80">
                  {t.detail}
                </span>
              </li>
            ))}
          </ol>
        </div>

        <div className="mt-4 flex items-center justify-between gap-4">
          <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
            {service.deliverables.join(' · ')}
          </p>
          <Link
            to="/about#contact"
            className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-solar px-4 py-2 font-sans text-sm font-semibold text-foreground transition-all hover:-translate-y-px hover:bg-solar-deep hover:text-white active:scale-[0.97]"
          >
            Discuss this service
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </DialogContent>
    </Dialog>
  )
}

/** Section 2 — six split-tone service cards with detail dialogs. */
export default function ServiceCatalog() {
  const gridRef = useReveal<HTMLDivElement>()

  return (
    <section className="py-24">
      <div className="mx-auto max-w-[1200px] px-6 md:px-10">
        <SectionHeader
          eyebrow="// SERVICE CATALOG"
          eyebrowTone="neutral"
          title={
            <>
              Six ways we become{' '}
              <em className="font-display italic">indispensable</em>.
            </>
          }
          lede="Every service lives at the oil↔solar intersection — data, models, and analysts for organizations navigating both systems at once."
        />

        <div
          ref={gridRef}
          data-reveal-stagger
          className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3"
        >
          {SERVICES.map((service, i) => (
            <ServiceCard key={service.id} service={service} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
