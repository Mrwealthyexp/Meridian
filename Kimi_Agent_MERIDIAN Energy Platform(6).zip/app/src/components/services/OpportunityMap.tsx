import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import { ArrowRight } from 'lucide-react'
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from '@/components/ui/hover-card'
import { cn } from '@/lib/utils'
import { useCountUp, useReveal } from '@/lib/animation'
import {
  DEFAULT_HOTSPOT_ID,
  HOTSPOTS,
} from '@/components/services/data'
import type { Hotspot, HotspotDomain, Urgency } from '@/components/services/data'

/* Brighter domain tones for legibility on the dark terminal band */
const DOT_COLORS: Record<HotspotDomain, string> = {
  oil: '#35A493',
  solar: '#F7B32B',
  intersection: '#F7B32B',
}

const URGENCY_STYLES: Record<Urgency, string> = {
  CRITICAL: 'bg-critical/20 text-[#E8846C]',
  HIGH: 'bg-terminal-amber/15 text-terminal-amber',
  MEDIUM: 'bg-oil/30 text-[#5FBDB0]',
}

const DOMAIN_LABEL: Record<HotspotDomain, string> = {
  oil: 'OIL',
  solar: 'SOLAR',
  intersection: 'INTERSECTION',
}

/** Fetch /world-dots.svg and strip it down to its inner markup so the dot
 *  fill can be tinted with currentColor on the dark band. */
function useWorldDotsInner() {
  const [inner, setInner] = useState<string | null>(null)

  useEffect(() => {
    let alive = true
    fetch('/world-dots.svg')
      .then((r) => r.text())
      .then((text) => {
        if (!alive) return
        const match = text.match(/<svg[^>]*>([\s\S]*)<\/svg>/)
        setInner(match ? match[1] : null)
      })
      .catch(() => setInner(null))
    return () => {
      alive = false
    }
  }, [])

  return inner
}

function SplitDot({ className }: { className?: string }) {
  return (
    <span
      aria-hidden
      className={cn('inline-block rounded-full', className)}
      style={{ background: 'linear-gradient(90deg, #35A493 50%, #F7B32B 50%)' }}
    />
  )
}

function HotspotMarker({
  spot,
  selected,
  onSelect,
}: {
  spot: Hotspot
  selected: boolean
  onSelect: (id: string) => void
}) {
  const color = DOT_COLORS[spot.domain]
  const ringCircumference = 2 * Math.PI * 24

  return (
    <HoverCard openDelay={100} closeDelay={80}>
      <HoverCardTrigger asChild>
        <button
          type="button"
          aria-label={`${spot.name} — ${spot.tag}`}
          onClick={() => onSelect(spot.id)}
          className="group absolute z-10 h-11 w-11 -translate-x-1/2 -translate-y-1/2 cursor-pointer"
          style={{
            left: `${(spot.x / 2000) * 100}%`,
            top: `${(spot.y / 1000) * 100}%`,
          }}
        >
          {/* pulse ring (transform/opacity only, staggered per hotspot) */}
          <span
            aria-hidden
            className="absolute left-1/2 top-1/2 -ml-[22px] -mt-[22px] h-11 w-11 animate-pulse-ring rounded-full border-2"
            style={{ borderColor: color, animationDelay: `${spot.pulseDelay}ms` }}
          />
          {/* selected ring, drawn via stroke-dashoffset */}
          <svg
            aria-hidden
            viewBox="0 0 56 56"
            className="absolute left-1/2 top-1/2 -ml-7 -mt-7 h-14 w-14"
          >
            <circle
              cx="28"
              cy="28"
              r="24"
              fill="none"
              stroke="#F7B32B"
              strokeWidth="2"
              strokeDasharray={ringCircumference}
              style={{
                strokeDashoffset: selected ? 0 : ringCircumference,
                transition: 'stroke-dashoffset 400ms ease-out',
              }}
            />
          </svg>
          {/* core dot */}
          {spot.domain === 'intersection' ? (
            <SplitDot className="absolute left-1/2 top-1/2 -ml-1.5 -mt-1.5 h-3 w-3 transition-transform group-hover:scale-125" />
          ) : (
            <span
              aria-hidden
              className="absolute left-1/2 top-1/2 -ml-1.5 -mt-1.5 h-3 w-3 rounded-full transition-transform group-hover:scale-125"
              style={{ background: color }}
            />
          )}
        </button>
      </HoverCardTrigger>
      <HoverCardContent
        side="top"
        sideOffset={10}
        className="w-72 rounded-md border-terminal-border bg-terminal-surface p-4"
      >
        <p className="font-mono text-[11px] font-semibold uppercase tracking-[0.12em] text-terminal-text">
          {spot.name} · {spot.tag}
        </p>
        <div className="mt-2.5 space-y-1.5 font-mono text-[10px] uppercase tracking-[0.1em]">
          <p className="text-terminal-text/60">
            NEED: <span className="text-terminal-text">{spot.need}</span>
          </p>
          <p className="flex items-center gap-2 text-terminal-text/60">
            URGENCY:
            <span
              className={cn(
                'rounded-full px-2 py-0.5 font-semibold',
                URGENCY_STYLES[spot.urgency],
              )}
            >
              {spot.urgency}
            </span>
          </p>
          <p className="text-terminal-text/40">CLICK FOR FULL BRIEF</p>
        </div>
      </HoverCardContent>
    </HoverCard>
  )
}

function DomainBadgeDark({ domain }: { domain: HotspotDomain }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em]',
        domain === 'oil' && 'bg-oil/30 text-[#5FBDB0]',
        domain === 'solar' && 'bg-terminal-amber/12 text-terminal-amber',
        domain === 'intersection' &&
          'bg-[linear-gradient(90deg,rgba(14,90,80,0.35),rgba(247,179,43,0.18))] text-terminal-text',
      )}
    >
      {domain === 'intersection' && <SplitDot className="h-2 w-2" />}
      {DOMAIN_LABEL[domain]}
    </span>
  )
}

function DetailPanel({ spot }: { spot: Hotspot }) {
  const market = useCountUp(spot.marketSize, true, 800)
  const mandates = useCountUp(spot.mandates, true, 800)

  const marketLabel =
    spot.marketSize >= 1000
      ? `$${(market / 1000).toFixed(1)}T`
      : `$${Math.round(market)}B`

  return (
    <div
      key={spot.id}
      className="svc-panel-in rounded-md border border-terminal-border bg-terminal-surface p-8"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-sans text-[22px] font-semibold leading-[1.25] text-terminal-text">
            {spot.name}
          </h3>
          <p className="mt-1 font-mono text-[11px] uppercase tracking-[0.14em] text-terminal-text/50">
            {spot.tag}
          </p>
        </div>
        <DomainBadgeDark domain={spot.domain} />
      </div>

      <div className="mt-6 space-y-4 border-t border-terminal-border pt-6">
        <div className="flex items-baseline justify-between gap-4">
          <span className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-terminal-text/50">
            Market size
          </span>
          <span className="font-mono text-xl font-medium tabular-nums text-terminal-amber">
            {marketLabel}
          </span>
        </div>
        <div className="flex items-baseline justify-between gap-4">
          <span className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-terminal-text/50">
            Active mandates
          </span>
          <span className="font-mono text-xl font-medium tabular-nums text-terminal-text">
            {Math.round(mandates)}
          </span>
        </div>
        <div className="flex items-center justify-between gap-4">
          <span className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-terminal-text/50">
            Urgency
          </span>
          <span
            className={cn(
              'rounded-full px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em]',
              URGENCY_STYLES[spot.urgency],
            )}
          >
            {spot.urgency}
          </span>
        </div>
      </div>

      <p className="mt-6 text-sm leading-[1.65] text-terminal-text/70">
        {spot.rationale}
      </p>
      <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.12em] text-terminal-text/40">
        Need: {spot.need} · Sample data
      </p>

      <Link
        to="/about#contact"
        className="mt-6 inline-flex items-center gap-1.5 font-sans text-sm font-semibold text-terminal-amber transition-colors hover:text-solar-bright"
      >
        Engage Meridian
        <ArrowRight className="h-4 w-4" />
      </Link>
    </div>
  )
}

/** Section 3 — dark interactive opportunity map (the page's one dark band). */
export default function OpportunityMap() {
  const [selectedId, setSelectedId] = useState(DEFAULT_HOTSPOT_ID)
  const headerRef = useReveal<HTMLDivElement>()
  const mapRef = useReveal<HTMLDivElement>()
  const panelRef = useReveal<HTMLDivElement>()
  const dotsInner = useWorldDotsInner()
  const [mapDelay] = useState(() => 300 + Math.round(Math.random() * 300))

  const selected = HOTSPOTS.find((h) => h.id === selectedId) ?? HOTSPOTS[0]

  return (
    <section className="bg-terminal-bg py-24">
      <div className="mx-auto max-w-[1200px] px-6 md:px-10">
        <div ref={headerRef} data-reveal>
          <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-terminal-amber">
            {"// THE OPPORTUNITY MAP"}
          </p>
          <h2 className="mt-3 font-display text-3xl font-medium leading-[1.1] tracking-[-0.01em] text-terminal-text md:text-[42px]">
            Where the world <em className="font-display italic">needs us next</em>.
          </h2>
          <p className="mt-4 max-w-2xl text-[17px] leading-[1.6] text-terminal-text/70 md:text-lg">
            Ten regions where oil exposure meets solar ambition. Hover a hotspot
            for the signal; click to open the full brief.
          </p>
        </div>

        <div className="mt-12 grid gap-10 lg:grid-cols-3">
          {/* Map */}
          <div ref={mapRef} data-reveal className="lg:col-span-2">
            <div
              className="relative aspect-[2/1] w-full"
              style={{ ['--reveal-delay' as string]: `${mapDelay}ms` }}
            >
              {dotsInner && (
                <svg
                  viewBox="0 0 2000 1000"
                  className="h-full w-full text-terminal-text/[0.18]"
                  fill="currentColor"
                  role="img"
                  aria-label="Dot-grid world map with opportunity hotspots"
                  dangerouslySetInnerHTML={{ __html: dotsInner }}
                />
              )}
              {HOTSPOTS.map((spot) => (
                <HotspotMarker
                  key={spot.id}
                  spot={spot}
                  selected={spot.id === selectedId}
                  onSelect={setSelectedId}
                />
              ))}
            </div>

            {/* Legend */}
            <div className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-terminal-text/50">
              <span className="inline-flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-[#35A493]" />
                Oil-critical
              </span>
              <span className="inline-flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-terminal-amber" />
                Solar-growth
              </span>
              <span className="inline-flex items-center gap-2">
                <SplitDot className="h-2 w-2" />
                Intersection
              </span>
              <span className="ml-auto hidden text-terminal-text/30 md:inline">
                SAMPLE DATA · HOVER / CLICK HOTSPOTS
              </span>
            </div>
          </div>

          {/* Detail panel */}
          <div ref={panelRef} data-reveal style={{ ['--reveal-delay' as string]: '150ms' }}>
            <DetailPanel key={selected.id} spot={selected} />
          </div>
        </div>
      </div>
    </section>
  )
}
