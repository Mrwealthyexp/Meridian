import { cn } from '@/lib/utils'

export type WordSegment = { text: string; italic?: boolean }

type MaskedWordsProps = {
  /** Segments of the headline; each segment is split into masked words. */
  segments: WordSegment[]
  /** When true, words slide up into view (adds .words-in). */
  active: boolean
  /** Delay before the first word starts, ms. */
  baseDelay?: number
  /** Stagger between words, ms. */
  stagger?: number
  className?: string
}

/**
 * Word-level masked slide-up headline (design §4.4). Relies on the global
 * `.word-mask` / `.words-in` CSS in index.css.
 */
export default function MaskedWords({
  segments,
  active,
  baseDelay = 0,
  stagger = 60,
  className,
}: MaskedWordsProps) {
  let wordIndex = 0
  return (
    <span className={cn(active && 'words-in', className)}>
      {segments.map((segment, si) =>
        segment.text
          .split(' ')
          .filter(Boolean)
          .map((word, wi) => {
            const delay = baseDelay + wordIndex * stagger
            wordIndex += 1
            return (
              <span key={`${si}-${wi}`} className="word-mask">
                <span
                  style={{ ['--word-delay' as string]: `${delay}ms` }}
                  className={cn(segment.italic && 'font-display italic')}
                >
                  {word}
                </span>
                {/* keep inter-word spacing */}
                {'\u00A0'}
              </span>
            )
          }),
      )}
    </span>
  )
}
