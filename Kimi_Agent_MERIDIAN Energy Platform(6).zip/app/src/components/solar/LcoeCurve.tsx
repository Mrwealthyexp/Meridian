import { useEffect, useState } from 'react'
import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceDot,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { useCountUp, useInView } from '@/lib/animation'
import { LCOE } from './data'
import { SlideIn, TerminalTooltip } from './shared'

const AXIS_TICK = {
  fill: '#6E675B',
  fontSize: 10,
  fontFamily: "'IBM Plex Mono', monospace",
} as const

/** Pulsing amber marker that fades in ~1400ms after chart mount, then pulses. */
function CrossoverDot({ cx, cy }: { cx?: number; cy?: number }) {
  const [on, setOn] = useState(false)
  useEffect(() => {
    const t = setTimeout(() => setOn(true), 1400)
    return () => clearTimeout(t)
  }, [])
  if (cx == null || cy == null) return null
  return (
    <g style={{ opacity: on ? 1 : 0, transition: 'opacity 300ms ease-out' }}>
      <circle cx={cx} cy={cy} r={5} fill="#E9A319" stroke="#FCFAF5" strokeWidth={2} />
      <circle cx={cx} cy={cy} r={5} fill="none" stroke="#E9A319" strokeWidth={1.5}>
        <animate attributeName="r" values="5;16" dur="2.4s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="0.7;0" dur="2.4s" repeatCount="indefinite" />
      </circle>
      <text
        x={cx + 12}
        y={cy - 10}
        fill="#B57309"
        fontSize={10}
        fontFamily="'IBM Plex Mono', monospace"
        fontWeight={600}
        letterSpacing="0.1em"
      >
        CROSSOVER · 2020
      </text>
    </g>
  )
}

function MiniStat({
  label,
  value,
  suffix,
  delta,
  active,
  index,
}: {
  label: string
  value: number
  suffix: string
  delta?: string
  active: boolean
  index: number
}) {
  const [start, setStart] = useState(false)
  useEffect(() => {
    if (!active) return
    const t = setTimeout(() => setStart(true), 400 + index * 120)
    return () => clearTimeout(t)
  }, [active, index])
  const v = useCountUp(value, start, 1200)
  return (
    <div className="rounded-lg border border-border bg-muted/40 p-4">
      <p className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </p>
      <p className="mt-1.5 font-mono text-xl font-semibold tabular-nums text-foreground">
        ${Math.round(v)}
        <span className="text-sm text-muted-foreground">{suffix}</span>
      </p>
      {delta && (
        <p className="mt-1 font-mono text-[10px] font-semibold tracking-[0.1em] text-positive">
          {delta}
        </p>
      )}
    </div>
  )
}

export default function LcoeCurve() {
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <section className="pb-24">
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 md:px-10">
        <SlideIn active={inView} y={28} duration={700}>
          <div className="rounded-xl border border-border bg-card p-6 md:p-10">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h3 className="font-sans text-lg font-semibold leading-[1.25] text-foreground md:text-[22px]">
                The Learning Curve
              </h3>
              <p className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                Utility PV LCOE · $/MWh · Sample Data
              </p>
            </div>

            <div className="mt-8 h-[360px]">
              {inView && (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={LCOE} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
                    <CartesianGrid stroke="#EDE7DA" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="year" tickLine={false} axisLine={false} tick={AXIS_TICK} />
                    <YAxis tickLine={false} axisLine={false} width={40} tick={AXIS_TICK} />
                    <Tooltip
                      content={<TerminalTooltip unit="/MWH" />}
                      cursor={{ stroke: '#E9A319', strokeOpacity: 0.4 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="solar"
                      name="Solar PV"
                      stroke="#E9A319"
                      strokeWidth={2.5}
                      dot={false}
                      isAnimationActive
                      animationDuration={1400}
                      animationEasing="ease-out"
                    />
                    <Line
                      type="monotone"
                      dataKey="coal"
                      name="Coal"
                      stroke="#6E675B"
                      strokeWidth={1.5}
                      strokeDasharray="6 4"
                      dot={false}
                      isAnimationActive
                      animationDuration={1400}
                      animationBegin={250}
                      animationEasing="ease-out"
                    />
                    <Line
                      type="monotone"
                      dataKey="gas"
                      name="Gas Peaker"
                      stroke="#0E5A50"
                      strokeWidth={1.5}
                      strokeDasharray="6 4"
                      dot={false}
                      isAnimationActive
                      animationDuration={1400}
                      animationBegin={500}
                      animationEasing="ease-out"
                    />
                    <ReferenceDot x={2020} y={68} shape={<CrossoverDot />} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2">
              {[
                { c: '#E9A319', label: 'Solar PV' },
                { c: '#6E675B', label: 'Coal' },
                { c: '#0E5A50', label: 'Gas Peaker' },
              ].map((l) => (
                <span
                  key={l.label}
                  className="flex items-center gap-1.5 font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground"
                >
                  <span className="h-0.5 w-4 rounded-full" style={{ backgroundColor: l.c }} />
                  {l.label}
                </span>
              ))}
            </div>

            <div className="mt-8 grid gap-4 sm:grid-cols-3">
              <MiniStat
                label="Solar LCOE"
                value={38}
                suffix="/MWH"
                delta="▼ 89% SINCE 2010"
                active={inView}
                index={0}
              />
              <MiniStat label="Coal" value={71} suffix="/MWH" active={inView} index={1} />
              <MiniStat label="Gas Peaker" value={118} suffix="/MWH" active={inView} index={2} />
            </div>
          </div>
        </SlideIn>
      </div>
    </section>
  )
}
