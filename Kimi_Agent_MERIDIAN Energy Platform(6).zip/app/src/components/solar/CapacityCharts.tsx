import { useState } from 'react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useInView } from '@/lib/animation'
import {
  ANNUAL_ADDITIONS,
  CAPACITY_FACTOR_LEADERS,
  CUMULATIVE,
  REGIONAL,
  REGION_COLORS,
} from './data'
import { FillBar, SlideIn, TerminalTooltip } from './shared'

type ChartTab = 'annual' | 'cumulative' | 'regional'

const AXIS_TICK = {
  fill: '#6E675B',
  fontSize: 10,
  fontFamily: "'IBM Plex Mono', monospace",
} as const

function ChartBody({ tab }: { tab: ChartTab }) {
  if (tab === 'annual') {
    return (
      <BarChart data={ANNUAL_ADDITIONS} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
        <CartesianGrid stroke="#EDE7DA" strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="year" tickLine={false} axisLine={false} tick={AXIS_TICK} />
        <YAxis tickLine={false} axisLine={false} width={36} tick={AXIS_TICK} />
        <Tooltip content={<TerminalTooltip unit=" GW" />} cursor={{ fill: '#E9A319', fillOpacity: 0.06 }} />
        <Bar dataKey="gw" radius={[6, 6, 0, 0]} isAnimationActive animationDuration={900} animationEasing="ease-out">
          {ANNUAL_ADDITIONS.map((p) => (
            <Cell
              key={p.year}
              fill="#E9A319"
              fillOpacity={p.estimate ? 0.6 : 1}
              strokeDasharray={p.estimate ? '4 3' : undefined}
              stroke={p.estimate ? '#B57309' : undefined}
              strokeWidth={p.estimate ? 1 : 0}
            />
          ))}
        </Bar>
      </BarChart>
    )
  }

  if (tab === 'cumulative') {
    return (
      <AreaChart data={CUMULATIVE} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
        <defs>
          <linearGradient id="solar-cum-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#E9A319" stopOpacity={0.32} />
            <stop offset="100%" stopColor="#E9A319" stopOpacity={0.03} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="#EDE7DA" strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="year" tickLine={false} axisLine={false} tick={AXIS_TICK} />
        <YAxis tickLine={false} axisLine={false} width={44} tick={AXIS_TICK} />
        <Tooltip content={<TerminalTooltip unit=" GW" />} cursor={{ stroke: '#E9A319', strokeOpacity: 0.4 }} />
        <Area
          type="monotone"
          dataKey="gw"
          stroke="#B57309"
          strokeWidth={2}
          fill="url(#solar-cum-fill)"
          isAnimationActive
          animationDuration={1200}
          animationEasing="ease-out"
        />
      </AreaChart>
    )
  }

  return (
    <BarChart data={REGIONAL} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
      <CartesianGrid stroke="#EDE7DA" strokeDasharray="3 3" vertical={false} />
      <XAxis dataKey="year" tickLine={false} axisLine={false} tick={AXIS_TICK} />
      <YAxis tickLine={false} axisLine={false} width={36} tick={AXIS_TICK} />
      <Tooltip content={<TerminalTooltip unit=" GW" />} cursor={{ fill: '#E9A319', fillOpacity: 0.06 }} />
      <Bar dataKey="cn" stackId="r" fill={REGION_COLORS.cn} isAnimationActive animationDuration={800} />
      <Bar dataKey="eu" stackId="r" fill={REGION_COLORS.eu} isAnimationActive animationDuration={800} />
      <Bar dataKey="us" stackId="r" fill={REGION_COLORS.us} isAnimationActive animationDuration={800} />
      <Bar dataKey="india" stackId="r" fill={REGION_COLORS.india} isAnimationActive animationDuration={800} />
      <Bar dataKey="row" stackId="r" fill={REGION_COLORS.row} radius={[6, 6, 0, 0]} isAnimationActive animationDuration={800} />
    </BarChart>
  )
}

export default function CapacityCharts() {
  const [tab, setTab] = useState<ChartTab>('annual')
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <section className="mx-auto mt-20 max-w-[1200px] px-6 md:px-10">
      <div ref={ref} className="grid gap-6 lg:grid-cols-3">
        {/* Main chart card */}
        <SlideIn active={inView} y={28} duration={700} className="lg:col-span-2">
          <div className="h-full rounded-xl border border-border bg-card p-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="font-sans text-lg font-semibold leading-[1.25] text-foreground md:text-[22px]">
                  Global Solar Capacity Additions
                </h3>
                <p className="mt-1 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                  GW Installed · Sample Data
                </p>
              </div>
              <Tabs value={tab} onValueChange={(v) => setTab(v as ChartTab)}>
                <TabsList className="bg-muted">
                  <TabsTrigger value="annual" className="font-mono text-[11px]">ANNUAL GW</TabsTrigger>
                  <TabsTrigger value="cumulative" className="font-mono text-[11px]">CUMULATIVE</TabsTrigger>
                  <TabsTrigger value="regional" className="font-mono text-[11px]">BY REGION</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="mt-6 h-[320px]">
              {inView && (
                <ResponsiveContainer width="100%" height="100%">
                  <ChartBody key={tab} tab={tab} />
                </ResponsiveContainer>
              )}
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-border pt-4">
              {tab === 'regional' ? (
                (Object.keys(REGION_COLORS) as (keyof typeof REGION_COLORS)[]).map((k) => (
                  <span key={k} className="flex items-center gap-1.5 font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: REGION_COLORS[k] }} />
                    {k === 'cn' ? 'China' : k === 'eu' ? 'Europe' : k === 'us' ? 'United States' : k === 'india' ? 'India' : 'Rest of World'}
                  </span>
                ))
              ) : (
                <span className="font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
                  2025E shaded = Meridian estimate
                </span>
              )}
            </div>
          </div>
        </SlideIn>

        {/* Capacity factor leaders */}
        <SlideIn active={inView} index={1} step={120} y={28} duration={700}>
          <div className="h-full rounded-xl border border-border bg-card p-6">
            <h3 className="font-sans text-lg font-semibold text-foreground">
              Capacity Factor Leaders
            </h3>
            <p className="mt-1 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
              Fleet Average · Sample Data
            </p>
            <div className="mt-6 space-y-5">
              {CAPACITY_FACTOR_LEADERS.map((r, i) => (
                <div
                  key={r.country}
                  style={{
                    opacity: inView ? 1 : 0,
                    transform: inView ? 'none' : 'translateX(16px)',
                    transition: `opacity 600ms cubic-bezier(0.22,1,0.36,1) ${i * 90}ms, transform 600ms cubic-bezier(0.22,1,0.36,1) ${i * 90}ms`,
                  }}
                >
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="flex items-baseline gap-3">
                      <span className="font-mono text-[11px] font-semibold tabular-nums text-solar-deep">
                        {String(i + 1).padStart(2, '0')}
                      </span>
                      <span className="font-sans text-sm font-medium text-foreground">
                        {r.country}
                      </span>
                    </span>
                    <span className="font-mono text-xs font-semibold tabular-nums text-foreground">
                      {r.factor}%
                    </span>
                  </div>
                  <FillBar
                    value={(r.factor / 35) * 100}
                    active={inView}
                    delay={300 + i * 120}
                    duration={800}
                    color="#E9A319"
                    className="mt-2"
                  />
                </div>
              ))}
            </div>
          </div>
        </SlideIn>
      </div>
    </section>
  )
}
