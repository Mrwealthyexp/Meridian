/* ---------------- Capacity data (GW, sample) ---------------- */

export type AnnualPoint = { year: string; gw: number; estimate?: boolean }

export const ANNUAL_ADDITIONS: AnnualPoint[] = [
  { year: '2016', gw: 52 },
  { year: '2017', gw: 76 },
  { year: '2018', gw: 96 },
  { year: '2019', gw: 106 },
  { year: '2020', gw: 124 },
  { year: '2021', gw: 148 },
  { year: '2022', gw: 176 },
  { year: '2023', gw: 226 },
  { year: '2024', gw: 282 },
  { year: '2025E', gw: 324, estimate: true },
]

export const CUMULATIVE = ANNUAL_ADDITIONS.reduce<
  { year: string; gw: number; estimate?: boolean }[]
>((acc, p, i) => {
  acc.push({ year: p.year, gw: (acc[i - 1]?.gw ?? 0) + p.gw, estimate: p.estimate })
  return acc
}, [])

export type RegionShare = { year: string; cn: number; eu: number; us: number; india: number; row: number }

const SHARES = { cn: 0.45, eu: 0.17, us: 0.12, india: 0.1, row: 0.16 }

export const REGIONAL: RegionShare[] = ANNUAL_ADDITIONS.map((p) => ({
  year: p.year,
  cn: Math.round(p.gw * SHARES.cn),
  eu: Math.round(p.gw * SHARES.eu),
  us: Math.round(p.gw * SHARES.us),
  india: Math.round(p.gw * SHARES.india),
  row: Math.round(p.gw * SHARES.row),
}))

export const REGION_COLORS = {
  cn: '#B57309',
  eu: '#E9A319',
  us: '#F7C948',
  india: '#D98E04',
  row: '#CBB26A',
} as const

export const CAPACITY_FACTOR_LEADERS = [
  { country: 'Chile', factor: 31 },
  { country: 'Australia', factor: 29 },
  { country: 'US Southwest', factor: 27 },
  { country: 'India', factor: 24 },
  { country: 'Spain', factor: 23 },
  { country: 'China', factor: 19 },
]

/* ---------------- Pipeline tracker ---------------- */

export type ProjectStatus = 'PERMITTED' | 'UNDER CONSTRUCTION' | 'GRID-TIED'

export type Project = {
  id: string
  name: string
  country: string
  region: string
  capacity: number // GW
  status: ProjectStatus
  cod: string
  progress: number
  capex: string
  note: string
  timeline: { permit: string; construction: string; gridTie: string }
}

export const PROJECTS: Project[] = [
  {
    id: 'sunspire-mesa',
    name: 'Sunspire Mesa',
    country: 'US',
    region: 'North America',
    capacity: 2.4,
    status: 'UNDER CONSTRUCTION',
    cod: 'Q2 2026',
    progress: 62,
    capex: '$2.1B',
    note: 'Single-axis tracking across 9,800 acres of high-desert plateau. Interconnection queues cleared in Q1 2025; module deliveries are running two weeks ahead of schedule.',
    timeline: { permit: 'Q3 2023', construction: 'Q1 2024', gridTie: 'Q2 2026' },
  },
  {
    id: 'thar-radiance',
    name: 'Thar Radiance',
    country: 'IN',
    region: 'Asia-Pacific',
    capacity: 3.1,
    status: 'PERMITTED',
    cod: 'Q4 2026',
    progress: 18,
    capex: '$1.9B',
    note: 'Desert-edge site with Class A irradiance and a dedicated 400kV evacuation corridor. Land aggregation complete; financial close expected mid-2026.',
    timeline: { permit: 'Q2 2025', construction: 'Q1 2026', gridTie: 'Q4 2026' },
  },
  {
    id: 'atacama-prime',
    name: 'Atacama Prime',
    country: 'CL',
    region: 'Latin America',
    capacity: 1.8,
    status: 'GRID-TIED',
    cod: 'DONE',
    progress: 100,
    capex: '$1.4B',
    note: 'The highest-irradiance utility site in the Meridian coverage universe, achieving a 31% capacity factor in its first full quarter of operation.',
    timeline: { permit: 'Q4 2021', construction: 'Q3 2022', gridTie: 'Q1 2024' },
  },
  {
    id: 'ningxia-helios',
    name: 'Ningxia Helios',
    country: 'CN',
    region: 'Asia-Pacific',
    capacity: 5.0,
    status: 'UNDER CONSTRUCTION',
    cod: 'Q1 2027',
    progress: 44,
    capex: '$3.6B',
    note: 'Anchor project of a desert-base renewables cluster pairing 5 GW of PV with co-located storage. Piling complete on 60% of the array field.',
    timeline: { permit: 'Q1 2023', construction: 'Q4 2023', gridTie: 'Q1 2027' },
  },
  {
    id: 'andalusia-array',
    name: 'Andalusia Array',
    country: 'ES',
    region: 'Europe',
    capacity: 0.9,
    status: 'GRID-TIED',
    cod: 'DONE',
    progress: 100,
    capex: '$0.7B',
    note: 'Merchant-plus-PPA hybrid that reached grid tie eleven weeks early. First-year output is tracking 6% above the P50 model.',
    timeline: { permit: 'Q2 2021', construction: 'Q1 2022', gridTie: 'Q2 2023' },
  },
  {
    id: 'pilbara-sun',
    name: 'Pilbara Sun',
    country: 'AU',
    region: 'Asia-Pacific',
    capacity: 2.2,
    status: 'PERMITTED',
    cod: 'Q3 2027',
    progress: 9,
    capex: '$1.8B',
    note: 'Industrial-load-anchored project serving iron-ore operations; 70% of output is contracted under a 15-year tolling agreement.',
    timeline: { permit: 'Q1 2025', construction: 'Q2 2026', gridTie: 'Q3 2027' },
  },
  {
    id: 'neom-heliopolis',
    name: 'Neom Heliopolis',
    country: 'SA',
    region: 'Middle East',
    capacity: 4.0,
    status: 'UNDER CONSTRUCTION',
    cod: 'Q4 2026',
    progress: 37,
    capex: '$3.2B',
    note: 'Flagship of the Kingdom\'s giga-project energy build-out. Bifacial modules on single-axis trackers with robotic dry-cleaning across the full field.',
    timeline: { permit: 'Q3 2022', construction: 'Q2 2024', gridTie: 'Q4 2026' },
  },
  {
    id: 'bavaria-sud',
    name: 'Bavaria Süd',
    country: 'DE',
    region: 'Europe',
    capacity: 0.6,
    status: 'GRID-TIED',
    cod: 'DONE',
    progress: 100,
    capex: '$0.5B',
    note: 'Agri-PV demonstration at utility scale — dual land use with grazing retained across 80% of the site. Output per hectare leads the German fleet.',
    timeline: { permit: 'Q1 2022', construction: 'Q3 2022', gridTie: 'Q4 2023' },
  },
]

export const REGIONS = [
  'North America',
  'Latin America',
  'Europe',
  'Middle East',
  'Asia-Pacific',
] as const

/* ---------------- LCOE learning curve ($/MWh, sample) ---------------- */

export const LCOE = [
  { year: 2010, solar: 345, coal: 63, gas: 108 },
  { year: 2011, solar: 302, coal: 64, gas: 112 },
  { year: 2012, solar: 262, coal: 65, gas: 110 },
  { year: 2013, solar: 225, coal: 65, gas: 115 },
  { year: 2014, solar: 196, coal: 66, gas: 118 },
  { year: 2015, solar: 172, coal: 66, gas: 114 },
  { year: 2016, solar: 150, coal: 67, gas: 119 },
  { year: 2017, solar: 128, coal: 68, gas: 116 },
  { year: 2018, solar: 110, coal: 69, gas: 121 },
  { year: 2019, solar: 92, coal: 70, gas: 118 },
  { year: 2020, solar: 68, coal: 71, gas: 122 },
  { year: 2021, solar: 60, coal: 73, gas: 125 },
  { year: 2022, solar: 54, coal: 76, gas: 132 },
  { year: 2023, solar: 48, coal: 74, gas: 124 },
  { year: 2024, solar: 42, coal: 72, gas: 120 },
  { year: 2025, solar: 38, coal: 71, gas: 118 },
]

/* ---------------- Irradiance hotspots ---------------- */

export const HOTSPOTS = [
  { id: 'chile', label: 'Chile · Atacama', ghi: '2,300', cls: 'CLASS A', x: 31, y: 71, size: 12 },
  { id: 'australia', label: 'Australia · Pilbara', ghi: '2,100', cls: 'CLASS A', x: 84, y: 70, size: 11 },
  { id: 'mena', label: 'MENA · Neom', ghi: '2,200', cls: 'CLASS A', x: 56, y: 42, size: 12 },
  { id: 'india', label: 'India · Thar', ghi: '2,000', cls: 'CLASS A', x: 66, y: 47, size: 10 },
  { id: 'us-sw', label: 'US Southwest', ghi: '1,950', cls: 'CLASS A', x: 17, y: 40, size: 10 },
  { id: 'china-nw', label: 'China NW · Ningxia', ghi: '1,800', cls: 'CLASS B+', x: 73, y: 36, size: 9 },
]

/* ---------------- KPI sparklines ---------------- */

function mulberry32(seed: number) {
  return () => {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export function sparkline(seed: number, points = 24, start = 90, end = 100) {
  const rand = mulberry32(seed)
  let v = start
  const step = (end - start) / (points - 1)
  return Array.from({ length: points }, (_, i) => {
    v += step + (rand() - 0.5) * step * 3
    return { i, v: +v.toFixed(2) }
  })
}
