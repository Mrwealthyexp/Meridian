import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import { Sun } from 'lucide-react'
import Words from '@/components/home/Words'
import { HeroIn } from './shared'

export default function SolarHero() {
  const [mounted, setMounted] = useState(false)
  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 40)
    return () => clearTimeout(t)
  }, [])

  return (
    <section className="relative overflow-hidden pb-16 pt-[136px]">
      {/* Breathing amber glow, top-right */}
      <div className="pointer-events-none absolute -right-32 -top-32 h-[600px] w-[600px]">
        <div
          className="h-full w-full animate-glow-breathe rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(247,201,72,0.22) 0%, transparent 70%)',
          }}
        />
      </div>

      <div className="relative mx-auto grid w-full max-w-[1200px] gap-12 px-6 md:px-10 lg:grid-cols-2 lg:items-center">
        <div>
          <HeroIn delay={80} duration={400} x={-16} y={0}>
            <p className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
              <Link to="/" className="transition-colors hover:text-foreground">
                Home
              </Link>
              <span className="mx-2">/</span>
              Solar Energy
            </p>
          </HeroIn>
          <HeroIn delay={160} duration={400} x={-16} y={0}>
            <p className="mt-5 flex items-center gap-2 font-mono text-xs font-semibold uppercase tracking-[0.18em] text-solar-deep">
              <Sun className="h-3.5 w-3.5 text-solar" />
              // Solar Energy Intelligence
            </p>
          </HeroIn>

          <h1
            className="mt-4 font-display text-4xl font-medium leading-[1.05] tracking-[-0.015em] text-foreground md:text-[56px]"
            style={{ fontVariationSettings: "'opsz' 144" }}
          >
            <Words
              active={mounted}
              delayStart={320}
              stagger={60}
              segments={[
                { text: 'Sunlight, turned into' },
                { text: 'strategy', italic: true },
                { text: '.' },
              ]}
            />
          </h1>

          <HeroIn delay={700} duration={600} y={16}>
            <p className="mt-6 max-w-2xl text-[17px] leading-[1.6] text-muted-foreground md:text-lg">
              Installed capacity, generation output, project pipelines,
              irradiance economics, and cost curves — the solar system of the
              energy system, quantified.
            </p>
          </HeroIn>
        </div>

        {/* Hero image card — clip-path wipe reveal + scale settle */}
        <div
          className="relative hidden lg:block"
          style={{
            clipPath: mounted ? 'inset(0 0 0 0)' : 'inset(0 100% 0 0)',
            transition: 'clip-path 900ms ease-out 500ms',
          }}
        >
          <div className="relative aspect-[16/10] overflow-hidden rounded-xl border border-border">
            <img
              src="/solar-field.jpg"
              alt="Rows of utility-scale solar panels under bright midday sun"
              className="h-full w-full object-cover"
              style={{
                transform: mounted ? 'scale(1)' : 'scale(1.1)',
                transition: 'transform 1400ms ease-out 500ms',
              }}
            />
            <div
              className="absolute inset-0"
              style={{
                background:
                  'linear-gradient(to top, rgba(181,115,9,0.55), transparent 55%)',
              }}
            />
            <p className="absolute bottom-4 left-4 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-white/90">
              Utility PV · Atacama
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
