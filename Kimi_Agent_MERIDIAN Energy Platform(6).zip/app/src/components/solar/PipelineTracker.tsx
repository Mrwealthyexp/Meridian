import { useMemo, useState } from 'react'
import { Check, CircleDashed, Sun } from 'lucide-react'
import SectionHeader from '@/components/SectionHeader'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet'
import { useInView } from '@/lib/animation'
import { cn } from '@/lib/utils'
import { PROJECTS, REGIONS } from './data'
import type { Project, ProjectStatus } from './data'
import { EASE, FillBar, useMediaQuery } from './shared'

type StatusFilter = 'ALL' | ProjectStatus

const STATUS_PILL: Record<ProjectStatus, string> = {
  PERMITTED: 'bg-bronze/10 text-bronze',
  'UNDER CONSTRUCTION': 'bg-solar/15 text-solar-deep',
  'GRID-TIED': 'bg-positive/10 text-positive',
}

const TIMELINE_STEPS: { key: keyof Project['timeline']; label: string }[] = [
  { key: 'permit', label: 'Permit Granted' },
  { key: 'construction', label: 'Construction Start' },
  { key: 'gridTie', label: 'Grid Tie' },
]

function ProjectDetail({ project }: { project: Project }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Capacity', value: `${project.capacity.toFixed(1)} GW` },
          { label: 'Capex', value: project.capex },
          { label: 'COD', value: project.cod },
        ].map((s) => (
          <div key={s.label} className="rounded-lg border border-border bg-muted/40 p-3">
            <p className="font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
              {s.label}
            </p>
            <p className="mt-1 font-mono text-sm font-semibold tabular-nums text-foreground">
              {s.value}
            </p>
          </div>
        ))}
      </div>

      {/* Mini timeline */}
      <div>
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          Project Timeline
        </p>
        <div className="mt-4 space-y-0">
          {TIMELINE_STEPS.map((step, i) => {
            const done =
              project.status === 'GRID-TIED' ||
              (project.status === 'UNDER CONSTRUCTION' && i < 2) ||
              (project.status === 'PERMITTED' && i === 0)
            const currentStatus =
              (project.status === 'UNDER CONSTRUCTION' && i === 1) ||
              (project.status === 'PERMITTED' && i === 1)
            return (
              <div key={step.key} className="relative flex gap-3 pb-6 last:pb-0">
                {i < TIMELINE_STEPS.length - 1 && (
                  <span
                    className={cn(
                      'absolute left-[9px] top-5 h-[calc(100%-16px)] w-px',
                      done ? 'bg-solar' : 'bg-border',
                    )}
                  />
                )}
                <span
                  className={cn(
                    'mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border',
                    done
                      ? 'border-solar bg-solar text-foreground'
                      : currentStatus
                        ? 'border-solar text-solar-deep'
                        : 'border-border text-muted-foreground',
                  )}
                >
                  {done ? (
                    <Check className="h-3 w-3" />
                  ) : currentStatus ? (
                    <Sun className="h-3 w-3" />
                  ) : (
                    <CircleDashed className="h-3 w-3" />
                  )}
                </span>
                <div>
                  <p className="font-sans text-sm font-medium text-foreground">{step.label}</p>
                  <p className="font-mono text-[11px] font-medium tracking-[0.08em] text-muted-foreground">
                    {project.timeline[step.key]}
                  </p>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      <div>
        <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          Build Progress · {project.progress}%
        </p>
        <FillBar value={project.progress} active duration={800} color="#E9A319" className="mt-2" />
      </div>

      <p className="text-sm leading-[1.65] text-muted-foreground">{project.note}</p>
      <p className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground/70">
        Meridian Solar Desk · Sample Project Note
      </p>
    </div>
  )
}

function DetailHeader({ project }: { project: Project }) {
  return (
    <>
      <div className="flex items-center gap-3">
        <span
          className={cn(
            'inline-flex items-center rounded-full px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em]',
            STATUS_PILL[project.status],
          )}
        >
          {project.status}
        </span>
        <span className="font-mono text-[11px] font-medium tracking-[0.08em] text-muted-foreground">
          {project.country} · {project.region.toUpperCase()}
        </span>
      </div>
      <SheetTitle className="font-display text-2xl font-medium">{project.name}</SheetTitle>
      <SheetDescription className="font-mono text-[11px] uppercase tracking-[0.12em]">
        Utility-Scale PV · Sample Data
      </SheetDescription>
    </>
  )
}

export default function PipelineTracker() {
  const [ref, inView] = useInView<HTMLDivElement>(0.1)
  const [region, setRegion] = useState<string>('ALL')
  const [status, setStatus] = useState<StatusFilter>('ALL')
  const [selected, setSelected] = useState<Project | null>(null)
  const isDesktop = useMediaQuery('(min-width: 768px)')

  const filtered = useMemo(
    () =>
      PROJECTS.filter(
        (p) =>
          (region === 'ALL' || p.region === region) &&
          (status === 'ALL' || p.status === status),
      ),
    [region, status],
  )

  return (
    <section className="mt-20 bg-muted/40 py-24">
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 md:px-10">
        <SectionHeader
          eyebrow="// PIPELINE TRACKER"
          eyebrowTone="solar"
          title={
            <>
              612 GW in motion. <em className="italic">Every project accounted for.</em>
            </>
          }
          lede="Flagship utility-scale projects under Meridian coverage — filter by region and build status, open any row for the full project brief."
        />

        {/* Filter row */}
        <div className="mt-10 flex flex-wrap items-center gap-4">
          <Select value={region} onValueChange={setRegion}>
            <SelectTrigger className="w-[210px] bg-card font-mono text-xs uppercase tracking-[0.08em]">
              <SelectValue placeholder="All regions" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL" className="font-mono text-xs">ALL REGIONS</SelectItem>
              {REGIONS.map((r) => (
                <SelectItem key={r} value={r} className="font-mono text-xs">
                  {r.toUpperCase()}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <ToggleGroup
            type="single"
            value={status}
            onValueChange={(v) => setStatus((v as StatusFilter) || 'ALL')}
            className="rounded-lg border border-border bg-card"
          >
            {(['ALL', 'PERMITTED', 'UNDER CONSTRUCTION', 'GRID-TIED'] as const).map((s) => (
              <ToggleGroupItem
                key={s}
                value={s}
                className="px-3 font-mono text-[10px] tracking-[0.06em] data-[state=on]:bg-solar data-[state=on]:text-foreground"
              >
                {s}
              </ToggleGroupItem>
            ))}
          </ToggleGroup>

          <span className="ml-auto font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
            Showing {filtered.length} of {PROJECTS.length} projects
          </span>
        </div>

        {/* Table */}
        <div className="mt-6 overflow-hidden rounded-xl border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                {['Project', 'Country', 'Capacity', 'Status', 'COD', 'Progress'].map((h) => (
                  <TableHead
                    key={h}
                    className="font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground"
                  >
                    {h}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody
              key={`${region}-${status}`}
              className="animate-in fade-in duration-300"
            >
              {filtered.map((p, i) => {
                const rowDelay = i * 70
                return (
                  <TableRow
                    key={p.id}
                    onClick={() => setSelected(p)}
                    className="cursor-pointer"
                    style={{
                      opacity: inView ? 1 : 0,
                      transform: inView ? 'none' : 'translateY(12px)',
                      transition: `opacity 600ms ${EASE} ${rowDelay}ms, transform 600ms ${EASE} ${rowDelay}ms`,
                    }}
                  >
                    <TableCell className="font-sans text-sm font-semibold text-foreground">
                      {p.name}
                    </TableCell>
                    <TableCell className="font-mono text-xs tabular-nums">{p.country}</TableCell>
                    <TableCell className="font-mono text-xs font-medium tabular-nums">
                      {p.capacity.toFixed(1)} GW
                    </TableCell>
                    <TableCell>
                      <span
                        className={cn(
                          'inline-flex items-center rounded-full px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.12em]',
                          STATUS_PILL[p.status],
                        )}
                      >
                        {p.status}
                      </span>
                    </TableCell>
                    <TableCell className="font-mono text-xs tabular-nums">{p.cod}</TableCell>
                    <TableCell className="w-40">
                      <div className="flex items-center gap-2">
                        <FillBar
                          value={p.progress}
                          active={inView}
                          delay={rowDelay + 300}
                          duration={800}
                          color={p.progress === 100 ? '#2E7D4F' : '#E9A319'}
                          className="w-24"
                        />
                        <span className="font-mono text-[11px] tabular-nums text-muted-foreground">
                          {p.progress}%
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
              {filtered.length === 0 && (
                <TableRow className="hover:bg-transparent">
                  <TableCell colSpan={6} className="py-10 text-center font-mono text-xs uppercase tracking-[0.12em] text-muted-foreground">
                    No projects match the current filters
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Detail: drawer on mobile, sheet on desktop */}
      {isDesktop ? (
        <Sheet open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
          <SheetContent side="right" className="w-full overflow-y-auto bg-card sm:max-w-md">
            {selected && (
              <>
                <SheetHeader className="p-6 pb-0">
                  <DetailHeader project={selected} />
                </SheetHeader>
                <div className="p-6">
                  <ProjectDetail project={selected} />
                </div>
              </>
            )}
          </SheetContent>
        </Sheet>
      ) : (
        <Drawer open={!!selected} onOpenChange={(open) => !open && setSelected(null)}>
          <DrawerContent className="bg-card">
            {selected && (
              <>
                <DrawerHeader className="px-6 text-left">
                  <DrawerTitle className="font-display text-2xl font-medium">
                    {selected.name}
                  </DrawerTitle>
                  <DrawerDescription className="font-mono text-[11px] uppercase tracking-[0.12em]">
                    {selected.country} · {selected.region.toUpperCase()} · {selected.status}
                  </DrawerDescription>
                </DrawerHeader>
                <div className="overflow-y-auto px-6 pb-8">
                  <ProjectDetail project={selected} />
                </div>
              </>
            )}
          </DrawerContent>
        </Drawer>
      )}
    </section>
  )
}
