import { Info } from 'lucide-react'
import { Line, LineChart, ResponsiveContainer } from 'recharts'
import { DomainBadge } from '@/components/badges'
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { useCountUp, useInView } from '@/lib/animation'
import { sparkline } from './data'
import { SlideIn } from './shared'

type Kpi = {
  label: string
  value: number
  format: (v: number) => string
  delta: string
  direction: 'up' | 'down'
  /** Declining cost is good — render the delta chip in positive green. */
  goodDown?: boolean
  spark: { i: number; v: number }[]
}

const KPIS: Kpi[] = [
  {
    label: 'Global Installed Capacity',
    value: 1610,
    format: (v) => `${new Intl.NumberFormat('en-US').format(Math.round(v))} GW`,
    delta: '24% YOY',
    direction: 'up',
    spark: sparkline(7, 24, 1100, 1610),
  },
  {
    label: 'Annual Generation',
    value: 2130,
    format: (v) => `${new Intl.NumberFormat('en-US').format(Math.round(v))} TWH`,
    delta: '21% YOY',
    direction: 'up',
    spark: sparkline(19, 24, 1500, 2130),
  },
  {
    label: 'Project Pipeline',
    value: 612,
    format: (v) => `${Math.round(v)} GW`,
    delta: '9% QOQ',
    direction: 'up',
    spark: sparkline(31, 24, 480, 612),
  },
  {
    label: 'Module Price',
    value: 0.11,
    format: (v) => `$${v.toFixed(2)}/W`,
    delta: '8% YOY',
    direction: 'down',
    goodDown: true,
    spark: sparkline(43, 24, 0.19, 0.11),
  },
]

function KpiCard({ kpi, active, index }: { kpi: Kpi; active: boolean; index: number }) {
  const v = useCountUp(kpi.value, active, 1200)
  const up = kpi.direction === 'up'
  const chipTone = kpi.goodDown
    ? 'bg-positive/10 text-positive'
    : up
      ? 'bg-positive/10 text-positive'
      : 'bg-critical/10 text-critical'

  const chip = (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-mono text-[11px] font-medium tabular-nums ${chipTone}`}
    >
      {up ? '▲' : '▼'} {kpi.delta}
      {kpi.goodDown && <Info className="h-3 w-3" />}
    </span>
  )

  return (
    <SlideIn active={active} index={index} step={80} y={20} duration={600}>
      <div className="card-lift h-full rounded-xl border border-border bg-card p-6 hover:border-solar/50">
        <div className="flex items-center justify-between gap-2">
          <p className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
            {kpi.label}
          </p>
          <DomainBadge domain="solar" />
        </div>
        <p className="mt-3 font-mono text-[30px] font-medium leading-[1.1] tracking-[-0.01em] tabular-nums text-foreground">
          {kpi.format(v)}
        </p>
        <div className="mt-2">
          {kpi.goodDown ? (
            <Tooltip>
              <TooltipTrigger asChild>{chip}</TooltipTrigger>
              <TooltipContent className="bg-terminal-bg font-mono text-[10px] uppercase tracking-[0.12em] text-terminal-amber">
                Cost down = good
              </TooltipContent>
            </Tooltip>
          ) : (
            chip
          )}
        </div>
        <div className="mt-4 h-12">
          {active && (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={kpi.spark}>
                <Line
                  type="monotone"
                  dataKey="v"
                  stroke="#E9A319"
                  strokeWidth={1.5}
                  dot={false}
                  isAnimationActive
                  animationDuration={900}
                  animationEasing="ease-out"
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </SlideIn>
  )
}

export default function SolarKpiStrip() {
  const [countRef, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <section className="mx-auto max-w-[1200px] px-6 md:px-10">
      <div ref={countRef} className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {KPIS.map((kpi, i) => (
          <KpiCard key={kpi.label} kpi={kpi} active={inView} index={i} />
        ))}
      </div>
      <p className="mt-4 text-right font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground/70">
        Sample Data · Refreshed Daily
      </p>
    </section>
  )
}
