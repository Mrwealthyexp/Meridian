import { Link } from 'react-router'
import { ArrowRight } from 'lucide-react'
import Words from '@/components/home/Words'
import { useInView } from '@/lib/animation'
import { SlideIn } from './shared'

export default function SolarCta() {
  const [ref, inView] = useInView<HTMLDivElement>(0.2)

  return (
    <section className="pb-32">
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 text-center md:px-10">
        <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-solar-deep">
          // The Intersection
        </p>
        <h2 className="mx-auto mt-4 max-w-2xl font-display text-3xl font-medium leading-[1.1] tracking-[-0.01em] text-foreground md:text-[40px]">
          <Words
            active={inView}
            stagger={50}
            segments={[
              { text: 'Solar doesn\u2019t replace oil data —' },
              { text: 'it completes it.', italic: true },
            ]}
          />
        </h2>
        <SlideIn active={inView} delayBase={400} y={16} duration={600}>
          <p className="mx-auto mt-5 max-w-xl text-[17px] leading-[1.6] text-muted-foreground md:text-lg">
            See where Meridian&rsquo;s combined oil + solar intelligence becomes a
            service your organization needs.
          </p>
        </SlideIn>
        <SlideIn active={inView} delayBase={650} y={16} duration={600}>
          <span
            className="mt-8 inline-block rounded-lg p-[2px] transition-[filter] duration-300 hover:hue-rotate-15"
            style={{ background: 'linear-gradient(90deg, #0E5A50, #E9A319)' }}
          >
            <Link
              to="/services"
              className="group inline-flex items-center gap-2 rounded-md bg-foreground px-6 py-3.5 font-sans text-[15px] font-semibold text-terminal-text transition-transform active:scale-[0.97]"
            >
              Where we&rsquo;re needed
              <ArrowRight className="h-4 w-4 text-terminal-amber transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </span>
        </SlideIn>
      </div>
    </section>
  )
}
