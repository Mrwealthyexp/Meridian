import SectionHeader from '@/components/SectionHeader'
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from '@/components/ui/hover-card'
import { useInView } from '@/lib/animation'
import { HOTSPOTS } from './data'
import { SlideIn } from './shared'

const STAT_CHIPS = [
  '2,300 KWH/M² PEAK GHI',
  '14 SITING CRITERIA',
  '120 MARKETS SCORED',
]

export default function IrradianceMap() {
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <section className="py-24">
      <div
        ref={ref}
        className="mx-auto grid max-w-[1200px] items-center gap-16 px-6 md:px-10 lg:grid-cols-2"
      >
        {/* Map */}
        <div className="relative">
          <div className="relative aspect-[2/1] w-full">
            {/* Amber-tinted dot map (mask keeps true amber hue at 25% alpha) */}
            <div
              aria-hidden
              className="absolute inset-0"
              style={{
                backgroundColor: '#E9A319',
                opacity: 0.25,
                WebkitMaskImage: 'url(/world-dots.svg)',
                maskImage: 'url(/world-dots.svg)',
                WebkitMaskSize: 'contain',
                maskSize: 'contain',
                WebkitMaskRepeat: 'no-repeat',
                maskRepeat: 'no-repeat',
                WebkitMaskPosition: 'center',
                maskPosition: 'center',
                transform: inView ? 'scale(1)' : 'scale(0.96)',
                transition: 'transform 400ms cubic-bezier(0.22,1,0.36,1)',
              }}
            />
            {/* Hotspots */}
            {HOTSPOTS.map((h, i) => (
              <div
                key={h.id}
                className="absolute"
                style={{ left: `${h.x}%`, top: `${h.y}%`, transform: 'translate(-50%, -50%)' }}
              >
                <HoverCard openDelay={100}>
                  <HoverCardTrigger asChild>
                    <button
                      aria-label={`${h.label} — GHI ${h.ghi} kWh/m²/yr`}
                      className="relative flex items-center justify-center"
                      style={{ width: h.size * 3, height: h.size * 3 }}
                    >
                      <span
                        className="absolute inset-0 animate-pulse-ring rounded-full bg-solar/50"
                        style={{ animationDelay: `${i * 400}ms` }}
                      />
                      <span
                        className="relative rounded-full bg-solar shadow-[0_0_12px_rgba(233,163,25,0.8)]"
                        style={{ width: h.size, height: h.size }}
                      />
                    </button>
                  </HoverCardTrigger>
                  <HoverCardContent className="w-52 border-terminal-border bg-terminal-bg p-3">
                    <p className="font-sans text-sm font-semibold text-terminal-text">{h.label}</p>
                    <p className="mt-1 font-mono text-[11px] font-medium tracking-[0.08em] text-terminal-amber">
                      GHI {h.ghi} KWH/M²/YR · {h.cls}
                    </p>
                  </HoverCardContent>
                </HoverCard>
              </div>
            ))}
          </div>
          <p className="mt-3 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
            Global Horizontal Irradiance · Hotspot Size = Irradiance Class · Sample Data
          </p>
        </div>

        {/* Explainer */}
        <div>
          <SlideIn active={inView} y={24} duration={700}>
            <SectionHeader
              eyebrow="// IRRADIANCE INTELLIGENCE"
              eyebrowTone="solar"
              title={
                <>
                  We know where the sun <em className="italic">works hardest</em>.
                </>
              }
            />
            <p className="mt-5 max-w-xl text-[17px] leading-[1.6] text-muted-foreground">
              Global horizontal irradiance data, land-use overlays, and
              grid-proximity scoring power our siting models — the same models
              that flag where solar replaces diesel and crude burn first.
            </p>
          </SlideIn>
          <div className="mt-8 flex flex-wrap gap-3">
            {STAT_CHIPS.map((chip, i) => (
              <span
                key={chip}
                className="inline-flex items-center rounded-full border border-solar/40 bg-solar/10 px-4 py-2 font-mono text-[11px] font-semibold tracking-[0.1em] text-solar-deep"
                style={{
                  transform: inView ? 'scale(1)' : 'scale(0.9)',
                  opacity: inView ? 1 : 0,
                  transition: `transform 400ms cubic-bezier(0.22,1,0.36,1) ${400 + i * 100}ms, opacity 400ms cubic-bezier(0.22,1,0.36,1) ${400 + i * 100}ms`,
                }}
              >
                {chip}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
