import { cn } from '@/lib/utils'

type Segment = { text: string; italic?: boolean }

/**
 * Word-level masked slide-up headline (§4.4). Splits segments into words,
 * each sliding up inside an overflow-hidden mask with a 60ms stagger once
 * `active` flips true.
 */
export default function Words({
  segments,
  active,
  delayStart = 0,
  stagger = 60,
  className,
}: {
  segments: Segment[]
  active: boolean
  delayStart?: number
  stagger?: number
  className?: string
}) {
  let index = 0
  return (
    <span className={cn(active && 'words-in', className)}>
      {segments.map((seg, si) => (
        <span key={si} className={seg.italic ? 'italic' : undefined}>
          {seg.text.split(' ').map((word, wi) => {
            const delay = delayStart + index++ * stagger
            return (
              <span key={wi} className="word-mask">
                <span style={{ ['--word-delay' as string]: `${delay}ms` }}>{word}</span>
                {wi < seg.text.split(' ').length - 1 ? ' ' : ''}
              </span>
            )
          })}
          {si < segments.length - 1 ? ' ' : ''}
        </span>
      ))}
    </span>
  )
}
