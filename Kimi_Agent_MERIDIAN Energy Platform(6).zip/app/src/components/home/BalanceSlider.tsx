import { useCallback, useRef } from 'react'
import type { KeyboardEvent, PointerEvent } from 'react'
import { cn } from '@/lib/utils'

/**
 * Signature Oil↔Solar Balance Slider (home hero).
 * Custom drag control (pointer events) + keyboard arrows (±5), driving a
 * 0–100 state lifted to the parent (glow cross-fade, stat swap, eyebrow tint).
 */
export default function BalanceSlider({
  value,
  onChange,
}: {
  value: number
  onChange: (v: number) => void
}) {
  const trackRef = useRef<HTMLDivElement | null>(null)

  const setFromClientX = useCallback(
    (clientX: number) => {
      const track = trackRef.current
      if (!track) return
      const rect = track.getBoundingClientRect()
      const v = Math.round(((clientX - rect.left) / rect.width) * 100)
      onChange(Math.min(100, Math.max(0, v)))
    },
    [onChange],
  )

  const onPointerDown = (e: PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId)
    setFromClientX(e.clientX)
  }
  const onPointerMove = (e: PointerEvent<HTMLDivElement>) => {
    if (e.buttons & 1) setFromClientX(e.clientX)
  }
  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') {
      e.preventDefault()
      onChange(Math.max(0, value - 5))
    } else if (e.key === 'ArrowRight' || e.key === 'ArrowUp') {
      e.preventDefault()
      onChange(Math.min(100, value + 5))
    }
  }

  const needleDeg = (value / 100) * 180 - 90
  const oilActive = value <= 49
  const solarActive = value >= 51
  const leftOpacity = Math.max(0.25, 1 - value / 100)
  const rightOpacity = Math.max(0.25, value / 100)

  return (
    <div className="rounded-xl border border-border bg-card/80 p-6 backdrop-blur">
      {/* Track + thumb */}
      <div className="flex items-center gap-4">
        <span className="shrink-0 font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-oil">
          ◀ Crude
        </span>
        <div
          ref={trackRef}
          role="slider"
          tabIndex={0}
          aria-label="Oil to solar balance"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={value}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onKeyDown={onKeyDown}
          className="relative h-6 flex-1 cursor-ew-resize touch-none select-none rounded-full focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
        >
          <div
            className="absolute inset-x-0 top-1/2 h-1.5 -translate-y-1/2 rounded-full"
            style={{
              background: 'linear-gradient(90deg, #0E5A50, #171410 50%, #E9A319)',
            }}
          />
          <div
            className="absolute top-1/2 h-7 w-7 -translate-x-1/2 -translate-y-1/2 rounded-full ring-2 ring-foreground"
            style={{
              left: `${value}%`,
              background: 'linear-gradient(90deg, #0E5A50 50%, #E9A319 50%)',
              boxShadow: '0 1px 4px rgba(23,20,16,0.3)',
              transition: 'box-shadow 200ms ease-out',
            }}
          />
        </div>
        <span className="shrink-0 font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-solar-deep">
          Solar ▶
        </span>
      </div>

      {/* Dial readout row */}
      <div className="mt-5 grid grid-cols-3 items-center gap-4">
        <div
          className={cn(
            'font-mono text-[13px] tabular-nums transition-colors duration-300',
            oilActive ? 'text-oil' : 'text-muted-foreground',
          )}
          style={{ opacity: leftOpacity }}
        >
          <span className="block text-[10px] font-medium uppercase tracking-[0.14em] opacity-70">
            WTI Crude
          </span>
          $78.42 · ▲0.8%
        </div>

        {/* Needle dial */}
        <svg viewBox="0 0 100 54" className="mx-auto h-12 w-24" aria-hidden>
          <path
            d="M8 50 A 42 42 0 0 1 92 50"
            fill="none"
            stroke="#E2DACB"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="M8 50 A 42 42 0 0 1 50 8"
            fill="none"
            stroke="#0E5A50"
            strokeWidth="3"
            strokeLinecap="round"
            opacity="0.55"
          />
          <path
            d="M50 8 A 42 42 0 0 1 92 50"
            fill="none"
            stroke="#E9A319"
            strokeWidth="3"
            strokeLinecap="round"
            opacity="0.55"
          />
          <g
            style={{
              transform: `rotate(${needleDeg}deg)`,
              transformOrigin: '50px 50px',
              transition: 'transform 300ms cubic-bezier(0.34,1.56,0.64,1)',
            }}
          >
            <line x1="50" y1="50" x2="50" y2="14" stroke="#171410" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="50" cy="50" r="4" fill="#171410" />
          </g>
        </svg>

        <div
          className={cn(
            'text-right font-mono text-[13px] tabular-nums transition-colors duration-300',
            solarActive ? 'text-solar-deep' : 'text-muted-foreground',
          )}
          style={{ opacity: rightOpacity }}
        >
          <span className="block text-[10px] font-medium uppercase tracking-[0.14em] opacity-70">
            PV Index
          </span>
          142.6 · ▲1.9%
        </div>
      </div>

      <p className="mt-4 text-center font-mono text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
        Drag to explore both worlds
      </p>
    </div>
  )
}
