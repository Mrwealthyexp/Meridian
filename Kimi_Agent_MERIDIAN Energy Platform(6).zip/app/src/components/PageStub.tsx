import SectionHeader from '@/components/SectionHeader'

/** Simple placeholder stub for sub-pages owned by page agents. */
export default function PageStub({
  eyebrow,
  title,
  lede,
}: {
  eyebrow: string
  title: string
  lede: string
}) {
  return (
    <div className="mx-auto max-w-[1200px] px-6 py-24 md:px-10">
      <p className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        Home / {title}
      </p>
      <div className="mt-6">
        <SectionHeader eyebrow={eyebrow} title={title} lede={lede} />
      </div>
    </div>
  )
}
