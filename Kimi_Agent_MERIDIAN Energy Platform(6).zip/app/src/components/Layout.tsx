import { useEffect } from 'react'
import { Outlet, useLocation } from 'react-router'
import Navbar from '@/components/Navbar'
import TickerStrip from '@/components/TickerStrip'
import Footer from '@/components/Footer'
import { Toaster } from '@/components/ui/sonner'

/**
 * Shared site chrome. Uses the nested-route pattern (renders <Outlet />),
 * so App.tsx must nest all routes under a <Route element={<Layout/>}>.
 * The ticker + navbar sit in one sticky unit in normal document flow, so
 * pages never need to compensate for nav height.
 */
export default function Layout() {
  const location = useLocation()

  // §4.3 — scroll reset on navigation; hash links smooth-scroll to target
  useEffect(() => {
    if (location.hash) {
      const id = location.hash.slice(1)
      // wait a tick so the target page has rendered
      requestAnimationFrame(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
      })
    } else {
      window.scrollTo(0, 0)
    }
  }, [location.pathname, location.hash])

  return (
    <div className="flex min-h-[100dvh] flex-col">
      <header className="sticky top-0 z-50">
        <TickerStrip />
        <Navbar />
      </header>
      <main className="flex-1">
        <div key={location.pathname} className="page-enter">
          <Outlet />
        </div>
      </main>
      <Footer />
      <Toaster position="bottom-right" />
    </div>
  )
}
