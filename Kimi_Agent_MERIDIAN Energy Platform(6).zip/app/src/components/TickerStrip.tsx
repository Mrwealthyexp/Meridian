import { trpc } from '@/providers/trpc'
import { cn } from '@/lib/utils'

type TickerItem = {
  label: string
  value: string
  delta?: string
  direction?: 'up' | 'down'
  live?: boolean
}

/** Canonical sample figures — used as fallback and for non-benchmark items. */
const FALLBACK: Record<string, TickerItem> = {
  WTI: { label: 'WTI', value: '$78.42', delta: '▲0.8%', direction: 'up' },
  BRENT: { label: 'BRENT', value: '$82.11', delta: '▼0.3%', direction: 'down' },
}

const STATIC_ITEMS: TickerItem[] = [
  { label: 'SOLAR PV INDEX', value: '142.6', delta: '▲1.9%', direction: 'up' },
  { label: 'POLYSILICON', value: '$8.9/kg' },
  { label: 'SPR', value: '372M BBL' },
  { label: 'GLOBAL PV PIPELINE', value: '612GW' },
]

function formatDelta(changePct: number): Pick<TickerItem, 'delta' | 'direction'> {
  const up = changePct >= 0
  return {
    delta: `${up ? '▲' : '▼'}${Math.abs(changePct).toFixed(1)}%`,
    direction: up ? 'up' : 'down',
  }
}

function TickerGroup({ items }: { items: TickerItem[] }) {
  return (
    <div className="flex shrink-0 items-center">
      {items.map((item) => (
        <span
          key={item.label}
          className="flex items-center gap-2 border-r border-terminal-border px-5 font-mono text-[13px] tracking-[0.04em] text-terminal-text/80"
        >
          <span className="text-terminal-text/50">
            {item.label}
            {item.live && <span className="text-terminal-amber"> •</span>}
          </span>
          <span className="tabular-nums">{item.value}</span>
          {item.delta && (
            <span
              className={cn(
                'tabular-nums',
                item.direction === 'up' ? 'text-positive' : 'text-critical',
              )}
            >
              {item.delta}
            </span>
          )}
        </span>
      ))}
    </div>
  )
}

export default function TickerStrip() {
  const quotes = trpc.energy.quotes.useQuery(undefined, {
    refetchInterval: 60_000,
    staleTime: 55_000,
    retry: 1,
  })

  const benchmarkItems: TickerItem[] = ['WTI', 'BRENT'].map((label) => {
    const live = quotes.data?.quotes.find((q) => q?.label === label)
    if (live) {
      return {
        label,
        value: `$${live.price.toFixed(2)}`,
        ...formatDelta(live.changePct),
        live: true,
      }
    }
    return FALLBACK[label]
  })

  const items = [...benchmarkItems, ...STATIC_ITEMS]
  const isLive = quotes.data?.live === true

  return (
    <div className="flex h-9 items-stretch overflow-hidden bg-terminal-bg">
      <div className="relative min-w-0 flex-1 overflow-hidden">
        <div className="marquee-track h-full items-center">
          <TickerGroup items={items} />
          <TickerGroup items={items} />
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-2 border-l border-terminal-border bg-terminal-bg px-4">
        <span
          className={cn(
            'h-1.5 w-1.5 animate-pulse-dot rounded-full',
            isLive ? 'bg-positive' : 'bg-terminal-amber',
          )}
        />
        <span className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-terminal-text/70">
          {isLive ? 'Live · Market Data' : 'Live · Sample Data'}
        </span>
      </div>
    </div>
  )
}
