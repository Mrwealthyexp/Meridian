import { cn } from '@/lib/utils'

type Domain = 'solar' | 'oil' | 'intersection'

const DOMAIN_STYLES: Record<Domain, string> = {
  solar: 'bg-solar/12 text-solar-deep',
  oil: 'bg-oil/12 text-oil',
  intersection:
    'border border-transparent bg-[linear-gradient(90deg,rgba(14,90,80,0.12),rgba(233,163,25,0.12))] [background-clip:padding-box]',
}

/** Pill domain badge — mono 10px uppercase (§5.6). */
export function DomainBadge({
  domain,
  className,
}: {
  domain: Domain
  className?: string
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em]',
        DOMAIN_STYLES[domain],
        className,
      )}
    >
      {domain}
    </span>
  )
}

/** ▲/▼ delta chip — bg at 10% alpha, colored text (§5.6). */
export function DeltaChip({
  value,
  direction,
  className,
}: {
  value: string
  direction: 'up' | 'down'
  className?: string
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-mono text-[11px] font-medium tabular-nums',
        direction === 'up' ? 'bg-positive/10 text-positive' : 'bg-critical/10 text-critical',
        className,
      )}
    >
      {direction === 'up' ? '▲' : '▼'} {value}
    </span>
  )
}
