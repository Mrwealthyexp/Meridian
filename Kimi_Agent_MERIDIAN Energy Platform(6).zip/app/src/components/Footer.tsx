import { useState } from 'react'
import type { FormEvent } from 'react'
import { Link } from 'react-router'
import { Github, Linkedin, Twitter } from 'lucide-react'
import { toast } from 'sonner'
import { trpc } from '@/providers/trpc'
import { Logo } from '@/components/Navbar'

const COLUMNS: { title: string; links: { label: string; to: string }[] }[] = [
  {
    title: 'Platform',
    links: [
      { label: 'Dashboard', to: '/dashboard' },
      { label: 'Oil Supply', to: '/oil-supply' },
      { label: 'Solar Energy', to: '/solar-energy' },
      { label: 'Services', to: '/services' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About', to: '/about' },
      { label: 'Methodology', to: '/about' },
      { label: 'Careers', to: '/about' },
      { label: 'Contact', to: '/about#contact' },
    ],
  },
  {
    title: 'Resources',
    links: [
      { label: 'Insights', to: '/insights' },
      { label: 'API Docs', to: '/insights' },
      { label: 'Sample Data', to: '/dashboard' },
      { label: 'Changelog', to: '/insights' },
    ],
  },
]

export default function Footer() {
  const [email, setEmail] = useState('')

  const subscribeMutation = trpc.forms.subscribe.useMutation({
    onSuccess: () => toast.success("You're on the list."),
    onError: () => toast.error('Subscription failed — please try again.'),
  })

  const subscribe = (e: FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return
    subscribeMutation.mutate({ email: email.trim(), source: 'footer' })
    setEmail('')
  }

  return (
    <footer className="relative bg-terminal-bg text-terminal-text">
      <div
        className="h-0.5 w-full"
        style={{ background: 'linear-gradient(90deg, #E9A319, #0E5A50)' }}
      />
      <div className="mx-auto max-w-[1360px] px-6 pb-10 pt-16 md:px-10">
        {/* Giant wordmark */}
        <div
          aria-hidden
          className="select-none font-display text-[64px] font-medium leading-none text-terminal-text/10 md:text-[96px]"
        >
          MERIDIAN
        </div>

        <div className="mt-12 grid gap-10 md:grid-cols-2 lg:grid-cols-5">
          <div className="lg:col-span-1">
            <Logo dark />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-terminal-text/50">
              From crude to photons — intelligence for the whole energy system.
            </p>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h4 className="font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-terminal-text/40">
                {col.title}
              </h4>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.to}
                      className="text-sm text-terminal-text/70 transition-colors hover:text-terminal-amber"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div>
            <h4 className="font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-terminal-text/40">
              Newsletter
            </h4>
            <form onSubmit={subscribe} className="mt-4 flex gap-2">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@office.gov"
                className="min-w-0 flex-1 rounded-md border border-terminal-border bg-terminal-surface px-3 py-2 font-mono text-sm text-terminal-text placeholder:text-terminal-text/30 focus:outline-none focus:ring-1 focus:ring-terminal-amber"
              />
              <button
                type="submit"
                className="shrink-0 rounded-md bg-solar px-3 py-2 font-sans text-sm font-semibold text-foreground transition-colors hover:bg-terminal-amber"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-4 border-t border-terminal-border pt-6 md:flex-row md:items-center md:justify-between">
          <p className="font-mono text-[11px] tracking-[0.06em] text-terminal-text/40">
            © 2025 MERIDIAN ENERGY INTELLIGENCE · PRESENTED BY{' '}
            <span className="text-terminal-amber">$WEX</span> — ALL FIGURES ARE SAMPLE DATA FOR
            DEMONSTRATION
          </p>
          <div className="flex items-center gap-4">
            {[Linkedin, Twitter, Github].map((Icon, i) => (
              <a
                key={i}
                href="#"
                aria-label="Social link"
                className="text-terminal-text/50 transition-colors hover:text-terminal-amber"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
