import { Combine, FunctionSquare, Satellite, Send } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import Rise from '@/components/about/Rise'
import SectionHeader from '@/components/SectionHeader'
import { useCountUp, useInView } from '@/lib/animation'

type Step = {
  n: number
  title: string
  body: string
  icon: LucideIcon
}

const STEPS: Step[] = [
  {
    n: 1,
    title: 'Collect',
    body: 'Terminal feeds, satellite tank-top reads, grid operators, permit registries.',
    icon: Satellite,
  },
  {
    n: 2,
    title: 'Normalize',
    body: '46 nations, 120 markets, one schema — oil and solar side by side.',
    icon: Combine,
  },
  {
    n: 3,
    title: 'Model',
    body: 'Scenario engines for supply shocks, ramps, and mix transitions.',
    icon: FunctionSquare,
  },
  {
    n: 4,
    title: 'Deliver',
    body: 'APIs, dashboards, briefings, and analysts on call.',
    icon: Send,
  },
]

function StepCard({
  step,
  index,
  active,
}: {
  step: Step
  index: number
  active: boolean
}) {
  const numeral = useCountUp(step.n, active, 900)
  const Icon = step.icon
  const delay = index * 120

  return (
    <div className="relative">
      {/* Dashed connector — draws after adjacent cards land (desktop only) */}
      {index > 0 && (
        <span
          aria-hidden
          className="absolute -left-6 top-14 hidden h-px w-6 origin-left border-t border-dashed border-muted-foreground/40 lg:block"
          style={{
            transform: active ? 'scaleX(1)' : 'scaleX(0)',
            transition: `transform 500ms cubic-bezier(0.22,1,0.36,1) ${delay + 450}ms`,
          }}
        />
      )}
      <Rise active={active} delay={delay} y={24} duration={700} className="h-full">
        <div className="card-lift group h-full rounded-xl border border-border bg-card p-6 hover:border-solar/50">
          <div className="flex items-start justify-between">
            <span className="font-mono text-4xl font-medium tabular-nums text-muted-foreground/40">
              {String(Math.round(numeral)).padStart(2, '0')}
            </span>
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted text-oil transition-colors duration-250 group-hover:bg-solar/15 group-hover:text-solar-deep">
              <Icon className="h-5 w-5" />
            </span>
          </div>
          <h3 className="mt-5 font-sans text-lg font-semibold leading-[1.25] text-foreground">
            {step.title}
          </h3>
          <p className="mt-2 text-sm leading-[1.6] text-muted-foreground">{step.body}</p>
        </div>
      </Rise>
    </div>
  )
}

/** §3 — Methodology: four steps from signal to decision. */
export default function Methodology() {
  const [ref, inView] = useInView<HTMLDivElement>(0.2)

  return (
    <section className="bg-muted/40 py-24">
      <div className="mx-auto max-w-[1200px] px-6 md:px-10">
        <SectionHeader
          align="center"
          eyebrow="// METHODOLOGY"
          title={
            <>
              How a signal becomes <span className="italic">a decision</span>.
            </>
          }
        />
        <div ref={ref} className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((step, i) => (
            <StepCard key={step.n} step={step} index={i} active={inView} />
          ))}
        </div>
      </div>
    </section>
  )
}
