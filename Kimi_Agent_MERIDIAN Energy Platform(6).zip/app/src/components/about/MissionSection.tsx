import { useEffect, useState } from 'react'
import Rise from '@/components/about/Rise'
import { useInView } from '@/lib/animation'

/** §2 — Mission copy + pull-quote, team image with wipe reveal. */
export default function MissionSection() {
  const [ref, inView] = useInView<HTMLDivElement>(0.2)
  const [imgRef, imgInView] = useInView<HTMLDivElement>(0.25)
  const [imgOn, setImgOn] = useState(false)

  useEffect(() => {
    if (!imgInView) return
    const raf = requestAnimationFrame(() => setImgOn(true))
    return () => cancelAnimationFrame(raf)
  }, [imgInView])

  return (
    <section className="mx-auto max-w-[1200px] px-6 py-24 md:px-10">
      <div className="grid items-center gap-16 lg:grid-cols-2">
        {/* Left — staggered 120ms, rise 20px */}
        <div ref={ref}>
          <Rise active={inView} y={20} duration={700}>
            <p className="flex items-center gap-3 font-mono text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              <span className="h-px w-8 bg-solar" aria-hidden />
              // OUR MISSION
            </p>
          </Rise>
          <Rise active={inView} delay={120} y={20} duration={700}>
            <h2 className="mt-4 font-display text-3xl font-medium leading-[1.1] tracking-[-0.01em] text-foreground md:text-[42px]">
              Intelligence is the <span className="italic">first fuel</span> of the transition.
            </h2>
          </Rise>
          <Rise active={inView} delay={240} y={20} duration={700}>
            <p className="mt-6 text-base leading-[1.65] text-muted-foreground">
              Meridian was founded on a simple observation: oil supply security and solar
              scale-up are one problem, not two. The ministries, traders, and operators who
              watch crude flows are the same organizations now signing gigawatts of PV — and
              they were reading them in separate rooms, on separate terminals, with separate
              models.
            </p>
          </Rise>
          <Rise active={inView} delay={360} y={20} duration={700}>
            <p className="mt-4 text-base leading-[1.65] text-muted-foreground">
              We build the data feeds, scenario models, and advisory practice that put both
              systems on one desk — for governments, traders, and infrastructure operators who
              need the whole picture, measured the same way.
            </p>
          </Rise>

          {/* Pull-quote — border draws scaleY 0→1, then text fades in */}
          <Rise active={inView} delay={480} y={20} duration={700}>
            <div className="relative mt-8 pl-6">
              <span
                aria-hidden
                className="absolute left-0 top-0 h-full w-[3px] origin-top bg-solar"
                style={{
                  transform: inView ? 'scaleY(1)' : 'scaleY(0)',
                  transition: 'transform 600ms cubic-bezier(0.22,1,0.36,1) 600ms',
                }}
              />
              <blockquote
                style={{
                  opacity: inView ? 1 : 0,
                  transition: 'opacity 600ms ease-out 900ms',
                }}
              >
                <p className="font-display text-[22px] italic leading-[1.4] text-foreground">
                  “You cannot manage a transition you cannot measure.”
                </p>
                <cite className="mt-3 block font-mono text-[11px] not-italic uppercase tracking-[0.14em] text-muted-foreground">
                  — Meridian Founding Memo, 2019
                </cite>
              </blockquote>
            </div>
          </Rise>
        </div>

        {/* Right — image wipe-reveal: clip-path inset + scale 1.08→1, 900ms */}
        <div ref={imgRef}>
          <figure
            className="relative overflow-hidden rounded-xl"
            style={{
              clipPath: imgOn ? 'inset(0 0 0 0)' : 'inset(0 100% 0 0)',
              transition: 'clip-path 900ms cubic-bezier(0.22,1,0.36,1)',
            }}
          >
            <img
              src="/about-team.jpg"
              alt="Meridian analysts around a table with charts and monitors"
              className="aspect-[16/9] w-full object-cover"
              style={{
                transform: imgOn ? 'scale(1)' : 'scale(1.08)',
                transition: 'transform 900ms cubic-bezier(0.22,1,0.36,1)',
              }}
            />
            <div
              aria-hidden
              className="absolute inset-x-0 bottom-0 h-24"
              style={{
                background: 'linear-gradient(180deg, transparent, rgba(23,20,16,0.55))',
              }}
            />
            <figcaption className="absolute bottom-4 left-5 font-mono text-[11px] uppercase tracking-[0.14em] text-terminal-text/90">
              Meridian Analyst Desk · Houston
            </figcaption>
          </figure>
        </div>
      </div>
    </section>
  )
}
