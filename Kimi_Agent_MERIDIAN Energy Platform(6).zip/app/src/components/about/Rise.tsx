import { useEffect, useState } from 'react'
import type { CSSProperties, ReactNode } from 'react'

const EASE = 'cubic-bezier(0.22,1,0.36,1)'

/**
 * Rise/fade entrance. When `active` is (or becomes) true, the block
 * transitions from translate(x,y) + opacity 0 to its natural position.
 * Used for hero choreography and in-view staggered reveals.
 */
export default function Rise({
  active = true,
  delay = 0,
  duration = 700,
  x = 0,
  y = 24,
  className,
  style,
  children,
}: {
  active?: boolean
  delay?: number
  duration?: number
  x?: number
  y?: number
  className?: string
  style?: CSSProperties
  children: ReactNode
}) {
  const [on, setOn] = useState(false)

  useEffect(() => {
    if (!active) return
    const raf = requestAnimationFrame(() => setOn(true))
    return () => cancelAnimationFrame(raf)
  }, [active])

  const shown = on && active

  return (
    <div
      className={className}
      style={{
        opacity: shown ? 1 : 0,
        transform: shown ? 'none' : `translate(${x}px, ${y}px)`,
        transition: `opacity ${duration}ms ${EASE} ${delay}ms, transform ${duration}ms ${EASE} ${delay}ms`,
        ...style,
      }}
    >
      {children}
    </div>
  )
}
