import { useEffect, useState } from 'react'
import { Controller, useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Check, Mail, MapPin } from 'lucide-react'
import { toast } from 'sonner'
import { trpc } from '@/providers/trpc'
import Rise from '@/components/about/Rise'
import { useInView } from '@/lib/animation'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'

const INTERESTS = [
  'Transition Analytics',
  'Data Feeds',
  'Solar Pipeline',
  'Hybrid Advisory',
  'Market Signals',
  'Briefings',
  'Other',
]

const REF_PREFIX = 'REF #'

const accessSchema = z.object({
  name: z.string().min(2, 'ENTER YOUR NAME'),
  organization: z.string().min(2, 'ENTER YOUR ORGANIZATION'),
  email: z.email('ENTER A VALID EMAIL ADDRESS'),
  interest: z.string().min(1, 'SELECT AN AREA OF INTEREST'),
  message: z.string().min(10, 'TELL US A LITTLE MORE (10+ CHARACTERS)'),
})

type AccessValues = z.infer<typeof accessSchema>

const inputClass = (invalid: boolean) =>
  cn(
    'w-full rounded-md border bg-terminal-bg px-3.5 py-2.5 font-sans text-sm text-terminal-text placeholder:text-terminal-text/30',
    'transition-shadow duration-200 focus:outline-none focus:ring-1 focus:ring-terminal-amber',
    invalid ? 'border-critical' : 'border-terminal-border',
  )

function FieldError({ message }: { message?: string }) {
  if (!message) return null
  return (
    <p className="mt-1.5 font-mono text-[11px] tracking-[0.04em] text-critical">{message}</p>
  )
}

function FieldLabel({ htmlFor, children }: { htmlFor: string; children: string }) {
  return (
    <label
      htmlFor={htmlFor}
      className="mb-1.5 block font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-terminal-text/60"
    >
      {children}
    </label>
  )
}

/** Confirmation panel with typed-out reference code (30ms/char). */
function Confirmation({ refCode }: { refCode: string }) {
  const [on, setOn] = useState(false)
  const [typed, setTyped] = useState(0)
  const display = `${REF_PREFIX}${refCode}`

  useEffect(() => {
    const raf = requestAnimationFrame(() => setOn(true))
    return () => cancelAnimationFrame(raf)
  }, [])

  useEffect(() => {
    if (!on) return
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setTyped(display.length)
      return
    }
    const start = window.setTimeout(() => {
      const iv = window.setInterval(() => {
        setTyped((t) => {
          if (t >= display.length) {
            window.clearInterval(iv)
            return t
          }
          return t + 1
        })
      }, 30)
    }, 500)
    return () => window.clearTimeout(start)
  }, [on])

  return (
    <div
      className="flex min-h-[420px] flex-col items-center justify-center text-center"
      style={{
        opacity: on ? 1 : 0,
        transform: on ? 'none' : 'translateY(12px)',
        transition: 'opacity 400ms ease-out, transform 400ms ease-out',
      }}
    >
      <span className="flex h-14 w-14 items-center justify-center rounded-full bg-solar/15 ring-1 ring-terminal-amber/50">
        <Check className="h-6 w-6 text-terminal-amber" />
      </span>
      <h3 className="mt-6 font-display text-2xl font-medium leading-[1.2] text-terminal-text">
        Request received.
      </h3>
      <p className="mt-3 max-w-sm text-sm leading-[1.65] text-terminal-text/70">
        Our desk will reply within one business day.
      </p>
      <p className="mt-6 rounded-md border border-terminal-border bg-terminal-bg px-4 py-2 font-mono text-xs tracking-[0.1em] text-terminal-amber">
        {display.slice(0, typed)}
        {typed < display.length && <span className="animate-caret-blink">▌</span>}
      </p>
    </div>
  )
}

/** §6 — Contact: the /about#contact conversion endpoint. */
export default function ContactSection() {
  const [ref, inView] = useInView<HTMLDivElement>(0.15)
  const [refCode, setRefCode] = useState<string | null>(null)

  const submitRequest = trpc.forms.submitAccessRequest.useMutation({
    onSuccess: (data) => setRefCode(data.refCode),
    onError: () =>
      toast.error('Submission failed — please try again in a moment.'),
  })

  const {
    register,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<AccessValues>({
    resolver: zodResolver(accessSchema),
    defaultValues: { name: '', organization: '', email: '', interest: '', message: '' },
  })

  const onSubmit = handleSubmit((values) => submitRequest.mutate(values))

  return (
    <section id="contact" className="scroll-mt-28 bg-terminal-bg py-24">
      <div
        ref={ref}
        className="mx-auto grid max-w-[1200px] gap-16 px-6 md:px-10 lg:grid-cols-2"
      >
        {/* Left — pitch */}
        <Rise active={inView} y={24} duration={700}>
          <p className="flex items-center gap-3 font-mono text-xs font-semibold uppercase tracking-[0.18em] text-terminal-amber">
            <span className="h-px w-8 bg-terminal-amber" aria-hidden />
            // REQUEST ACCESS
          </p>
          <h2 className="mt-4 font-display text-3xl font-medium leading-[1.1] tracking-[-0.01em] text-terminal-text md:text-[40px]">
            Tell us where you&rsquo;re <span className="italic">exposed</span>.
          </h2>
          <p className="mt-5 max-w-md text-[15px] leading-[1.65] text-terminal-text/70">
            Whether your exposure is a crude chokepoint, a solar ramp, or the spread between
            them — our desks will scope it with you.
          </p>
          <p className="mt-6 inline-flex rounded-full border border-terminal-border px-3.5 py-1.5 font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-terminal-amber">
            Replies within 1 business day
          </p>
          <div className="mt-10 space-y-4">
            <p className="flex items-center gap-3 font-mono text-xs tracking-[0.08em] text-terminal-text/70">
              <Mail className="h-4 w-4 text-terminal-amber" />
              HELLO@MERIDIAN-ENERGY.EXAMPLE
            </p>
            <p className="flex items-center gap-3 font-mono text-xs tracking-[0.08em] text-terminal-text/70">
              <MapPin className="h-4 w-4 text-terminal-amber" />
              HOUSTON · SINGAPORE · BRUSSELS
            </p>
          </div>
          <p className="mt-10 font-mono text-[10px] uppercase tracking-[0.14em] text-terminal-text/40">
            Live form · Submissions stored securely
          </p>
        </Rise>

        {/* Right — form card */}
        <Rise active={inView} delay={200} y={28} duration={700}>
          <div className="rounded-xl border border-terminal-border bg-terminal-surface p-8">
            {/* Fields collapse (300ms) on success */}
            <div
              className={cn(
                'grid transition-all duration-300',
                refCode ? 'grid-rows-[0fr] opacity-0' : 'grid-rows-[1fr] opacity-100',
              )}
            >
              <div className="overflow-hidden">
                <form onSubmit={onSubmit} noValidate className="space-y-5">
                  <div className="grid gap-5 sm:grid-cols-2">
                    <div>
                      <FieldLabel htmlFor="contact-name">Name</FieldLabel>
                      <input
                        id="contact-name"
                        placeholder="Ada Okonkwo"
                        aria-invalid={!!errors.name}
                        {...register('name')}
                        className={inputClass(!!errors.name)}
                      />
                      <FieldError message={errors.name?.message} />
                    </div>
                    <div>
                      <FieldLabel htmlFor="contact-org">Organization</FieldLabel>
                      <input
                        id="contact-org"
                        placeholder="Ministry of Energy"
                        aria-invalid={!!errors.organization}
                        {...register('organization')}
                        className={inputClass(!!errors.organization)}
                      />
                      <FieldError message={errors.organization?.message} />
                    </div>
                  </div>
                  <div>
                    <FieldLabel htmlFor="contact-email">Email</FieldLabel>
                    <input
                      id="contact-email"
                      type="email"
                      placeholder="you@office.gov"
                      aria-invalid={!!errors.email}
                      {...register('email')}
                      className={inputClass(!!errors.email)}
                    />
                    <FieldError message={errors.email?.message} />
                  </div>
                  <div>
                    <FieldLabel htmlFor="contact-interest">Interest</FieldLabel>
                    <Controller
                      control={control}
                      name="interest"
                      render={({ field }) => (
                        <Select value={field.value} onValueChange={field.onChange}>
                          <SelectTrigger
                            id="contact-interest"
                            aria-invalid={!!errors.interest}
                            className={cn(
                              'w-full border-terminal-border bg-terminal-bg font-sans text-sm text-terminal-text',
                              'focus:ring-1 focus:ring-terminal-amber data-[placeholder]:text-terminal-text/30',
                              errors.interest && 'border-critical',
                            )}
                          >
                            <SelectValue placeholder="Select an area of interest" />
                          </SelectTrigger>
                          <SelectContent className="border-terminal-border bg-terminal-surface text-terminal-text">
                            {INTERESTS.map((interest) => (
                              <SelectItem
                                key={interest}
                                value={interest}
                                className="focus:bg-terminal-amber/15 focus:text-terminal-amber"
                              >
                                {interest}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    />
                    <FieldError message={errors.interest?.message} />
                  </div>
                  <div>
                    <FieldLabel htmlFor="contact-message">Message</FieldLabel>
                    <textarea
                      id="contact-message"
                      rows={4}
                      placeholder="Where does the oil↔solar intersection touch your mandate?"
                      aria-invalid={!!errors.message}
                      {...register('message')}
                      className={cn(inputClass(!!errors.message), 'resize-none')}
                    />
                    <FieldError message={errors.message?.message} />
                  </div>
                  <button
                    type="submit"
                    disabled={submitRequest.isPending}
                    className="w-full rounded-lg bg-solar px-5 py-3 font-sans text-sm font-semibold text-foreground transition-all hover:-translate-y-px hover:bg-terminal-amber active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {submitRequest.isPending ? 'Submitting…' : 'Request Access'}
                  </button>
                </form>
              </div>
            </div>

            {refCode && <Confirmation refCode={refCode} />}
          </div>
        </Rise>
      </div>
    </section>
  )
}
