import Rise from '@/components/about/Rise'
import SectionHeader from '@/components/SectionHeader'
import { useInView } from '@/lib/animation'
import { cn } from '@/lib/utils'

type Leader = {
  name: string
  initials: string
  role: string
  line: string
  /** hover ring treatment */
  ring: { color?: string; gradient?: string }
}

const LEADERS: Leader[] = [
  {
    name: 'Dr. Amara Osei',
    initials: 'AO',
    role: 'CHIEF EXECUTIVE',
    line: 'Former IEA reserve-analysis lead.',
    ring: { gradient: 'linear-gradient(135deg, #0E5A50 50%, #E9A319 50%)' },
  },
  {
    name: 'Rajan Mehta',
    initials: 'RM',
    role: 'HEAD OF SOLAR INTELLIGENCE',
    line: 'Built three national PV registries.',
    ring: { color: '#E9A319' },
  },
  {
    name: 'Elena Vasquez',
    initials: 'EV',
    role: 'HEAD OF OIL SUPPLY',
    line: '15 years on trading-floor supply desks.',
    ring: { color: '#0E5A50' },
  },
  {
    name: 'Tomas Lindqvist',
    initials: 'TL',
    role: 'CHIEF TECHNOLOGY OFFICER',
    line: 'Realtime energy data infrastructure.',
    ring: { color: '#171410' },
  },
]

function Monogram({ leader, active, delay }: { leader: Leader; active: boolean; delay: number }) {
  return (
    <div
      className="relative h-20 w-20"
      style={{
        transform: active ? 'scale(1)' : 'scale(0.8)',
        opacity: active ? 1 : 0,
        transition: `transform 500ms cubic-bezier(0.34,1.56,0.64,1) ${delay}ms, opacity 500ms ease-out ${delay}ms`,
      }}
    >
      {/* Domain ring — draws on hover */}
      <span
        aria-hidden
        className="absolute -inset-1 rounded-full opacity-0 transition-all duration-300 group-hover:opacity-100"
        style={
          leader.ring.gradient
            ? {
                background: leader.ring.gradient,
                WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
                WebkitMaskComposite: 'xor',
                maskComposite: 'exclude',
                padding: 2,
              }
            : { border: `2px solid ${leader.ring.color}` }
        }
      />
      <span className="absolute inset-0 flex items-center justify-center rounded-full bg-muted font-display text-xl font-medium text-foreground">
        {leader.initials}
      </span>
    </div>
  )
}

/** §5 — Leadership strip: monogram cards for the four desks. */
export default function Leadership() {
  const [ref, inView] = useInView<HTMLDivElement>(0.2)

  return (
    <section className="mx-auto max-w-[1200px] px-6 pb-24 md:px-10">
      <SectionHeader eyebrow="// LEADERSHIP" title="The desks behind the data." />

      <div ref={ref} className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {LEADERS.map((leader, i) => (
          <Rise key={leader.name} active={inView} delay={i * 100} y={20} duration={700} className="h-full">
            <div className="card-lift group h-full rounded-xl border border-border bg-card p-6">
              <Monogram leader={leader} active={inView} delay={i * 100 + 150} />
              <h3 className="mt-5 font-sans text-lg font-semibold leading-[1.25] text-foreground">
                {leader.name}
              </h3>
              <p
                className={cn(
                  'mt-1.5 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground',
                )}
              >
                {leader.role}
              </p>
              <p className="mt-3 text-sm leading-[1.6] text-muted-foreground">{leader.line}</p>
            </div>
          </Rise>
        ))}
      </div>
    </section>
  )
}
