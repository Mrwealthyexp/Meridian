import Rise from '@/components/about/Rise'
import SectionHeader from '@/components/SectionHeader'
import { useInView } from '@/lib/animation'
import { cn } from '@/lib/utils'

type Era = 'oil' | 'solar' | 'split'

type TimelineNode = {
  year: string
  title: string
  body: string
  era: Era
  today?: boolean
}

const NODES: TimelineNode[] = [
  {
    year: '2019',
    title: 'Founded as a strategic petroleum data desk',
    body: 'Three analysts, one terminal, and a conviction that reserve data deserved better tooling.',
    era: 'oil',
  },
  {
    year: '2021',
    title: 'Reserve monitoring grows to 46 nations',
    body: 'Tank-top reads and stockdraw alerts extend across every IEA member and beyond.',
    era: 'oil',
  },
  {
    year: '2022',
    title: 'First solar pipeline database ships',
    body: 'The desk goes dual: utility-scale PV projects tracked with the same rigor as crude flows.',
    era: 'solar',
  },
  {
    year: '2024',
    title: 'Unified oil↔solar scenario engine launches',
    body: 'Supply shocks and solar ramps modeled in one schema — the intersection becomes the product.',
    era: 'split',
  },
  {
    year: '2025',
    title: 'Meridian Command Dashboard opens to partners',
    body: 'The full platform — both systems, one terminal — opens to partner desks worldwide.',
    era: 'split',
    today: true,
  },
]

const NODE_BG: Record<Era, string> = {
  oil: '#0E5A50',
  solar: '#E9A319',
  split: 'linear-gradient(135deg, #0E5A50 50%, #E9A319 50%)',
}

const CHIP_CLASS: Record<Era, string> = {
  oil: 'bg-oil/12 text-oil',
  solar: 'bg-solar/15 text-solar-deep',
  split:
    'bg-[linear-gradient(90deg,rgba(14,90,80,0.12),rgba(233,163,25,0.12))] text-foreground',
}

function Node({ node, index, active }: { node: TimelineNode; index: number; active: boolean }) {
  const left = index % 2 === 0
  const cardDelay = 300 + index * 200
  const dotDelay = 200 + index * 200

  return (
    <div className="relative pb-12 pl-12 last:pb-0 lg:grid lg:grid-cols-2 lg:gap-16 lg:pl-0">
      {/* Node dot — pops scale 0→1, stagger 200ms */}
      <span
        aria-hidden
        className="absolute left-[13px] top-1.5 h-3.5 w-3.5 rounded-full ring-4 ring-background lg:left-1/2 lg:-translate-x-1/2"
        style={{
          background: NODE_BG[node.era],
          scale: active ? '1' : '0',
          transition: `scale 450ms cubic-bezier(0.34,1.56,0.64,1) ${dotDelay}ms`,
        }}
      />
      {/* Card — slides in from its side as the line passes */}
      <div className={cn(left ? 'lg:col-start-1' : 'lg:col-start-2')}>
        <Rise
          active={active}
          delay={cardDelay}
          duration={600}
          y={0}
          x={left ? -32 : 32}
        >
          <div
            className={cn(
              'card-lift rounded-xl border border-border bg-card p-6',
              left ? 'lg:text-right' : 'lg:text-left',
            )}
          >
            <div className={cn('flex items-center gap-2', left && 'lg:justify-end')}>
              <span
                className={cn(
                  'inline-flex items-center rounded-full px-2.5 py-1 font-mono text-[11px] font-semibold tracking-[0.1em] tabular-nums',
                  CHIP_CLASS[node.era],
                )}
              >
                {node.year}
              </span>
              {node.today && (
                <span className="inline-flex items-center rounded-full bg-solar px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-foreground">
                  Today
                </span>
              )}
            </div>
            <h3 className="mt-3 font-sans text-lg font-semibold leading-[1.3] text-foreground">
              {node.title}
            </h3>
            <p className="mt-2 text-sm leading-[1.6] text-muted-foreground">{node.body}</p>
          </div>
        </Rise>
      </div>
    </div>
  )
}

/** §4 — Alternating vertical timeline, 2019 → today. */
export default function Timeline() {
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <section className="mx-auto max-w-[1200px] px-6 py-24 md:px-10">
      <SectionHeader
        eyebrow="// TRAJECTORY"
        title={
          <>
            From an oil desk to a <span className="italic">dual-energy platform</span>.
          </>
        }
      />

      <div ref={ref} className="relative mx-auto mt-14 max-w-4xl">
        {/* Center line — draws scaleY 0→1 over 1200ms */}
        <span
          aria-hidden
          className="absolute bottom-0 left-5 top-1.5 w-0.5 origin-top bg-border lg:left-1/2 lg:-translate-x-1/2"
          style={{
            transform: inView ? 'scaleY(1)' : 'scaleY(0)',
            transition: 'transform 1200ms cubic-bezier(0.22,1,0.36,1) 150ms',
          }}
        />
        {NODES.map((node, i) => (
          <Node key={node.year} node={node} index={i} active={inView} />
        ))}
      </div>
    </section>
  )
}
