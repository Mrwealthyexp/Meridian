import { useMemo, useState } from 'react'
import { Coins, Landmark, ShieldAlert, TrendingUp } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import {
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { useInView } from '@/lib/animation'
import {
  BENCHMARK_META,
  fiveYearAverage,
  seriesFor,
} from './data'
import type { Benchmark, PriceRange } from './data'
import { FillBar, SlideIn, TerminalTooltip } from './shared'

const DRIVERS: { icon: LucideIcon; label: string; weight: number }[] = [
  { icon: Landmark, label: 'OPEC+ Discipline', weight: 72 },
  { icon: TrendingUp, label: 'Demand Growth', weight: 54 },
  { icon: ShieldAlert, label: 'Geopolitics', weight: 61 },
  { icon: Coins, label: 'DXY Strength', weight: 38 },
]

function AvgLabel({ viewBox, avg }: { viewBox?: { x?: number; y?: number }; avg: number }) {
  const x = (viewBox?.x ?? 0) + 6
  const y = (viewBox?.y ?? 0) - 6
  return (
    <text
      x={x}
      y={y}
      className="fill-muted-foreground"
      fontSize={10}
      fontFamily="'IBM Plex Mono', monospace"
      letterSpacing="0.1em"
    >
      5Y AVG ${avg.toFixed(2)}
    </text>
  )
}

export default function PriceCenter() {
  const [bench, setBench] = useState<Benchmark>('wti')
  const [range, setRange] = useState<PriceRange>('1Y')
  const [cardRef, inView] = useInView<HTMLDivElement>(0.15)

  const data = useMemo(() => seriesFor(range), [range])
  const avg = useMemo(() => fiveYearAverage(bench), [bench])
  const meta = BENCHMARK_META[bench]

  return (
    <section className="mx-auto mt-20 max-w-[1200px] px-6 md:px-10">
      <div ref={cardRef} className="grid gap-6 lg:grid-cols-3">
        {/* Main chart card */}
        <SlideIn
          active={inView}
          y={28}
          duration={700}
          className="lg:col-span-2"
        >
          <div className="h-full rounded-xl border border-border bg-card p-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="font-sans text-lg font-semibold leading-[1.25] text-foreground md:text-[22px]">
                  Benchmark Crude Prices
                </h3>
                <p className="mt-1 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                  {meta.label} · ${meta.end.toFixed(2)}/BBL · SAMPLE DATA
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <Tabs value={bench} onValueChange={(v) => setBench(v as Benchmark)}>
                  <TabsList className="bg-muted">
                    <TabsTrigger value="wti" className="font-mono text-[11px]">WTI</TabsTrigger>
                    <TabsTrigger value="brent" className="font-mono text-[11px]">BRENT</TabsTrigger>
                    <TabsTrigger value="dubai" className="font-mono text-[11px]">DUBAI</TabsTrigger>
                    <TabsTrigger value="spread" className="font-mono text-[11px]">SPREAD</TabsTrigger>
                  </TabsList>
                </Tabs>
                <ToggleGroup
                  type="single"
                  value={range}
                  onValueChange={(v) => v && setRange(v as PriceRange)}
                  className="rounded-lg border border-border"
                >
                  {(['3M', '1Y', '5Y'] as const).map((r) => (
                    <ToggleGroupItem
                      key={r}
                      value={r}
                      className="px-3 font-mono text-[11px] data-[state=on]:bg-oil data-[state=on]:text-white"
                    >
                      {r}
                    </ToggleGroupItem>
                  ))}
                </ToggleGroup>
              </div>
            </div>

            <div className="mt-6 h-[320px]">
              {inView && (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    key={`${bench}-${range}`}
                    data={data}
                    margin={{ top: 8, right: 8, bottom: 0, left: 0 }}
                  >
                    <CartesianGrid stroke="#EDE7DA" strokeDasharray="3 3" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tickLine={false}
                      axisLine={false}
                      minTickGap={48}
                      tick={{
                        fill: '#6E675B',
                        fontSize: 10,
                        fontFamily: "'IBM Plex Mono', monospace",
                      }}
                    />
                    <YAxis
                      domain={['auto', 'auto']}
                      tickLine={false}
                      axisLine={false}
                      width={44}
                      tick={{
                        fill: '#6E675B',
                        fontSize: 10,
                        fontFamily: "'IBM Plex Mono', monospace",
                      }}
                    />
                    <Tooltip
                      content={<TerminalTooltip unit={bench === 'spread' ? '' : '/BBL'} />}
                      cursor={{ stroke: '#0E5A50', strokeOpacity: 0.3 }}
                    />
                    <ReferenceLine
                      y={avg}
                      stroke="#9A6A33"
                      strokeDasharray="6 4"
                      strokeOpacity={0.8}
                      label={<AvgLabel avg={avg} />}
                    />
                    <Line
                      type="monotone"
                      dataKey={bench}
                      stroke="#0E5A50"
                      strokeWidth={2}
                      dot={false}
                      isAnimationActive
                      animationDuration={1200}
                      animationEasing="ease-out"
                    />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>
        </SlideIn>

        {/* Price drivers side card */}
        <SlideIn active={inView} index={1} step={120} y={28} duration={700}>
          <div className="h-full rounded-xl border border-border bg-card p-6">
            <h3 className="font-sans text-lg font-semibold text-foreground">Price Drivers</h3>
            <p className="mt-1 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
              Contribution Weight · Sample Model
            </p>
            <div className="mt-6 space-y-6">
              {DRIVERS.map((d, i) => (
                <div key={d.label}>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2.5">
                      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted">
                        <d.icon className="h-4 w-4 text-oil" />
                      </span>
                      <span className="font-sans text-sm font-medium text-foreground">
                        {d.label}
                      </span>
                    </span>
                    <span className="font-mono text-xs font-medium tabular-nums text-muted-foreground">
                      {d.weight}%
                    </span>
                  </div>
                  <FillBar
                    value={d.weight}
                    active={inView}
                    delay={300 + i * 120}
                    duration={800}
                    color="#0E5A50"
                    className="mt-2.5"
                  />
                </div>
              ))}
            </div>
            <p className="mt-6 border-t border-border pt-4 text-[13px] leading-[1.5] text-muted-foreground">
              Weights reflect the rolling 90-day regression of prompt Brent
              against Meridian driver factors.
            </p>
          </div>
        </SlideIn>
      </div>
    </section>
  )
}
