import { Line, LineChart, ResponsiveContainer } from 'recharts'
import { DeltaChip, DomainBadge } from '@/components/badges'
import { useCountUp, useInView } from '@/lib/animation'
import { sparkline } from './data'
import { SlideIn } from './shared'

type Kpi = {
  label: string
  value: number
  format: (v: number) => string
  delta: string
  direction: 'up' | 'down'
  spark: { i: number; v: number }[]
  color: string
}

const KPIS: Kpi[] = [
  {
    label: 'US Strategic Reserve',
    value: 372,
    format: (v) => `${Math.round(v)}M BBL`,
    delta: '0.4% WK',
    direction: 'up',
    spark: sparkline(7, 24, 352, 372),
    color: '#9A6A33',
  },
  {
    label: 'OPEC+ Output',
    value: 41.2,
    format: (v) => `${v.toFixed(1)}M BBL/D`,
    delta: '0.6%',
    direction: 'down',
    spark: sparkline(19, 24, 42.4, 41.2),
    color: '#0E5A50',
  },
  {
    label: 'IEA Import Cover',
    value: 94,
    format: (v) => `${Math.round(v)} DAYS`,
    delta: '2',
    direction: 'up',
    spark: sparkline(31, 24, 88, 94),
    color: '#0E5A50',
  },
  {
    label: 'Global Upstream Capex',
    value: 545,
    format: (v) => `$${Math.round(v)}B`,
    delta: '3.1% YOY',
    direction: 'up',
    spark: sparkline(43, 24, 480, 545),
    color: '#9A6A33',
  },
]

function KpiCard({ kpi, active, index }: { kpi: Kpi; active: boolean; index: number }) {
  const v = useCountUp(kpi.value, active, 1200)
  return (
    <SlideIn active={active} index={index} step={80} y={20} duration={600}>
      <div className="card-lift h-full rounded-xl border border-border bg-card p-6 hover:border-oil/40">
        <div className="flex items-center justify-between gap-2">
          <p className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
            {kpi.label}
          </p>
          <DomainBadge domain="oil" />
        </div>
        <p className="mt-3 font-mono text-[30px] font-medium leading-[1.1] tracking-[-0.01em] tabular-nums text-foreground">
          {kpi.format(v)}
        </p>
        <div className="mt-2">
          <DeltaChip value={kpi.delta} direction={kpi.direction} />
        </div>
        <div className="mt-4 h-12">
          {active && (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={kpi.spark}>
                <Line
                  type="monotone"
                  dataKey="v"
                  stroke={kpi.color}
                  strokeWidth={1.5}
                  dot={false}
                  isAnimationActive
                  animationDuration={900}
                  animationEasing="ease-out"
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </SlideIn>
  )
}

export default function OilKpiStrip() {
  const [countRef, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <section className="mx-auto max-w-[1200px] px-6 md:px-10">
      <div ref={countRef} className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {KPIS.map((kpi, i) => (
          <KpiCard key={kpi.label} kpi={kpi} active={inView} index={i} />
        ))}
      </div>
      <p className="mt-4 text-right font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground/70">
        Sample Data · Refreshed Daily
      </p>
    </section>
  )
}
