import { Link } from 'react-router'
import { ArrowRight } from 'lucide-react'
import { useInView } from '@/lib/animation'
import { SlideIn } from './shared'

const SERVICES = [
  'Reserve Data Feeds',
  'Chokepoint Alerts',
  'Supply Scenario Modeling',
  'Advisory Retainers',
]

export default function RiskBrief() {
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <section className="pb-24">
      <div ref={ref} className="mx-auto grid max-w-[1200px] gap-10 px-6 md:px-10 lg:grid-cols-3">
        <SlideIn active={inView} y={24} duration={700} className="lg:col-span-2">
          <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-oil">
            // Risk Brief
          </p>
          <h3 className="mt-3 font-display text-2xl font-medium leading-[1.15] tracking-[-0.01em] text-foreground md:text-[30px]">
            Bab el-Mandeb: the quiet chokepoint behind Q4 supply scenarios.
          </h3>
          <div className="mt-5 max-w-2xl space-y-4 text-[15px] leading-[1.65] text-muted-foreground">
            <p>
              While Hormuz dominates headlines, Bab el-Mandeb has quietly become
              the binding constraint on Atlantic-basin product balances. Transit
              volumes remain a third below trend, and every week of diversion
              adds roughly a day of global vessel demand to the tanker fleet.
            </p>
            <p>
              Our Q4 scenarios assign a 55% probability to sustained Cape
              rerouting through year-end. Under that path, European diesel
              cracks stay elevated and prompt Brent structure holds backwardation
              even as OPEC+ unwinds voluntary cuts.
            </p>
            <p>
              The contrarian case: a credible ceasefire compresses freight
              premia within weeks and releases an effective 0.8M bbl/d of latent
              supply. Positioning data suggests the market prices less than half
              of that tail.
            </p>
          </div>
          <p className="mt-6 font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground/70">
            Meridian Oil Desk · Sample Analysis
          </p>
        </SlideIn>

        <SlideIn active={inView} index={1} step={120} y={24} duration={700}>
          <div
            className="h-full rounded-xl border border-border bg-card p-6"
            style={{ borderTop: '3px solid #0E5A50' }}
          >
            <h4 className="font-sans text-base font-semibold text-foreground">
              Oil module services
            </h4>
            <div className="mt-4 divide-y divide-border">
              {SERVICES.map((s, i) => (
                <div
                  key={s}
                  style={{
                    opacity: inView ? 1 : 0,
                    transform: inView ? 'none' : 'translateX(12px)',
                    transition: `opacity 500ms cubic-bezier(0.22,1,0.36,1) ${300 + i * 80}ms, transform 500ms cubic-bezier(0.22,1,0.36,1) ${300 + i * 80}ms`,
                  }}
                >
                  <Link
                    to="/services"
                    className="group flex items-center justify-between rounded-md px-2 py-3.5 transition-colors hover:bg-muted/50"
                  >
                    <span className="font-sans text-sm font-medium text-foreground">{s}</span>
                    <ArrowRight className="h-4 w-4 text-oil transition-transform duration-200 group-hover:translate-x-1" />
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </SlideIn>
      </div>
    </section>
  )
}
