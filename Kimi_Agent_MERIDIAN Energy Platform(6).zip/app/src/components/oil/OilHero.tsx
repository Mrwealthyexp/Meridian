import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import Words from '@/components/home/Words'
import { HeroIn } from './shared'

export default function OilHero() {
  const [mounted, setMounted] = useState(false)
  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 40)
    return () => clearTimeout(t)
  }, [])

  return (
    <section className="relative overflow-hidden pb-16 pt-[136px]">
      <div className="mx-auto grid w-full max-w-[1200px] gap-12 px-6 md:px-10 lg:grid-cols-2 lg:items-center">
        <div>
          <HeroIn delay={80} duration={400} x={-16} y={0}>
            <p className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
              <Link to="/" className="transition-colors hover:text-foreground">
                Home
              </Link>
              <span className="mx-2">/</span>
              Oil Supply
            </p>
          </HeroIn>
          <HeroIn delay={160} duration={400} x={-16} y={0}>
            <p className="mt-5 font-mono text-xs font-semibold uppercase tracking-[0.18em] text-oil">
              // Strategic Oil Supply
            </p>
          </HeroIn>

          <h1
            className="mt-4 font-display text-4xl font-medium leading-[1.05] tracking-[-0.015em] text-foreground md:text-[56px]"
            style={{ fontVariationSettings: "'opsz' 144" }}
          >
            <Words
              active={mounted}
              delayStart={320}
              stagger={60}
              segments={[
                { text: 'Every barrel that' },
                { text: 'matters', italic: true },
                { text: ', measured.' },
              ]}
            />
          </h1>

          <HeroIn delay={700} duration={600} y={16}>
            <p className="mt-6 max-w-2xl text-[17px] leading-[1.6] text-muted-foreground md:text-lg">
              Reserve inventories, transit chokepoints, benchmark pricing, and
              geopolitical exposure — the complete strategic oil picture,
              refreshed daily.
            </p>
          </HeroIn>
        </div>

        {/* Hero image card — clip-path wipe reveal + scale settle */}
        <div
          className="relative hidden lg:block"
          style={{
            clipPath: mounted ? 'inset(0 0 0 0)' : 'inset(0 100% 0 0)',
            transition: 'clip-path 900ms ease-out 500ms',
          }}
        >
          <div className="relative aspect-[16/10] overflow-hidden rounded-xl border border-border">
            <img
              src="/oil-terminal.jpg"
              alt="Aerial view of a strategic petroleum reserve tank farm at dusk"
              className="h-full w-full object-cover"
              style={{
                transform: mounted ? 'scale(1)' : 'scale(1.1)',
                transition: 'transform 1400ms ease-out 500ms',
              }}
            />
            <div
              className="absolute inset-0"
              style={{
                background: 'linear-gradient(to top, rgba(9,59,53,0.7), transparent 55%)',
              }}
            />
            <p className="absolute bottom-4 left-4 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-white/90">
              SPR Tank Farm · Gulf Coast
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
