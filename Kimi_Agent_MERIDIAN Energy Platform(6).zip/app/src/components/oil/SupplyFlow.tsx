import { Fragment } from 'react'
import type { CSSProperties } from 'react'
import { ChartLine, Database, Factory, Fuel, Ship } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import SectionHeader from '@/components/SectionHeader'
import { useInView } from '@/lib/animation'
import { EASE, SlideIn } from './shared'

const STEPS: { icon: LucideIcon; title: string; line: string }[] = [
  { icon: Fuel, title: 'Upstream Production', line: '10.4M bbl/d tracked across 32 producers' },
  { icon: Ship, title: 'Transit & Chokepoints', line: '62% of seaborne crude via 5 straits' },
  { icon: Factory, title: 'Refining', line: 'Utilization at 91.3% of capacity' },
  { icon: Database, title: 'Storage & SPR', line: '1.2B bbl of strategic capacity monitored' },
  { icon: ChartLine, title: 'Distribution & Pricing', line: 'Benchmark formation, daily' },
]

/** Dashed connector with a perpetual "dash march" + sequenced scale draw. */
function FlowConnector({
  active,
  index,
  vertical = false,
}: {
  active: boolean
  index: number
  vertical?: boolean
}) {
  const delay = (index + 1) * 120 + 350
  const drawn: CSSProperties = active
    ? { transform: 'scale(1)' }
    : { transform: vertical ? 'scaleY(0)' : 'scaleX(0)' }
  return (
    <div
      aria-hidden
      className={
        vertical
          ? 'mx-auto flex h-10 w-4 items-center justify-center'
          : 'flex min-w-8 flex-1 items-center self-stretch'
      }
    >
      <div
        className={vertical ? 'h-full w-4' : 'h-4 w-full'}
        style={{
          ...drawn,
          transformOrigin: vertical ? 'top' : 'left',
          transition: `transform 500ms ${EASE} ${delay}ms`,
        }}
      >
        <svg
          className={vertical ? 'h-full w-4' : 'h-4 w-full'}
          preserveAspectRatio="none"
          viewBox={vertical ? '0 0 16 40' : '0 0 100 16'}
        >
          {vertical ? (
            <line
              x1="8"
              y1="0"
              x2="8"
              y2="40"
              stroke="#0E5A50"
              strokeWidth="2"
              strokeDasharray="5 5"
              className="meridian-flow-dash"
            />
          ) : (
            <line
              x1="0"
              y1="8"
              x2="100"
              y2="8"
              stroke="#0E5A50"
              strokeWidth="2"
              strokeDasharray="5 5"
              vectorEffect="non-scaling-stroke"
              className="meridian-flow-dash"
            />
          )}
        </svg>
      </div>
    </div>
  )
}

export default function SupplyFlow() {
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <section className="py-24">
      <style>{`
        @keyframes meridian-dash-march { to { stroke-dashoffset: -200; } }
        .meridian-flow-dash { animation: meridian-dash-march 20s linear infinite; }
        @media (prefers-reduced-motion: reduce) { .meridian-flow-dash { animation: none; } }
      `}</style>
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 md:px-10">
        <SectionHeader
          eyebrow="// SUPPLY CHAIN"
          eyebrowTone="oil"
          title={
            <>
              From field to <em className="italic">strategic reserve</em>.
            </>
          }
        />

        {/* Desktop: horizontal flow */}
        <div className="mt-12 hidden items-stretch lg:flex">
          {STEPS.map((step, i) => (
            <Fragment key={step.title}>
              <SlideIn active={inView} index={i} step={120} y={24} duration={600} className="w-full">
                <div className="card-lift h-full rounded-xl border border-border bg-card p-5 hover:border-oil/40">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-semibold tracking-[0.14em] text-bronze">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted">
                      <step.icon className="h-4 w-4 text-oil" />
                    </span>
                  </div>
                  <h3 className="mt-4 font-sans text-base font-semibold leading-[1.25] text-foreground">
                    {step.title}
                  </h3>
                  <p className="mt-1.5 text-[13px] leading-[1.5] text-muted-foreground">
                    {step.line}
                  </p>
                </div>
              </SlideIn>
              {i < STEPS.length - 1 && <FlowConnector active={inView} index={i} />}
            </Fragment>
          ))}
        </div>

        {/* Mobile/tablet: vertical stack */}
        <div className="mt-12 flex flex-col lg:hidden">
          {STEPS.map((step, i) => (
            <Fragment key={step.title}>
              <SlideIn active={inView} index={i} step={120} y={24} duration={600}>
                <div className="card-lift rounded-xl border border-border bg-card p-5 hover:border-oil/40">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-semibold tracking-[0.14em] text-bronze">
                      {String(i + 1).padStart(2, '0')}
                    </span>
                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted">
                      <step.icon className="h-4 w-4 text-oil" />
                    </span>
                  </div>
                  <h3 className="mt-4 font-sans text-base font-semibold leading-[1.25] text-foreground">
                    {step.title}
                  </h3>
                  <p className="mt-1.5 text-[13px] leading-[1.5] text-muted-foreground">
                    {step.line}
                  </p>
                </div>
              </SlideIn>
              {i < STEPS.length - 1 && <FlowConnector active={inView} index={i} vertical />}
            </Fragment>
          ))}
        </div>
      </div>
    </section>
  )
}
