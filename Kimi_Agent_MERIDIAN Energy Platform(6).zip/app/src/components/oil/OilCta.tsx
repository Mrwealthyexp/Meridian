import { Link } from 'react-router'
import { ArrowRight } from 'lucide-react'
import Words from '@/components/home/Words'
import { useInView } from '@/lib/animation'
import { SlideIn } from './shared'

export default function OilCta() {
  const [ref, inView] = useInView<HTMLDivElement>(0.2)

  return (
    <section className="pb-32">
      <style>{`
        @keyframes meridian-nudge { 0%, 100% { transform: translateX(0); } 50% { transform: translateX(2px); } }
        .meridian-nudge { animation: meridian-nudge 2.4s ease-in-out infinite; }
        @media (prefers-reduced-motion: reduce) { .meridian-nudge { animation: none; } }
      `}</style>
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 text-center md:px-10">
        <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-oil">
          // Next Module
        </p>
        <h2 className="mx-auto mt-4 max-w-2xl font-display text-3xl font-medium leading-[1.1] tracking-[-0.01em] text-foreground md:text-[40px]">
          <Words
            active={inView}
            stagger={50}
            segments={[{ text: 'Now see the' }, { text: 'other half', italic: true }, { text: 'of the system.' }]}
          />
        </h2>
        <SlideIn active={inView} delayBase={600} y={16} duration={600}>
          <Link
            to="/solar-energy"
            className="group mt-8 inline-flex items-center gap-2 rounded-lg bg-solar px-6 py-3.5 font-sans text-[15px] font-semibold text-foreground transition-all hover:-translate-y-px hover:bg-solar-deep hover:text-white active:scale-[0.97]"
          >
            Explore Solar Energy
            <ArrowRight className="meridian-nudge h-4 w-4" />
          </Link>
        </SlideIn>
      </div>
    </section>
  )
}
