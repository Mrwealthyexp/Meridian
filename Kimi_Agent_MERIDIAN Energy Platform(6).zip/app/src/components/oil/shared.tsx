import { useEffect, useState } from 'react'
import type { CSSProperties, ReactNode } from 'react'
import { cn } from '@/lib/utils'

export const EASE = 'cubic-bezier(0.22,1,0.36,1)'

/** Load-sequence entrance: rises/fades once on mount with a delay. */
export function HeroIn({
  delay = 0,
  duration = 700,
  x = 0,
  y = 24,
  className,
  children,
}: {
  delay?: number
  duration?: number
  x?: number
  y?: number
  className?: string
  children: ReactNode
}) {
  const [on, setOn] = useState(false)
  useEffect(() => {
    const raf = requestAnimationFrame(() => setOn(true))
    return () => cancelAnimationFrame(raf)
  }, [])
  return (
    <div
      className={className}
      style={{
        opacity: on ? 1 : 0,
        transform: on ? 'none' : `translate(${x}px, ${y}px)`,
        transition: `opacity ${duration}ms ${EASE} ${delay}ms, transform ${duration}ms ${EASE} ${delay}ms`,
      }}
    >
      {children}
    </div>
  )
}

/** Scroll-triggered staggered item — rises/slides in once `active` flips true. */
export function SlideIn({
  active,
  index = 0,
  step = 80,
  delayBase = 0,
  duration = 600,
  x = 0,
  y = 20,
  className,
  children,
  style,
}: {
  active: boolean
  index?: number
  step?: number
  delayBase?: number
  duration?: number
  x?: number
  y?: number
  className?: string
  children: ReactNode
  style?: CSSProperties
}) {
  const delay = delayBase + index * step
  return (
    <div
      className={className}
      style={{
        opacity: active ? 1 : 0,
        transform: active ? 'none' : `translate(${x}px, ${y}px)`,
        transition: `opacity ${duration}ms ${EASE} ${delay}ms, transform ${duration}ms ${EASE} ${delay}ms`,
        ...style,
      }}
    >
      {children}
    </div>
  )
}

/** Dark terminal-styled recharts tooltip (terminal-bg, mono, amber values). */
export function TerminalTooltip({
  active,
  payload,
  label,
  unit = '',
}: {
  active?: boolean
  payload?: { name?: string; value?: number | string; color?: string; dataKey?: string }[]
  label?: string
  unit?: string
}) {
  if (!active || !payload || payload.length === 0) return null
  return (
    <div className="rounded-md border border-terminal-border bg-terminal-bg px-3 py-2 shadow-signature">
      <p className="font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-terminal-text/50">
        {label}
      </p>
      {payload.map((p, i) => (
        <p
          key={i}
          className="mt-0.5 font-mono text-xs font-medium tabular-nums text-terminal-amber"
        >
          {typeof p.value === 'number' ? p.value.toFixed(2) : p.value}
          {unit}
        </p>
      ))}
    </div>
  )
}

/** Horizontal fill bar (transform-only) that fills when `active`. */
export function FillBar({
  value,
  active,
  delay = 0,
  duration = 800,
  color = '#0E5A50',
  trackClass = 'bg-muted',
  className,
}: {
  value: number // 0–100
  active: boolean
  delay?: number
  duration?: number
  color?: string
  trackClass?: string
  className?: string
}) {
  return (
    <div className={cn('h-1.5 w-full overflow-hidden rounded-full', trackClass, className)}>
      <div
        className="h-full w-full origin-left rounded-full"
        style={{
          backgroundColor: color,
          transform: active ? `scaleX(${value / 100})` : 'scaleX(0)',
          transition: `transform ${duration}ms ${EASE} ${delay}ms`,
        }}
      />
    </div>
  )
}
