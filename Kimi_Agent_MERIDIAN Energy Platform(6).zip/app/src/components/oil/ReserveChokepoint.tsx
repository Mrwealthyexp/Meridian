import { useState } from 'react'
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Cell,
  LabelList,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import SectionHeader from '@/components/SectionHeader'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { useInView } from '@/lib/animation'
import { CHOKEPOINTS, RESERVES, STATUS_TONE } from './data'
import type { Chokepoint } from './data'
import { cn } from '@/lib/utils'
import { EASE, SlideIn, TerminalTooltip } from './shared'

/* ---------------- Card A: reserves bar chart ---------------- */

function ReservesChart({ active }: { active: boolean }) {
  const [hovered, setHovered] = useState<number | null>(null)
  return (
    <div className="h-[340px]">
      {active && (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={RESERVES}
            layout="vertical"
            margin={{ top: 0, right: 56, bottom: 0, left: 0 }}
          >
            <XAxis type="number" hide domain={[0, 420]} />
            <YAxis
              type="category"
              dataKey="nation"
              width={118}
              tickLine={false}
              axisLine={false}
              tick={{
                fill: '#6E675B',
                fontSize: 10,
                fontFamily: "'IBM Plex Mono', monospace",
                letterSpacing: '0.06em',
              }}
            />
            <Tooltip
              content={<TerminalTooltip unit="M BBL" />}
              cursor={{ fill: '#0E5A50', fillOpacity: 0.05 }}
            />
            <Bar
              dataKey="mbl"
              radius={[0, 4, 4, 0]}
              isAnimationActive
              animationDuration={900}
              animationEasing="ease-out"
              animationBegin={0}
            >
              {RESERVES.map((r, i) => (
                <Cell
                  key={r.code}
                  fill={hovered === i ? '#E9A319' : '#0E5A50'}
                  fillOpacity={hovered === i ? 1 : 0.75}
                  onMouseEnter={() => setHovered(i)}
                  onMouseLeave={() => setHovered(null)}
                />
              ))}
              <LabelList
                dataKey="mbl"
                position="right"
                style={{
                  fill: '#171410',
                  fontSize: 11,
                  fontFamily: "'IBM Plex Mono', monospace",
                  fontWeight: 500,
                }}
                formatter={(v: unknown) => `${v}M`}
              />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  )
}

/* ---------------- Card B: chokepoint monitor ---------------- */

function ChokepointRow({
  cp,
  active,
  index,
  onOpen,
}: {
  cp: Chokepoint
  active: boolean
  index: number
  onOpen: (cp: Chokepoint) => void
}) {
  const rowDelay = index * 80
  return (
    <button
      onClick={() => onOpen(cp)}
      className="group flex w-full items-center justify-between gap-4 rounded-lg border border-transparent px-4 py-3.5 text-left transition-colors hover:border-border hover:bg-card"
      style={{
        opacity: active ? 1 : 0,
        transform: active ? 'none' : 'translateX(-12px)',
        transition: `opacity 600ms ${EASE} ${rowDelay}ms, transform 600ms ${EASE} ${rowDelay}ms`,
      }}
    >
      <div className="min-w-0">
        <p className="font-sans text-[15px] font-semibold text-foreground">{cp.name}</p>
        <p className="mt-0.5 font-mono text-[11px] font-medium tracking-[0.08em] text-muted-foreground">
          {cp.throughput}
        </p>
      </div>
      <span
        className={cn(
          'inline-flex shrink-0 items-center rounded-full px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em]',
          STATUS_TONE[cp.status],
        )}
        style={{
          transform: active ? 'scale(1)' : 'scale(0.85)',
          opacity: active ? 1 : 0,
          transition: `transform 200ms ease-out ${rowDelay + 200}ms, opacity 200ms ease-out ${rowDelay + 200}ms`,
        }}
      >
        {cp.status}
      </span>
    </button>
  )
}

function ChokepointDialog({
  cp,
  onClose,
}: {
  cp: Chokepoint | null
  onClose: () => void
}) {
  return (
    <Dialog open={!!cp} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-xl bg-card">
        {cp && (
          <>
            <DialogHeader>
              <div className="flex items-center gap-3">
                <DialogTitle className="font-sans text-xl font-semibold">
                  {cp.name}
                </DialogTitle>
                <span
                  className={cn(
                    'inline-flex items-center rounded-full px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em]',
                    STATUS_TONE[cp.status],
                  )}
                >
                  {cp.status}
                </span>
              </div>
              <DialogDescription className="font-mono text-[11px] uppercase tracking-[0.12em]">
                {cp.throughput} · 12-MONTH TRANSIT VOLUME · SAMPLE DATA
              </DialogDescription>
            </DialogHeader>

            <div className="h-[180px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={cp.transit} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
                  <defs>
                    <linearGradient id="cp-fill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#0E5A50" stopOpacity={0.28} />
                      <stop offset="100%" stopColor="#0E5A50" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="month"
                    tickLine={false}
                    axisLine={false}
                    tick={{
                      fill: '#6E675B',
                      fontSize: 10,
                      fontFamily: "'IBM Plex Mono', monospace",
                    }}
                  />
                  <YAxis
                    domain={['auto', 'auto']}
                    tickLine={false}
                    axisLine={false}
                    width={36}
                    tick={{
                      fill: '#6E675B',
                      fontSize: 10,
                      fontFamily: "'IBM Plex Mono', monospace",
                    }}
                  />
                  <Tooltip
                    content={<TerminalTooltip unit="M BBL/D" />}
                    cursor={{ stroke: '#0E5A50', strokeOpacity: 0.3 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="volume"
                    stroke="#0E5A50"
                    strokeWidth={2}
                    fill="url(#cp-fill)"
                    isAnimationActive
                    animationDuration={900}
                    animationEasing="ease-out"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-3">
              <p className="text-sm leading-[1.65] text-muted-foreground">{cp.note1}</p>
              <p className="text-sm leading-[1.65] text-muted-foreground">{cp.note2}</p>
            </div>
            <p className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground/70">
              Meridian Oil Desk · Sample Risk Note
            </p>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}

/* ---------------- Section ---------------- */

export default function ReserveChokepoint() {
  const [ref, inView] = useInView<HTMLDivElement>(0.15)
  const [selected, setSelected] = useState<Chokepoint | null>(null)

  return (
    <section className="mt-20 bg-muted/40 py-24">
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 md:px-10">
        <SectionHeader
          eyebrow="// RESERVE & TRANSIT WATCH"
          eyebrowTone="oil"
          title={
            <>
              Where the world&rsquo;s oil <em className="italic">sits</em> — and
              where it <em className="italic">squeezes</em>.
            </>
          }
        />

        <div className="mt-12 grid gap-6 lg:grid-cols-2">
          <SlideIn active={inView} y={28} duration={700}>
            <div className="h-full rounded-xl border border-border bg-card p-6">
              <div className="flex items-center justify-between">
                <h3 className="font-sans text-lg font-semibold text-foreground">
                  Strategic Reserves by Nation
                </h3>
                <span className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                  M BBL · Gov-Held
                </span>
              </div>
              <div className="mt-6">
                <ReservesChart active={inView} />
              </div>
            </div>
          </SlideIn>

          <SlideIn active={inView} index={1} step={150} y={28} duration={700}>
            <div className="h-full rounded-xl border border-border bg-card p-6">
              <div className="flex items-center justify-between">
                <h3 className="font-sans text-lg font-semibold text-foreground">
                  Chokepoint Monitor
                </h3>
                <span className="font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
                  Click Row For Risk Note
                </span>
              </div>
              <div className="mt-4 divide-y divide-border">
                {CHOKEPOINTS.map((cp, i) => (
                  <ChokepointRow
                    key={cp.id}
                    cp={cp}
                    active={inView}
                    index={i}
                    onOpen={setSelected}
                  />
                ))}
              </div>
            </div>
          </SlideIn>
        </div>
      </div>

      <ChokepointDialog cp={selected} onClose={() => setSelected(null)} />
    </section>
  )
}
