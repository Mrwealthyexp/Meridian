import { format, subWeeks } from 'date-fns'

/** Deterministic PRNG so sample series are stable across renders/builds. */
function mulberry32(seed: number) {
  return () => {
    seed |= 0
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export type PricePoint = {
  label: string
  wti: number
  brent: number
  dubai: number
  spread: number
}

const WEEKS = 260 // 5 years of weekly closes

function walk(seed: number, n: number, start: number, end: number, vol: number) {
  const rand = mulberry32(seed)
  const raw: number[] = [0]
  for (let i = 1; i < n; i++) {
    raw.push(raw[i - 1] + (rand() - 0.48) * vol)
  }
  const first = raw[0]
  const last = raw[n - 1]
  const span = last - first || 1
  // affine map raw walk onto [start, end] anchor points
  return raw.map((r) => {
    const t = (r - first) / span
    const base = start + t * (end - start)
    // retain some walk texture around the anchor line
    const texture = (r - (first + t * span)) * 0.35
    return base + texture
  })
}

function buildPriceSeries(): PricePoint[] {
  const wti = walk(11, WEEKS, 39, 78.42, 3.2)
  const brent = walk(23, WEEKS, 43, 82.11, 3.0)
  const dubai = walk(37, WEEKS, 41, 79.6, 3.0)
  const end = new Date(2025, 10, 14) // fixed sample "as of" date
  const out: PricePoint[] = []
  for (let i = 0; i < WEEKS; i++) {
    out.push({
      label: format(subWeeks(end, WEEKS - 1 - i), 'MMM d, yyyy').toUpperCase(),
      wti: +wti[i].toFixed(2),
      brent: +brent[i].toFixed(2),
      dubai: +dubai[i].toFixed(2),
      spread: +(brent[i] - wti[i]).toFixed(2),
    })
  }
  return out
}

export const PRICE_SERIES = buildPriceSeries()

export const RANGE_WEEKS = { '3M': 13, '1Y': 52, '5Y': 260 } as const
export type PriceRange = keyof typeof RANGE_WEEKS
export type Benchmark = 'wti' | 'brent' | 'dubai' | 'spread'

export const BENCHMARK_META: Record<Benchmark, { label: string; end: number }> = {
  wti: { label: 'WTI', end: 78.42 },
  brent: { label: 'BRENT', end: 82.11 },
  dubai: { label: 'DUBAI', end: 79.6 },
  spread: { label: 'BRENT–WTI SPREAD', end: 3.69 },
}

export function seriesFor(range: PriceRange): PricePoint[] {
  return PRICE_SERIES.slice(-RANGE_WEEKS[range])
}

export function fiveYearAverage(key: Benchmark): number {
  const sum = PRICE_SERIES.reduce((acc, p) => acc + p[key], 0)
  return +(sum / PRICE_SERIES.length).toFixed(2)
}

/* ---------------- Reserves (M bbl, sample) ---------------- */

export const RESERVES = [
  { nation: 'UNITED STATES', code: 'US', mbl: 372 },
  { nation: 'JAPAN', code: 'JP', mbl: 324 },
  { nation: 'CHINA', code: 'CN', mbl: 310 },
  { nation: 'GERMANY', code: 'DE', mbl: 246 },
  { nation: 'SOUTH KOREA', code: 'KR', mbl: 192 },
  { nation: 'FRANCE', code: 'FR', mbl: 165 },
  { nation: 'ITALY', code: 'IT', mbl: 152 },
  { nation: 'INDIA', code: 'IN', mbl: 138 },
]

/* ---------------- Chokepoints ---------------- */

export type ChokepointStatus = 'STABLE' | 'ELEVATED' | 'HIGH'

export type Chokepoint = {
  id: string
  name: string
  throughput: string
  status: ChokepointStatus
  transit: { month: string; volume: number }[]
  note1: string
  note2: string
}

function transitSeries(seed: number, base: number, vol: number) {
  const rand = mulberry32(seed)
  const months = [
    'DEC', 'JAN', 'FEB', 'MAR', 'APR', 'MAY',
    'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV',
  ]
  let v = base * 0.96
  return months.map((month) => {
    v = Math.max(base * 0.8, v + (rand() - 0.47) * vol)
    return { month, volume: +v.toFixed(1) }
  })
}

export const CHOKEPOINTS: Chokepoint[] = [
  {
    id: 'hormuz',
    name: 'STRAIT OF HORMUZ',
    throughput: '17.3M BBL/D',
    status: 'ELEVATED',
    transit: transitSeries(101, 17.3, 1.4),
    note1:
      'Roughly a fifth of global petroleum liquids consumption transits Hormuz each day. Insurance premia on VLCC fixtures have firmed for three consecutive weeks, and two flag states have issued advisory routing notices for night transits.',
    note2:
      'Meridian scenario work prices a two-week full closure at a $18–24/bbl prompt spike, with SPR release logistics becoming binding after day ten. Partial harassment scenarios add $4–7/bbl of sustained risk premium.',
  },
  {
    id: 'malacca',
    name: 'STRAIT OF MALACCA',
    throughput: '16.0M BBL/D',
    status: 'STABLE',
    transit: transitSeries(202, 16.0, 0.8),
    note1:
      'Malacca remains the shortest sea lane between Middle East supply and Northeast Asian demand. Congestion metrics are within seasonal norms and piracy incident counts sit at a five-year low.',
    note2:
      'The structural watch item is capacity: draft restrictions cap fully-loaded VLCCs, so marginal barrels re-route via Lombok at a 3–4 day delay. Meridian tracks re-routing frequency as an early stress indicator.',
  },
  {
    id: 'suez',
    name: 'SUEZ / SUMED',
    throughput: '5.5M BBL/D',
    status: 'STABLE',
    transit: transitSeries(303, 5.5, 0.7),
    note1:
      'Suez Canal transits and SUMED pipeline flows together carry roughly 5.5M bbl/d of crude and products. Canal authority rebates have kept northbound tanker traffic steady despite Red Sea rerouting pressure further south.',
    note2:
      'SUMED spare capacity (~1.3M bbl/d) provides partial redundancy to canal disruption. Meridian models a canal closure as a freight-rate event rather than a supply event, adding $1–2/bbl to delivered Mediterranean crude.',
  },
  {
    id: 'bab-el-mandeb',
    name: 'BAB EL-MANDEB',
    throughput: '4.8M BBL/D',
    status: 'HIGH',
    transit: transitSeries(404, 4.8, 1.1),
    note1:
      'Transit volumes through the Bab el-Mandeb remain roughly 35% below trailing three-year averages as carriers continue to divert around the Cape of Good Hope. War-risk premia on the corridor are quoted at multi-year highs.',
    note2:
      'Sustained diversion adds 12–14 days to Europe-bound voyages and effectively tightens vessel supply worldwide. Meridian flags any normalization of Red Sea routing as a bearish prompt-spread catalyst worth 2–3% on Brent.',
  },
  {
    id: 'bosphorus',
    name: 'BOSPHORUS',
    throughput: '2.4M BBL/D',
    status: 'STABLE',
    transit: transitSeries(505, 2.4, 0.4),
    note1:
      'Bosphorus flows are dominated by Black Sea crude and CPC blend. Daylight transit rules and convoy scheduling keep throughput near design capacity but operationally predictable.',
    note2:
      'Watch items are winter fog closures and inspection-regime escalation on sanctioned tonnage. Meridian estimates each week of full closure removes ~17M bbl from prompt Mediterranean availability.',
  },
]

export const STATUS_TONE: Record<ChokepointStatus, string> = {
  STABLE: 'bg-positive/10 text-positive',
  ELEVATED: 'bg-solar/15 text-solar-deep',
  HIGH: 'bg-critical/10 text-critical',
}

/* ---------------- KPI sparklines ---------------- */

export function sparkline(seed: number, points = 24, start = 90, end = 100) {
  const rand = mulberry32(seed)
  let v = start
  const step = (end - start) / (points - 1)
  return Array.from({ length: points }, (_, i) => {
    v += step + (rand() - 0.5) * step * 3
    return { i, v: +v.toFixed(2) }
  })
}
