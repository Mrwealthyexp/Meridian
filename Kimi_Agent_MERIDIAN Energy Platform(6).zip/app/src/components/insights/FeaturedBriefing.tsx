import Rise from '@/components/insights/Rise'
import { DomainBadge } from '@/components/badges'
import { useInView } from '@/lib/animation'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'

const ARTICLE_PARAGRAPHS = [
  'Strategic petroleum reserves were designed for a crude-only world: a finite stockpile, drawn down when supply breaks and refilled when prices calm. That doctrine assumed demand for burn-barrel crude would always recover. With the US SPR holding 372M barrels — roughly 52% of capacity — and global solar capacity reaching 1,610 GW, up 24% year over year, that assumption is quietly expiring.',
  'Every gigawatt of solar that enters the mix displaces a slice of transport and generation fuel demand. Our scenario engine estimates that the 612 GW global PV pipeline now under construction removes the equivalent of several large OPEC producers\u2019 worth of incremental demand growth by the end of the decade. For reserve managers, the question is no longer only when to release — it is whether the next refill will ever be needed at the same scale.',
  'The calculus of hold, release, and refill is being rewritten in three places at once. First, the trigger thresholds: import-cover rules built around 94 days of IEA cover were calibrated for crude shocks, not for a grid where midday power is increasingly photonic. Second, the refill window: solar-driven demand erosion flattens the price troughs that reserve buyers historically exploited. Third, the political economy: a barrel held in cavern storage now competes with a megawatt-hour held in batteries and transmission.',
  'None of this makes reserves obsolete. Crude still moves aviation, freight, and petrochemicals, and the Bab el-Mandeb and Hormuz chokepoints have not become safer because panels got cheaper. But it does change the optimal reserve posture: smaller marginal releases, faster rotation, and procurement rules that treat solar build-out data as a leading indicator of how much insurance a barrel in the ground really buys.',
  'The desks that get this right will be the ones reading both systems at once. A reserve strategy that ignores the interconnection queue is flying on instruments from another era — and in a dual-energy world, the spread between the prepared and the surprised compounds every quarter.',
]

function ArticleBody() {
  return (
    <div className="space-y-5 text-[15px] leading-[1.75] text-foreground/85">
      <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
        FIG. 01 — US STRATEGIC PETROLEUM RESERVE, 372M BBL (52% CAPACITY) · SAMPLE DATA
      </p>
      <p>{ARTICLE_PARAGRAPHS[0]}</p>
      <p>{ARTICLE_PARAGRAPHS[1]}</p>
      <blockquote className="border-l-[3px] border-solar py-1 pl-6 font-display text-[22px] italic leading-[1.4] text-foreground">
        “A barrel in a cavern is now priced against a photon on a wire — reserve doctrine
        just hasn’t caught up.”
      </blockquote>
      <p>{ARTICLE_PARAGRAPHS[2]}</p>
      <p>{ARTICLE_PARAGRAPHS[3]}</p>
      <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
        FIG. 02 — GLOBAL PV PIPELINE 612 GW VS. PROJECTED DEMAND DISPLACEMENT · SAMPLE DATA
      </p>
      <p>{ARTICLE_PARAGRAPHS[4]}</p>
      <p className="border-t border-border pt-4 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
        Meridian Research Desk · Sample article for demonstration
      </p>
    </div>
  )
}

/** §2 — Featured briefing card + article dialog. */
export default function FeaturedBriefing() {
  const [ref, inView] = useInView<HTMLDivElement>(0.15)

  return (
    <div ref={ref}>
      <Rise active={inView} y={28} duration={800}>
        <article className="grid overflow-hidden rounded-xl border border-border bg-card lg:grid-cols-2">
          {/* Cover */}
          <div className="relative min-h-[280px] overflow-hidden lg:min-h-full">
            <img
              src="/insights-cover-1.jpg"
              alt="Macro of crude oil surface with golden light reflections"
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-[600ms] ease-out hover:scale-[1.03]"
            />
          </div>

          {/* Body — children stagger 100ms, rise 12px */}
          <div className="flex flex-col justify-center p-8 md:p-10">
            <Rise active={inView} delay={150} y={12} duration={600}>
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center rounded-full bg-solar px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-foreground">
                  Featured
                </span>
                <DomainBadge domain="intersection" />
              </div>
            </Rise>
            <Rise active={inView} delay={250} y={12} duration={600}>
              <h2 className="mt-5 font-display text-[28px] font-medium leading-[1.15] tracking-[-0.01em] text-foreground md:text-[34px]">
                When the SPR meets the solar surplus: reserve strategy in a{' '}
                <span className="italic">dual-energy era</span>.
              </h2>
            </Rise>
            <Rise active={inView} delay={350} y={12} duration={600}>
              <p className="mt-4 line-clamp-3 text-[15px] leading-[1.65] text-muted-foreground">
                Strategic reserves were designed for a crude-only world. As solar displaces
                burn-barrel demand, the calculus of when to hold, release, and refill is being
                rewritten — and the old trigger thresholds no longer hold.
              </p>
            </Rise>
            <Rise active={inView} delay={450} y={12} duration={600}>
              <p className="mt-5 font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
                Meridian Research Desk · 12 min read · Aug 2025
              </p>
            </Rise>
            <Rise active={inView} delay={550} y={12} duration={600}>
              <div className="mt-7">
                <Dialog>
                  <DialogTrigger asChild>
                    <button className="rounded-lg bg-foreground px-5 py-2.5 font-sans text-sm font-semibold text-background transition-all hover:-translate-y-px hover:bg-oil active:scale-[0.97]">
                      Read briefing
                    </button>
                  </DialogTrigger>
                  <DialogContent className="max-h-[85vh] overflow-y-auto border-border bg-card sm:max-w-2xl">
                    <DialogHeader>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="inline-flex items-center rounded-full bg-solar px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-foreground">
                          Featured
                        </span>
                        <DomainBadge domain="intersection" />
                      </div>
                      <DialogTitle className="pt-3 text-left font-display text-2xl font-medium leading-[1.2] tracking-[-0.01em] text-foreground md:text-3xl">
                        When the SPR meets the solar surplus: reserve strategy in a dual-energy
                        era.
                      </DialogTitle>
                      <DialogDescription className="pt-1 text-left font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
                        Meridian Research Desk · 12 min read · Aug 2025
                      </DialogDescription>
                    </DialogHeader>
                    <div className="mt-2 overflow-hidden rounded-lg">
                      <img
                        src="/insights-cover-1.jpg"
                        alt="Macro of crude oil surface with golden light reflections"
                        className="aspect-[3/2] w-full object-cover"
                      />
                    </div>
                    <ArticleBody />
                  </DialogContent>
                </Dialog>
              </div>
            </Rise>
          </div>
        </article>
      </Rise>
    </div>
  )
}
