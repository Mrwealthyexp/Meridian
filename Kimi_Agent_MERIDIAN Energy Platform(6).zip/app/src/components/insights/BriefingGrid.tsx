import { useEffect, useState } from 'react'
import { DomainBadge } from '@/components/badges'
import { useInView } from '@/lib/animation'
import { cn } from '@/lib/utils'

export type BriefingFilter = 'all' | 'oil' | 'solar' | 'intersection' | 'policy'

type BriefingDomain = Exclude<BriefingFilter, 'all'>

type Briefing = {
  title: string
  excerpt: string
  domain: BriefingDomain
  image: string
  imageClass?: string
  date: string
  readTime: string
}

const BRIEFINGS: Briefing[] = [
  {
    title: 'Polysilicon\u2019s floor: what $8.9/kg means for 2026 project economics.',
    excerpt:
      'Module prices at $0.11/W are rewriting procurement math. We model who can still build at these input costs — and who cannot.',
    domain: 'solar',
    image: '/insights-cover-2.jpg',
    date: 'AUG 2025',
    readTime: '8 MIN',
  },
  {
    title: 'Corridor logic: co-siting PV along the world\u2019s pipelines.',
    excerpt:
      'Existing right-of-way, existing security, existing grid proximity. The case for pairing panels with pipe is stronger than it looks.',
    domain: 'intersection',
    image: '/insights-cover-3.jpg',
    date: 'AUG 2025',
    readTime: '10 MIN',
  },
  {
    title: 'Bab el-Mandeb transit risk: three scenarios for Q4.',
    excerpt:
      'Rerouting costs, war-risk premiums, and SPR release triggers — mapped against 41.2M bbl/day of OPEC+ output.',
    domain: 'oil',
    image: '/oil-terminal.jpg',
    imageClass: 'object-bottom',
    date: 'JUL 2025',
    readTime: '7 MIN',
  },
  {
    title: '612 GW and counting: inside the global pipeline audit.',
    excerpt:
      'Our desk re-verified every announced utility-scale project on the books. Here is what survived the audit — and what evaporated.',
    domain: 'solar',
    image: '/solar-field.jpg',
    imageClass: 'object-top',
    date: 'JUL 2025',
    readTime: '9 MIN',
  },
  {
    title: 'Import cover rules after the 2024 stockdraw: a 46-nation review.',
    excerpt:
      'The 94-day IEA benchmark is fracturing. We reviewed stockholding policy across 46 nations to see who is rewriting the rules.',
    domain: 'policy',
    image: '/insights-cover-1.jpg',
    imageClass: 'brightness-[0.65]',
    date: 'JUN 2025',
    readTime: '11 MIN',
  },
  {
    title: 'When refineries host solar: the dual-use terminal playbook.',
    excerpt:
      'Tank farms have land, grid interconnections, and power-hungry operations. The dual-use terminal is the quiet winner of the transition.',
    domain: 'intersection',
    image: '/insights-cover-2.jpg',
    imageClass: 'sepia-[0.4] saturate-[1.25]',
    date: 'JUN 2025',
    readTime: '6 MIN',
  },
]

const TITLE_HOVER: Record<BriefingDomain, string> = {
  oil: 'group-hover:text-oil',
  solar: 'group-hover:text-solar-deep',
  intersection: 'group-hover:text-foreground',
  policy: 'group-hover:text-foreground',
}

function PolicyBadge() {
  return (
    <span className="inline-flex items-center rounded-full bg-foreground/8 px-2.5 py-1 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-foreground">
      Policy
    </span>
  )
}

function BriefingCard({
  briefing,
  index,
  active,
}: {
  briefing: Briefing
  index: number
  active: boolean
}) {
  const [on, setOn] = useState(false)

  useEffect(() => {
    if (!active) return
    const raf = requestAnimationFrame(() => setOn(true))
    return () => cancelAnimationFrame(raf)
  }, [active])

  const shown = on && active
  const delay = Math.min(index, 7) * 90
  const entrance = `opacity 700ms cubic-bezier(0.22,1,0.36,1) ${delay}ms, transform 700ms cubic-bezier(0.22,1,0.36,1) ${delay}ms`

  return (
    <div
      style={{
        opacity: shown ? 1 : 0,
        transform: shown ? 'none' : 'translateY(28px)',
        transition: entrance,
      }}
    >
      <article className="card-lift group flex h-full flex-col overflow-hidden rounded-xl border border-border bg-card hover:border-solar/50">
        <div className="aspect-[3/2] overflow-hidden">
          {/* Entrance wrapper: scale 1.05 -> 1 on reveal; img owns the hover zoom */}
          <div
            className="h-full w-full"
            style={{
              transform: shown ? 'none' : 'scale(1.05)',
              transition: entrance,
            }}
          >
            <img
              src={briefing.image}
              alt={briefing.title}
              loading="lazy"
              className={cn(
                'h-full w-full object-cover transition-transform duration-[600ms] ease-out group-hover:scale-[1.04]',
                briefing.imageClass,
              )}
            />
          </div>
        </div>
        <div className="flex flex-1 flex-col p-6">
          <div>
            {briefing.domain === 'policy' ? (
              <PolicyBadge />
            ) : (
              <DomainBadge domain={briefing.domain} />
            )}
          </div>
          <h3
            className={cn(
              'mt-4 font-sans text-xl font-semibold leading-[1.25] text-foreground/90 transition-colors duration-200',
              TITLE_HOVER[briefing.domain],
            )}
          >
            {briefing.title}
          </h3>
          <p className="mt-2.5 line-clamp-2 text-sm leading-[1.6] text-muted-foreground">
            {briefing.excerpt}
          </p>
          <p className="mt-auto pt-5 font-mono text-[10px] uppercase tracking-[0.14em] text-muted-foreground/80">
            {briefing.date} · {briefing.readTime}
          </p>
        </div>
      </article>
    </div>
  )
}

/** §3 — Filterable briefing grid; fresh 90ms stagger on every filter change. */
export default function BriefingGrid({ filter }: { filter: BriefingFilter }) {
  const [ref, inView] = useInView<HTMLDivElement>(0.1)
  const visible =
    filter === 'all' ? BRIEFINGS : BRIEFINGS.filter((b) => b.domain === filter)

  return (
    <div ref={ref} className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {visible.map((briefing, i) => (
        <BriefingCard
          key={`${filter}-${briefing.title}`}
          briefing={briefing}
          index={i}
          active={inView}
        />
      ))}
    </div>
  )
}
