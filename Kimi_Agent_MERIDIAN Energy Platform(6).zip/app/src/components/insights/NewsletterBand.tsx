import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { toast } from 'sonner'
import { trpc } from '@/providers/trpc'
import { useReveal } from '@/lib/animation'
import { cn } from '@/lib/utils'

const wireSchema = z.object({
  email: z.email('ENTER A VALID EMAIL ADDRESS'),
})

type WireValues = z.infer<typeof wireSchema>

/** §4 — The Meridian Wire newsletter band (the page's one dark band). */
export default function NewsletterBand() {
  const ref = useReveal<HTMLDivElement>(0.2)
  const [subscribed, setSubscribed] = useState(false)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<WireValues>({
    resolver: zodResolver(wireSchema),
    defaultValues: { email: '' },
  })

  const subscribeMutation = trpc.forms.subscribe.useMutation({
    onSuccess: () => {
      toast.success("You're on the Wire — welcome.")
      reset()
      setSubscribed(true)
      window.setTimeout(() => setSubscribed(false), 2400)
    },
    onError: () => toast.error('Subscription failed — please try again.'),
  })

  const onSubmit = handleSubmit((values) => {
    subscribeMutation.mutate({ email: values.email, source: 'wire' })
  })

  return (
    <section className="bg-terminal-bg py-20">
      <div ref={ref} data-reveal className="mx-auto max-w-2xl px-6 text-center md:px-10">
        <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-terminal-amber">
          // THE MERIDIAN WIRE
        </p>
        <h2 className="mt-3 font-display text-3xl font-medium leading-[1.1] tracking-[-0.01em] text-terminal-text md:text-4xl">
          One wire. Both worlds. <span className="italic">Weekly.</span>
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-[15px] leading-[1.65] text-terminal-text/70">
          Oil supply moves and solar market signals, distilled by our desks every Monday 06:00
          UTC.
        </p>

        <form onSubmit={onSubmit} noValidate className="mt-8">
          <div className="flex flex-col gap-3 sm:flex-row">
            <input
              type="email"
              placeholder="you@office.gov"
              aria-label="Email address"
              aria-invalid={!!errors.email}
              {...register('email')}
              className={cn(
                'min-w-0 flex-1 rounded-md border bg-terminal-surface px-4 py-3 font-mono text-sm text-terminal-text placeholder:text-terminal-text/30',
                'transition-all duration-200 focus:scale-[1.01] focus:outline-none focus:ring-1 focus:ring-terminal-amber',
                errors.email ? 'border-critical' : 'border-terminal-border',
              )}
            />
            <button
              type="submit"
              className={cn(
                'relative shrink-0 overflow-hidden rounded-md px-6 py-3 font-sans text-sm font-semibold transition-all hover:-translate-y-px active:scale-[0.97]',
                subscribed
                  ? 'bg-positive text-white'
                  : 'bg-solar text-foreground hover:bg-terminal-amber',
              )}
            >
              <span
                className={cn(
                  'block transition-opacity duration-300',
                  subscribed ? 'opacity-0' : 'opacity-100',
                )}
              >
                Subscribe
              </span>
              <span
                aria-hidden={!subscribed}
                className={cn(
                  'absolute inset-0 flex items-center justify-center font-mono text-xs tracking-[0.08em] transition-opacity duration-300',
                  subscribed ? 'opacity-100' : 'opacity-0',
                )}
              >
                ✓ SUBSCRIBED
              </span>
            </button>
          </div>
          {errors.email && (
            <p className="mt-2 text-left font-mono text-[11px] tracking-[0.06em] text-critical">
              {errors.email.message}
            </p>
          )}
        </form>

        <p className="mt-5 font-mono text-[10px] uppercase tracking-[0.14em] text-terminal-text/40">
          No spam · Unsubscribe anytime · Sample form
        </p>
      </div>
    </section>
  )
}
