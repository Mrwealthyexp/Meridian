import { Routes, Route } from 'react-router'
import Layout from '@/components/Layout'
import Home from '@/pages/Home'
import Dashboard from '@/pages/Dashboard'
import OilSupply from '@/pages/OilSupply'
import SolarEnergy from '@/pages/SolarEnergy'
import Services from '@/pages/Services'
import Insights from '@/pages/Insights'
import About from '@/pages/About'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="oil-supply" element={<OilSupply />} />
        <Route path="solar-energy" element={<SolarEnergy />} />
        <Route path="services" element={<Services />} />
        <Route path="insights" element={<Insights />} />
        <Route path="about" element={<About />} />
        <Route path="*" element={<Home />} />
      </Route>
    </Routes>
  )
}
