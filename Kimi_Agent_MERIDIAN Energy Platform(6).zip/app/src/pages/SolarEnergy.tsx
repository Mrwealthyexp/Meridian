import SolarHero from '@/components/solar/SolarHero'
import SolarKpiStrip from '@/components/solar/SolarKpiStrip'
import CapacityCharts from '@/components/solar/CapacityCharts'
import PipelineTracker from '@/components/solar/PipelineTracker'
import IrradianceMap from '@/components/solar/IrradianceMap'
import LcoeCurve from '@/components/solar/LcoeCurve'
import SolarCta from '@/components/solar/SolarCta'

export default function SolarEnergy() {
  return (
    <>
      <SolarHero />
      <SolarKpiStrip />
      <CapacityCharts />
      <PipelineTracker />
      <IrradianceMap />
      <LcoeCurve />
      <SolarCta />
    </>
  )
}
