import ServicesHero from '@/components/services/ServicesHero'
import ServiceCatalog from '@/components/services/ServiceCatalog'
import OpportunityMap from '@/components/services/OpportunityMap'
import EngagementTiers from '@/components/services/EngagementTiers'
import ProofStrip from '@/components/services/ProofStrip'
import ServicesCta from '@/components/services/ServicesCta'

/**
 * /services — "Where We're Needed"
 * Service catalog + interactive opportunity map at the oil<->solar
 * intersection, engagement models, proof metrics, and CTA.
 */
export default function Services() {
  return (
    <>
      {/* Page-local keyframes (prefixed svc-) for the hero cinematics and
          the opportunity-map detail panel cross-fade. */}
      <style>{`
        @keyframes svc-hero-in {
          from { transform: scale(1.08); }
          to { transform: scale(1); }
        }
        @keyframes svc-kenburns {
          from { transform: scale(1) translateY(0); }
          to { transform: scale(1.05) translateY(-8px); }
        }
        @keyframes svc-scrim-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes svc-rise-in {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes svc-panel-in {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .svc-hero-img {
          animation:
            svc-hero-in 1600ms ease-out both,
            svc-kenburns 20s ease-in-out 1600ms infinite alternate;
          will-change: transform;
        }
        .svc-hero-scrim {
          animation: svc-scrim-in 800ms ease-out both;
        }
        .svc-hero-rise {
          animation: svc-rise-in 600ms ease-out 300ms both;
        }
        .svc-panel-in {
          animation: svc-panel-in 350ms ease-out both;
        }
        @media (prefers-reduced-motion: reduce) {
          .svc-hero-img,
          .svc-hero-scrim,
          .svc-hero-rise,
          .svc-panel-in {
            animation-duration: 0.01ms !important;
            animation-delay: 0ms !important;
            animation-iteration-count: 1 !important;
          }
        }
      `}</style>

      <ServicesHero />
      <ServiceCatalog />
      <OpportunityMap />
      <EngagementTiers />
      <ProofStrip />
      <ServicesCta />
    </>
  )
}
