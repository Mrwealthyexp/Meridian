import { useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { Link } from 'react-router'
import {
  ArrowRight,
  Check,
  Database,
  GitMerge,
  PanelsTopLeft,
  Radio,
  TrendingUpDown,
} from 'lucide-react'
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from 'recharts'
import BalanceSlider from '@/components/home/BalanceSlider'
import Words from '@/components/home/Words'
import SectionHeader from '@/components/SectionHeader'
import { DomainBadge } from '@/components/badges'
import { useCountUp, useInView, useReveal } from '@/lib/animation'
import { cn } from '@/lib/utils'

/* ---------------------------------------------------------------- */
/* Helpers                                                           */
/* ---------------------------------------------------------------- */

const EASE = 'cubic-bezier(0.22,1,0.36,1)'

/** Load-sequence entrance: rises/fades once on mount with a delay. */
function HeroIn({
  delay = 0,
  duration = 700,
  x = 0,
  y = 24,
  className,
  children,
}: {
  delay?: number
  duration?: number
  x?: number
  y?: number
  className?: string
  children: ReactNode
}) {
  const [on, setOn] = useState(false)
  useEffect(() => {
    const raf = requestAnimationFrame(() => setOn(true))
    return () => cancelAnimationFrame(raf)
  }, [])
  return (
    <div
      className={className}
      style={{
        opacity: on ? 1 : 0,
        transform: on ? 'none' : `translate(${x}px, ${y}px)`,
        transition: `opacity ${duration}ms ${EASE} ${delay}ms, transform ${duration}ms ${EASE} ${delay}ms`,
      }}
    >
      {children}
    </div>
  )
}

/* ---------------------------------------------------------------- */
/* Section 1 — The Duality Hero                                      */
/* ---------------------------------------------------------------- */

function Hero() {
  const [balance, setBalance] = useState(50)
  const [mounted, setMounted] = useState(false)
  const textRef = useRef<HTMLDivElement | null>(null)
  const imgWrapRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 30)
    return () => clearTimeout(t)
  }, [])

  // Scroll parallax — text 0.15×, image 0.05× (reduced-motion safe)
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    let raf = 0
    const onScroll = () => {
      cancelAnimationFrame(raf)
      raf = requestAnimationFrame(() => {
        const y = window.scrollY
        if (textRef.current) textRef.current.style.transform = `translateY(${y * 0.15}px)`
        if (imgWrapRef.current) imgWrapRef.current.style.transform = `translateY(${y * 0.05}px)`
      })
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => {
      window.removeEventListener('scroll', onScroll)
      cancelAnimationFrame(raf)
    }
  }, [])

  // Glow cross-fade: 0 = full teal, 100 = full amber, 50 = both at 60%
  const tealGlow = 1 - 0.8 * (balance / 100)
  const amberGlow = 0.2 + 0.8 * (balance / 100)
  const mode: 'oil' | 'solar' | 'neutral' =
    balance <= 49 ? 'oil' : balance >= 51 ? 'solar' : 'neutral'

  return (
    <section
      className="relative flex min-h-[92vh] flex-col overflow-hidden pb-24 pt-16 md:pt-20"
      style={{ background: 'linear-gradient(180deg, #F6F2EA 0%, #F1E9D8 100%)' }}
    >
      {/* Breathing radial glows, cross-faded by the balance slider */}
      <div
        className="pointer-events-none absolute -left-40 top-10 h-[700px] w-[700px] transition-opacity duration-500"
        style={{ opacity: tealGlow }}
      >
        <div
          className="h-full w-full animate-glow-breathe rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(14,90,80,0.16) 0%, transparent 70%)',
          }}
        />
      </div>
      <div
        className="pointer-events-none absolute -right-40 bottom-0 h-[700px] w-[700px] transition-opacity duration-500"
        style={{ opacity: amberGlow }}
      >
        <div
          className="h-full w-full animate-glow-breathe rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(247,201,72,0.28) 0%, transparent 70%)',
          }}
        />
      </div>

      {/* Duality image melting into the paper background */}
      <div ref={imgWrapRef} className="pointer-events-none absolute bottom-0 right-0 w-[92%] md:w-[58%]">
        <img
          src="/hero-duality.png"
          alt="Solar field at golden hour with a distant refinery skyline"
          className="h-auto w-full"
          style={{
            opacity: mounted ? 0.55 : 0,
            transform: mounted ? 'scale(1)' : 'scale(1.06)',
            transition: 'opacity 1600ms ease-out, transform 1600ms ease-out',
            maskImage:
              'linear-gradient(to top, black 55%, transparent 98%), linear-gradient(to right, transparent, black 30%)',
            maskComposite: 'intersect',
            WebkitMaskImage:
              'linear-gradient(to top, black 55%, transparent 98%), linear-gradient(to right, transparent, black 30%)',
            WebkitMaskComposite: 'source-in',
          }}
        />
      </div>

      {/* Content */}
      <div ref={textRef} className="relative z-10 mx-auto w-full max-w-[1200px] px-6 md:px-10">
        <HeroIn delay={100} duration={400} x={-20} y={0}>
          <p
            className={cn(
              'flex items-center gap-3 font-mono text-xs font-semibold uppercase tracking-[0.18em] transition-colors duration-300',
              mode === 'oil' && 'text-oil',
              mode === 'solar' && 'text-solar-deep',
              mode === 'neutral' && 'text-muted-foreground',
            )}
          >
            <span className="h-px w-6 bg-solar" />
            // MERIDIAN ENERGY INTELLIGENCE
          </p>
        </HeroIn>

        <h1
          className="mt-6 max-w-4xl font-display text-[42px] font-medium leading-[1.02] tracking-[-0.02em] text-foreground md:text-[76px]"
          style={{ fontVariationSettings: "'opsz' 144" }}
        >
          <Words
            active={mounted}
            delayStart={250}
            stagger={60}
            segments={[
              { text: 'Strategic oil supply.' },
              { text: 'Solar energy.' },
              { text: 'One intelligence platform.', italic: true },
            ]}
          />
        </h1>

        <HeroIn delay={700} duration={600} y={16} className="mt-6 max-w-xl">
          <p className="text-[17px] leading-[1.6] text-muted-foreground md:text-lg">
            Meridian delivers the data, analytics, and services that governments,
            traders, and operators need — across the entire energy system, from
            crude reserves to photovoltaic pipelines.
          </p>
        </HeroIn>

        <div className="mt-8 flex flex-wrap items-center gap-4">
          <HeroIn delay={900} duration={500} y={16}>
            <Link
              to="/dashboard"
              className="group inline-flex items-center gap-2 rounded-lg bg-solar px-5 py-3 font-sans text-[15px] font-semibold text-foreground transition-all hover:-translate-y-px hover:bg-solar-deep hover:text-white active:scale-[0.97]"
            >
              Explore the Dashboard
              <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </HeroIn>
          <HeroIn delay={1050} duration={500} y={16}>
            <Link
              to="/services"
              className="inline-flex items-center rounded-lg border border-foreground/20 px-5 py-3 font-sans text-[15px] font-semibold text-foreground transition-colors hover:border-foreground/60 hover:bg-foreground/5"
            >
              Where we&rsquo;re needed
            </Link>
          </HeroIn>
        </div>

        <HeroIn delay={1200} duration={700} y={24} className="mt-14 max-w-2xl">
          <BalanceSlider value={balance} onChange={setBalance} />
        </HeroIn>
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- */
/* Section 2 — Live Stat Band (dark terminal band)                   */
/* ---------------------------------------------------------------- */

const intFmt = new Intl.NumberFormat('en-US')

function StatCell({
  label,
  value,
  format,
  delta,
  direction,
  amber,
  active,
  index,
}: {
  label: string
  value: number
  format: (v: number) => string
  delta?: string
  direction?: 'up' | 'down'
  amber?: boolean
  active: boolean
  index: number
}) {
  const v = useCountUp(value, active, 1400)
  return (
    <div
      className="border-terminal-border px-6 py-2 first:border-l-0 md:border-l"
      style={{ ['--i' as string]: index }}
    >
      <p className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-terminal-text/50">
        {label}
      </p>
      <p
        className={cn(
          'mt-2 font-mono text-[30px] font-medium leading-[1.1] tracking-[-0.01em] tabular-nums md:text-[40px]',
          amber ? 'text-terminal-amber' : 'text-terminal-text',
        )}
      >
        {format(v)}
      </p>
      {delta && direction && (
        <span
          className={cn(
            'mt-3 inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-mono text-[11px] font-medium tabular-nums transition-transform duration-300',
            direction === 'up' ? 'bg-positive/15 text-positive' : 'bg-critical/15 text-critical',
          )}
          style={{
            transform: active ? 'scale(1)' : 'scale(0.8)',
            transitionDelay: '1550ms',
          }}
        >
          {direction === 'up' ? '▲' : '▼'} {delta}
        </span>
      )}
    </div>
  )
}

function StatBand() {
  const [countRef, inView] = useInView<HTMLDivElement>(0.4)
  const gridRef = useReveal<HTMLDivElement>(0.15)

  const setRefs = (el: HTMLDivElement | null) => {
    countRef.current = el
    gridRef.current = el
  }

  return (
    <section className="bg-terminal-bg py-10">
      <div className="mx-auto max-w-[1360px] px-6 md:px-10">
        <div
          ref={setRefs}
          data-reveal-stagger
          className="grid grid-cols-2 gap-y-6 md:grid-cols-4"
        >
          <StatCell
            label="WTI Crude"
            value={78.42}
            format={(v) => `$${v.toFixed(2)}`}
            delta="0.8%"
            direction="up"
            amber
            active={inView}
            index={0}
          />
          <StatCell
            label="Global Solar Capacity"
            value={1610}
            format={(v) => `${intFmt.format(Math.round(v))} GW`}
            delta="24% YOY"
            direction="up"
            active={inView}
            index={1}
          />
          <StatCell
            label="Strategic Reserves Tracked"
            value={46}
            format={(v) => `${Math.round(v)} NATIONS`}
            active={inView}
            index={2}
          />
          <StatCell
            label="PV Project Pipeline"
            value={612}
            format={(v) => `${Math.round(v)} GW`}
            delta="9% QOQ"
            direction="up"
            active={inView}
            index={3}
          />
        </div>
        <p className="mt-8 text-right font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-terminal-text/40">
          Updated 09:42 UTC · Sample Data
        </p>
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- */
/* Section 3 — Two Worlds (domain previews)                          */
/* ---------------------------------------------------------------- */

function MiniStat({
  value,
  format,
  unit,
  active,
  index,
}: {
  value: number
  format?: (v: number) => string
  unit: string
  active: boolean
  index: number
}) {
  const [start, setStart] = useState(false)
  useEffect(() => {
    if (!active) return
    const t = setTimeout(() => setStart(true), index * 120)
    return () => clearTimeout(t)
  }, [active, index])
  const v = useCountUp(value, start, 900)
  return (
    <div>
      <p className="font-mono text-sm font-semibold tabular-nums text-foreground">
        {format ? format(v) : intFmt.format(Math.round(v))}
      </p>
      <p className="mt-0.5 font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
        {unit}
      </p>
    </div>
  )
}

type DomainCardProps = {
  image: string
  badge: 'oil' | 'solar'
  caption: string
  title: string
  copy: string
  stats: { value: number; format?: (v: number) => string; unit: string }[]
  link: string
  linkLabel: string
  scrim: string
}

function DomainCard({
  image,
  badge,
  caption,
  title,
  copy,
  stats,
  link,
  linkLabel,
  scrim,
}: DomainCardProps) {
  const ref = useReveal<HTMLElement>(0.15)
  const [statRef, statsInView] = useInView<HTMLDivElement>(0.4)
  const accent = badge === 'oil' ? 'text-oil' : 'text-solar-deep'

  return (
    <article
      ref={ref}
      data-reveal
      className="card-lift group overflow-hidden rounded-xl border border-border bg-card hover:border-foreground/20"
    >
      <div className="relative aspect-[16/10] overflow-hidden">
        <div
          className="h-full w-full scale-[1.08] transition-transform ease-out group-[.is-revealed]:scale-100"
          style={{ transitionDuration: '1200ms' }}
        >
          <img
            src={image}
            alt={title}
            className="h-full w-full object-cover transition-transform ease-out group-hover:scale-[1.04]"
            style={{ transitionDuration: '600ms' }}
          />
        </div>
        <div
          className="absolute inset-0 opacity-80 transition-opacity duration-300 group-hover:opacity-100"
          style={{ background: scrim }}
        />
        <div className="absolute bottom-4 left-4 flex items-center gap-3">
          <DomainBadge domain={badge} className="bg-card/90" />
          <span className="font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-white/90">
            {caption}
          </span>
        </div>
      </div>
      <div className="p-8">
        <h3 className="font-sans text-[22px] font-semibold leading-[1.25] text-foreground">
          {title}
        </h3>
        <p className="mt-2 text-[15px] leading-[1.65] text-muted-foreground">{copy}</p>
        <div ref={statRef} className="mt-6 grid grid-cols-3 gap-4 border-t border-border pt-5">
          {stats.map((s, i) => (
            <MiniStat key={s.unit} {...s} active={statsInView} index={i} />
          ))}
        </div>
        <Link
          to={link}
          className={cn(
            'group/link mt-6 inline-flex items-center gap-1.5 font-sans text-sm font-semibold',
            accent,
          )}
        >
          {linkLabel}
          <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover/link:translate-x-1" />
        </Link>
      </div>
    </article>
  )
}

function TwoWorlds() {
  return (
    <section className="py-24 md:py-32">
      <div className="mx-auto max-w-[1200px] px-6 md:px-10">
        <SectionHeader
          eyebrow="// TWO WORLDS, ONE PLATFORM"
          title={
            <>
              From wellhead economics to <em className="italic">watt-hour</em> forecasting.
            </>
          }
          lede="Meridian's twin data engines cover the full spectrum of modern energy strategy."
        />
        <div className="mt-14 grid gap-8 md:grid-cols-2">
          <DomainCard
            image="/oil-terminal.jpg"
            badge="oil"
            caption="SPR Watch · 46 Nations"
            title="Strategic Oil Supply"
            copy="Reserve levels, supply-chain chokepoints, benchmark pricing, and geopolitical risk — modeled daily."
            stats={[
              { value: 372, unit: 'M BBL · US SPR' },
              { value: 41.2, format: (v) => v.toFixed(1) + 'M', unit: 'BBL/D · OPEC+' },
              { value: 94, unit: 'DAYS · IEA COVER' },
            ]}
            link="/oil-supply"
            linkLabel="Enter the oil module"
            scrim="linear-gradient(to top, rgba(9,59,53,0.85), transparent 55%)"
          />
          <DomainCard
            image="/solar-field.jpg"
            badge="solar"
            caption="Pipeline · 612 GW"
            title="Solar Energy"
            copy="Capacity, generation, project pipelines, and cost curves — tracked across 120 markets."
            stats={[
              { value: 1610, unit: 'GW · INSTALLED' },
              { value: 0.11, format: (v) => '$' + v.toFixed(2), unit: '/W · MODULES' },
              { value: 120, unit: 'MARKETS' },
            ]}
            link="/solar-energy"
            linkLabel="Enter the solar module"
            scrim="linear-gradient(to top, rgba(181,115,9,0.75), transparent 55%)"
          />
        </div>
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- */
/* Section 4 — Where We're Needed (teaser)                           */
/* ---------------------------------------------------------------- */

const FRONTIERS = [
  {
    icon: TrendingUpDown,
    title: 'Transition Analytics',
    copy: 'Oil-to-solar portfolio modeling for national planners.',
    accent: 'split' as const,
  },
  {
    icon: Database,
    title: 'Reserve & Storage Intelligence',
    copy: 'SPR levels, tank farms, and flow data in one feed.',
    accent: 'oil' as const,
  },
  {
    icon: PanelsTopLeft,
    title: 'Solar Pipeline Tracking',
    copy: 'Every utility-scale project, from permit to grid-tie.',
    accent: 'solar' as const,
  },
  {
    icon: GitMerge,
    title: 'Hybrid Infrastructure Advisory',
    copy: 'Siting solar alongside legacy oil assets.',
    accent: 'split' as const,
  },
  {
    icon: Radio,
    title: 'Market Signal Feeds',
    copy: 'Benchmark prices and PV indices, API-delivered.',
    accent: 'solar' as const,
  },
]

function FrontierTile({
  icon: Icon,
  title,
  copy,
  accent,
  index,
}: (typeof FRONTIERS)[number] & { index: number }) {
  return (
    <div
      style={{ ['--i' as string]: index }}
      className={cn(
        'group w-[220px] shrink-0 rounded-xl border border-border bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-signature lg:w-auto',
        accent === 'oil' && 'hover:border-oil/60',
        accent === 'solar' && 'hover:border-solar/60',
        accent === 'split' && 'hover:border-bronze/60',
      )}
    >
      <div className="flex items-start justify-between">
        <span className="font-mono text-[13px] font-medium tabular-nums text-muted-foreground">
          {String(index + 1).padStart(2, '0')}
        </span>
        <span
          className={cn(
            'flex h-10 w-10 items-center justify-center rounded-lg transition-colors duration-300',
            accent === 'oil' && 'bg-oil/10 text-oil group-hover:bg-oil/20',
            accent === 'solar' && 'bg-solar/10 text-solar-deep group-hover:bg-solar/20',
            accent === 'split' &&
              'text-foreground group-hover:bg-[linear-gradient(135deg,rgba(14,90,80,0.2),rgba(233,163,25,0.2))] bg-[linear-gradient(135deg,rgba(14,90,80,0.1),rgba(233,163,25,0.1))]',
          )}
        >
          <Icon className="h-5 w-5" />
        </span>
      </div>
      <h3 className="mt-4 font-sans text-lg font-semibold leading-[1.25] text-foreground">
        {title}
      </h3>
      <p className="mt-1.5 text-[13px] leading-[1.5] text-muted-foreground">{copy}</p>
    </div>
  )
}

function WhereNeeded() {
  const ref = useReveal<HTMLDivElement>(0.15)
  const linkRef = useReveal<HTMLDivElement>(0.15)
  return (
    <section className="bg-muted/40 py-24 md:py-32">
      <div className="mx-auto max-w-[1200px] px-6 md:px-10">
        <SectionHeader
          align="center"
          eyebrow="// WHERE WE'RE NEEDED"
          title={
            <>
              The energy transition runs on <em className="italic">information</em>.
            </>
          }
          lede="Five frontiers where Meridian's data and services become indispensable."
        />
        <div
          ref={ref}
          data-reveal-stagger
          className="mt-14 flex gap-6 overflow-x-auto pb-4 lg:grid lg:grid-cols-5 lg:overflow-visible lg:pb-0"
        >
          {FRONTIERS.map((f, i) => (
            <FrontierTile key={f.title} {...f} index={i} />
          ))}
        </div>
        <div data-reveal className="mt-10 text-center" ref={linkRef}>
          <Link
            to="/services"
            className="group inline-flex items-center gap-1.5 font-sans text-sm font-semibold text-foreground"
          >
            See the full opportunity map
            <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- */
/* Section 5 — Platform in Numbers + Mini Chart                      */
/* ---------------------------------------------------------------- */

const CHART_DATA = Array.from({ length: 24 }, (_, i) => {
  const t = i / 23
  return {
    month: `M${i + 1}`,
    oil: Math.round(100 + 14 * t + 4 * Math.sin(i * 0.9)),
    solar: Math.round(100 + 118 * Math.pow(t, 1.4) + 6 * Math.sin(i * 0.7)),
  }
})

const CHECKLIST = [
  'Daily-updated oil supply and reserve models',
  'Solar capacity and pipeline data across 120 markets',
  'API, dashboard, and advisory delivery',
]

function MiniChart() {
  const [ref, inView] = useInView<HTMLDivElement>(0.3)
  const [solarOn, setSolarOn] = useState(false)

  useEffect(() => {
    if (!inView) return
    const t = setTimeout(() => setSolarOn(true), 300)
    return () => clearTimeout(t)
  }, [inView])

  return (
    <div ref={ref} className="rounded-xl border border-border bg-card p-6 shadow-signature">
      <div className="flex items-center gap-5">
        <span className="flex items-center gap-2 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
          <span className="h-2 w-2 rounded-full bg-oil" /> Oil Supply Index
        </span>
        <span className="flex items-center gap-2 font-mono text-[11px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
          <span className="h-2 w-2 rounded-full bg-solar" /> Solar Generation Index
        </span>
      </div>
      <div className="mt-4 h-64">
        {inView && (
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={CHART_DATA} margin={{ top: 4, right: 4, bottom: 0, left: 4 }}>
              <XAxis
                dataKey="month"
                tick={{ fontFamily: 'IBM Plex Mono', fontSize: 10, fill: '#6E675B' }}
                tickLine={false}
                axisLine={{ stroke: '#E2DACB' }}
                interval={5}
              />
              <Tooltip
                contentStyle={{
                  background: '#FCFAF5',
                  border: '1px solid #E2DACB',
                  borderRadius: 10,
                  fontFamily: 'IBM Plex Mono',
                  fontSize: 12,
                }}
                labelStyle={{ color: '#6E675B' }}
              />
              <Area
                type="monotone"
                dataKey="oil"
                name="Oil supply index"
                stroke="#0E5A50"
                strokeWidth={2}
                fill="#0E5A50"
                fillOpacity={0.12}
                isAnimationActive
                animationDuration={1200}
                animationEasing="ease-out"
              />
              {solarOn && (
                <Area
                  type="monotone"
                  dataKey="solar"
                  name="Solar generation index"
                  stroke="#E9A319"
                  strokeWidth={2}
                  fill="#E9A319"
                  fillOpacity={0.18}
                  isAnimationActive
                  animationDuration={1200}
                  animationEasing="ease-out"
                />
              )}
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>
      <p className="mt-3 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        Monthly indexed output · Sample data
      </p>
    </div>
  )
}

function PlatformNumbers() {
  const leftRef = useReveal<HTMLDivElement>(0.15)
  const chartRef = useReveal<HTMLDivElement>(0.15)

  return (
    <section className="py-24 md:py-32">
      <div className="mx-auto grid max-w-[1200px] items-center gap-16 px-6 md:px-10 lg:grid-cols-2">
        <div ref={leftRef} data-reveal-stagger>
          <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
            // THE PLATFORM
          </p>
          <h2 className="mt-3 font-display text-3xl font-medium leading-[1.1] tracking-[-0.01em] text-foreground md:text-[42px]">
            One feed. <em className="italic">Every electron and barrel.</em>
          </h2>
          <ul className="mt-8 space-y-4">
            {CHECKLIST.map((item) => (
              <li key={item} className="flex items-start gap-3">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-solar/15">
                  <Check className="h-3.5 w-3.5 text-solar-deep" />
                </span>
                <span className="text-[15px] leading-[1.65] text-foreground">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        <div ref={chartRef} data-reveal>
          <MiniChart />
        </div>
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- */
/* Section 6 — Featured Insight (editorial card)                     */
/* ---------------------------------------------------------------- */

function FeaturedInsight() {
  const ref = useReveal<HTMLElement>(0.15)
  return (
    <section className="pb-24 md:pb-32">
      <div className="mx-auto max-w-[1200px] px-6 md:px-10">
        <article
          ref={ref}
          data-reveal
          className="card-lift group grid overflow-hidden rounded-xl border border-border bg-card lg:grid-cols-5"
        >
          <div className="relative aspect-[3/2] overflow-hidden lg:col-span-2 lg:aspect-auto">
            <img
              src="/insights-cover-1.jpg"
              alt="Golden light reflecting on a crude oil surface"
              className="absolute inset-0 h-full w-full object-cover transition-transform ease-out group-hover:scale-[1.03]"
              style={{ transitionDuration: '600ms' }}
            />
          </div>
          <div className="p-10 lg:col-span-3">
            <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              // FEATURED BRIEFING
            </p>
            <h3 className="mt-4 font-display text-[28px] font-medium leading-[1.15] tracking-[-0.01em] text-foreground">
              When the SPR meets the solar surplus: reserve strategy in a
              dual-energy era.
            </h3>
            <p className="mt-4 line-clamp-2 text-[15px] leading-[1.65] text-muted-foreground">
              Strategic reserves were designed for a crude-only world. As solar
              surpluses reshape intraday demand curves, the calculus of when to
              hold, release, and refill is being rewritten — and the planners who
              see both systems at once will write the rules.
            </p>
            <p className="mt-6 font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
              12 min read · Energy security · Aug 2025
            </p>
            <Link
              to="/insights"
              className="mt-6 inline-flex items-center gap-1.5 font-sans text-sm font-semibold text-foreground"
            >
              Read the briefing
              <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
            </Link>
          </div>
        </article>
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- */
/* Section 7 — CTA band (closing)                                    */
/* ---------------------------------------------------------------- */

function CtaBand() {
  const [ref, inView] = useInView<HTMLDivElement>(0.2)

  return (
    <section className="py-24 md:py-32">
      <div ref={ref} className="mx-auto max-w-[1200px] px-6 text-center md:px-10">
        <p className="font-mono text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
          // REQUEST ACCESS
        </p>
        <h2
          className="mx-auto mt-4 max-w-3xl font-display text-4xl font-medium leading-[1.05] tracking-[-0.015em] text-foreground md:text-5xl"
          style={{ fontVariationSettings: "'opsz' 144" }}
        >
          <Words
            active={inView}
            stagger={50}
            segments={[
              { text: 'Put the whole energy system' },
              { text: 'within your grasp.', italic: true },
            ]}
          />
        </h2>
        <div
          className="mx-auto mt-6 h-0.5 w-24 origin-center bg-solar transition-transform ease-out"
          style={{ transitionDuration: '600ms', transform: inView ? 'scaleX(1)' : 'scaleX(0)' }}
        />
        <p className="mx-auto mt-6 max-w-xl text-[17px] leading-[1.6] text-muted-foreground md:text-lg">
          Meridian is onboarding national energy offices, trading desks, and
          infrastructure funds.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <span
            className="inline-block transition-all duration-500 ease-out"
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? 'none' : 'translateY(16px)',
              transitionDelay: '200ms',
            }}
          >
            <Link
              to="/about#contact"
              className="inline-flex items-center gap-2 rounded-lg bg-solar px-6 py-3.5 font-sans text-[15px] font-semibold text-foreground transition-all hover:-translate-y-px hover:bg-solar-deep hover:text-white active:scale-[0.97]"
            >
              Request Access
              <ArrowRight className="h-4 w-4" />
            </Link>
          </span>
          <span
            className="inline-block transition-all duration-500 ease-out"
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? 'none' : 'translateY(16px)',
              transitionDelay: '400ms',
            }}
          >
            <Link
              to="/services"
              className="inline-flex items-center rounded-lg border border-foreground/20 px-6 py-3.5 font-sans text-[15px] font-semibold text-foreground transition-colors hover:border-foreground/60 hover:bg-foreground/5"
            >
              Explore services
            </Link>
          </span>
        </div>
      </div>
    </section>
  )
}

/* ---------------------------------------------------------------- */

export default function Home() {
  return (
    <>
      <Hero />
      <StatBand />
      <TwoWorlds />
      <WhereNeeded />
      <PlatformNumbers />
      <FeaturedInsight />
      <CtaBand />
    </>
  )
}
