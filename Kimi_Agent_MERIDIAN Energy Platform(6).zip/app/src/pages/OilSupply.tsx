import OilHero from '@/components/oil/OilHero'
import OilKpiStrip from '@/components/oil/OilKpiStrip'
import PriceCenter from '@/components/oil/PriceCenter'
import ReserveChokepoint from '@/components/oil/ReserveChokepoint'
import SupplyFlow from '@/components/oil/SupplyFlow'
import RiskBrief from '@/components/oil/RiskBrief'
import OilCta from '@/components/oil/OilCta'

export default function OilSupply() {
  return (
    <>
      <OilHero />
      <OilKpiStrip />
      <PriceCenter />
      <ReserveChokepoint />
      <SupplyFlow />
      <RiskBrief />
      <OilCta />
    </>
  )
}
