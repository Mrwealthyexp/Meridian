import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import { RefreshCw } from 'lucide-react'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { useInView } from '@/lib/animation'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { KPIS, RANGES, REGIONS } from '@/components/dashboard/data'
import type { RangeKey, RegionKey } from '@/components/dashboard/data'
import KpiCard from '@/components/dashboard/KpiCard'
import EnergyBalance from '@/components/dashboard/EnergyBalance'
import StressGauge from '@/components/dashboard/StressGauge'
import RegionMap from '@/components/dashboard/RegionMap'
import Watchlist from '@/components/dashboard/Watchlist'
import AlertsFeed from '@/components/dashboard/AlertsFeed'

export default function Dashboard() {
  // Region filter — header Select and map hotspot clicks share this state.
  // displayRegion lags 200ms behind `region` to drive the 400ms cross-fade.
  const [region, setRegionState] = useState<RegionKey>('global')
  const [displayRegion, setDisplayRegion] = useState<RegionKey>('global')
  const [fading, setFading] = useState(false)

  const [range, setRange] = useState<RangeKey>('1Y')
  const [jitter, setJitter] = useState(0)
  const [spinning, setSpinning] = useState(false)

  // Header load animation
  const [mounted, setMounted] = useState(false)
  useEffect(() => {
    const t = requestAnimationFrame(() => setMounted(true))
    return () => cancelAnimationFrame(t)
  }, [])

  const [bandRef, bandInView] = useInView<HTMLDivElement>(0.15)
  const [chartsRef, chartsInView] = useInView<HTMLDivElement>(0.15)

  const setRegion = (r: RegionKey) => {
    if (r === region) return
    setRegionState(r)
    setFading(true)
    window.setTimeout(() => {
      setDisplayRegion(r)
      setFading(false)
    }, 200)
  }

  const refresh = () => {
    setSpinning(true)
    window.setTimeout(() => setSpinning(false), 400)
    setJitter((j) => j + 1)
    toast('Feed refreshed · sample data')
  }

  const controlStagger = (i: number) => ({
    transitionDelay: `${250 + i * 80}ms`,
  })

  return (
    <div className="mx-auto max-w-[1360px] px-6 md:px-10">
      {/* Section 1 — Page header bar */}
      <div className="flex flex-wrap items-end justify-between gap-6 pb-8 pt-16">
        <div
          className={cn(
            'transition-all duration-500 ease-out',
            mounted ? 'translate-y-0 opacity-100' : 'translate-y-5 opacity-0',
          )}
        >
          <p className="font-mono text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
            <Link to="/" className="transition-colors hover:text-foreground">Home</Link>
            <span className="mx-2 text-border">/</span>
            <span className="text-foreground/70">Dashboard</span>
          </p>
          <h1 className="mt-4 font-display text-4xl font-medium leading-[1.05] tracking-[-0.015em] text-foreground md:text-[44px]">
            Command <em className="italic">Dashboard</em>
          </h1>
          <p className="mt-3 font-mono text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">
            Unified feed · Oil + Solar · Updated 09:42 UTC
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div
            className={cn(
              'transition-all duration-500 ease-out',
              mounted ? 'translate-y-0 opacity-100' : 'translate-y-3 opacity-0',
            )}
            style={controlStagger(0)}
          >
            <Select value={region} onValueChange={(v) => setRegion(v as RegionKey)}>
              <SelectTrigger className="w-[172px] border-border bg-card font-mono text-xs uppercase tracking-[0.08em]">
                <SelectValue placeholder="Region" />
              </SelectTrigger>
              <SelectContent className="border-border bg-card">
                {REGIONS.map((r) => (
                  <SelectItem key={r.key} value={r.key} className="font-mono text-xs uppercase tracking-[0.08em]">
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div
            className={cn(
              'transition-all duration-500 ease-out',
              mounted ? 'translate-y-0 opacity-100' : 'translate-y-3 opacity-0',
            )}
            style={controlStagger(1)}
          >
            <ToggleGroup
              type="single"
              value={range}
              onValueChange={(v) => v && setRange(v as RangeKey)}
              className="rounded-lg border border-border bg-card p-1"
            >
              {RANGES.map((r) => (
                <ToggleGroupItem
                  key={r.key}
                  value={r.key}
                  className="h-7 rounded-md px-3 font-mono text-[11px] font-medium tracking-[0.1em] text-muted-foreground data-[state=on]:bg-muted data-[state=on]:text-foreground"
                >
                  {r.key}
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
          </div>

          <div
            className={cn(
              'transition-all duration-500 ease-out',
              mounted ? 'translate-y-0 opacity-100' : 'translate-y-3 opacity-0',
            )}
            style={controlStagger(2)}
          >
            <button
              type="button"
              onClick={refresh}
              aria-label="Refresh feed"
              className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-card text-muted-foreground transition-colors hover:border-solar hover:text-foreground"
            >
              <RefreshCw
                className={cn('h-4 w-4', spinning && 'animate-[spin_0.4s_ease-out]')}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Region cross-fade wrapper — KPIs + charts re-filter with a 400ms fade */}
      <div
        className={cn('transition-opacity duration-200', fading ? 'opacity-0' : 'opacity-100')}
      >
        {/* Section 2 — KPI band */}
        <div ref={bandRef} className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
          {KPIS.map((def, i) => (
            <KpiCard
              key={def.id}
              def={def}
              region={displayRegion}
              jitter={jitter}
              index={i}
              bandActive={bandInView}
            />
          ))}
        </div>

        {/* Section 3 — Main chart grid */}
        <div ref={chartsRef} className="mt-8 grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <EnergyBalance region={displayRegion} range={range} jitter={jitter} active={chartsInView} />
          </div>
          <div className="lg:col-span-1">
            <StressGauge active={chartsInView} />
          </div>
        </div>
      </div>

      {/* Section 4 — Region panel + watchlist */}
      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <RegionMap region={region} onSelectRegion={setRegion} />
        </div>
        <div className="lg:col-span-2">
          <Watchlist />
        </div>
      </div>

      {/* Section 5 — Alerts feed */}
      <div className="mt-6 pb-24">
        <AlertsFeed />
      </div>
    </div>
  )
}
