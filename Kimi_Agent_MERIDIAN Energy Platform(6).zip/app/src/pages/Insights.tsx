import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import Words from '@/components/home/Words'
import Rise from '@/components/insights/Rise'
import FeaturedBriefing from '@/components/insights/FeaturedBriefing'
import BriefingGrid from '@/components/insights/BriefingGrid'
import type { BriefingFilter } from '@/components/insights/BriefingGrid'
import NewsletterBand from '@/components/insights/NewsletterBand'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { cn } from '@/lib/utils'

const FILTERS: { value: BriefingFilter; label: string }[] = [
  { value: 'all', label: 'ALL' },
  { value: 'oil', label: 'OIL' },
  { value: 'solar', label: 'SOLAR' },
  { value: 'intersection', label: 'INTERSECTION' },
  { value: 'policy', label: 'POLICY' },
]

function Hero({ filter, onFilter }: { filter: BriefingFilter; onFilter: (f: BriefingFilter) => void }) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 30)
    return () => clearTimeout(t)
  }, [])

  return (
    <section className="mx-auto max-w-[1200px] px-6 pb-12 pt-[136px] md:px-10">
      {/* Breadcrumb + eyebrow — slide-fade, 80ms stagger */}
      <Rise y={8} duration={400}>
        <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground/70">
          <Link to="/" className="transition-colors hover:text-foreground">
            Home
          </Link>
          <span className="mx-2 text-muted-foreground/40">/</span>
          <span className="text-muted-foreground">Insights</span>
        </p>
      </Rise>
      <Rise delay={80} y={8} duration={400}>
        <p className="mt-6 flex items-center gap-3 font-mono text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
          <span className="h-px w-8 bg-solar" aria-hidden />
          // INSIGHTS &amp; BRIEFINGS
        </p>
      </Rise>

      {/* H1 — word-level slide-up, 60ms stagger */}
      <h1 className="mt-4 font-display text-[42px] font-medium leading-[1.05] tracking-[-0.015em] text-foreground md:text-[56px]">
        <Words
          active={mounted}
          segments={[{ text: 'Analysis that moves' }, { text: 'before the market.', italic: true }]}
        />
      </h1>

      {/* Lede — rise 16px */}
      <Rise delay={320} y={16} duration={600}>
        <p className="mt-5 max-w-2xl text-[17px] leading-[1.6] text-muted-foreground md:text-lg">
          Briefings, reports, and featured analysis from the Meridian desks — where oil supply
          security meets the solar build-out, in writing.
        </p>
      </Rise>

      {/* Filter tabs — slide up 12px fade, 400ms delay */}
      <Rise delay={400} y={12} duration={500}>
        <Tabs
          value={filter}
          onValueChange={(v) => onFilter(v as BriefingFilter)}
          className="mt-9"
        >
          <TabsList className="h-auto flex-wrap justify-start gap-2 bg-transparent p-0">
            {FILTERS.map((f) => (
              <TabsTrigger
                key={f.value}
                value={f.value}
                className={cn(
                  'rounded-full border border-border bg-card px-4 py-2 font-mono text-xs font-medium tracking-[0.08em] text-muted-foreground',
                  'transition-colors hover:border-foreground/30 hover:text-foreground',
                  'data-[state=active]:border-foreground data-[state=active]:bg-foreground data-[state=active]:text-background data-[state=active]:shadow-none',
                )}
              >
                {f.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </Rise>
    </section>
  )
}

export default function Insights() {
  const [filter, setFilter] = useState<BriefingFilter>('all')

  return (
    <>
      <Hero filter={filter} onFilter={setFilter} />

      {/* §2 — Featured briefing */}
      <section className="mx-auto max-w-[1200px] px-6 pb-16 md:px-10">
        <FeaturedBriefing />
      </section>

      {/* §3 — Briefing grid */}
      <section className="mx-auto max-w-[1200px] px-6 pb-24 md:px-10">
        <BriefingGrid filter={filter} />
      </section>

      {/* §4 — Newsletter band */}
      <NewsletterBand />
    </>
  )
}
