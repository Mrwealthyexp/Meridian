import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import Words from '@/components/home/Words'
import Rise from '@/components/about/Rise'
import MissionSection from '@/components/about/MissionSection'
import Methodology from '@/components/about/Methodology'
import Timeline from '@/components/about/Timeline'
import Leadership from '@/components/about/Leadership'
import ContactSection from '@/components/about/ContactSection'
import { useInView } from '@/lib/animation'

function Hero() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 30)
    return () => clearTimeout(t)
  }, [])

  return (
    <section className="mx-auto max-w-[1200px] px-6 pb-16 pt-[136px] md:px-10">
      {/* Breadcrumb + eyebrow — slide-fade 400ms, stagger 80ms */}
      <Rise y={8} duration={400}>
        <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground/70">
          <Link to="/" className="transition-colors hover:text-foreground">
            Home
          </Link>
          <span className="mx-2 text-muted-foreground/40">/</span>
          <span className="text-muted-foreground">About</span>
        </p>
      </Rise>
      <Rise delay={80} y={8} duration={400}>
        <p className="mt-6 flex items-center gap-3 font-mono text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
          <span className="h-px w-8 bg-solar" aria-hidden />
          // ABOUT MERIDIAN
        </p>
      </Rise>

      {/* H1 — word-level slide-up, 60ms stagger */}
      <h1 className="mt-4 max-w-3xl font-display text-[42px] font-medium leading-[1.05] tracking-[-0.015em] text-foreground md:text-[56px]">
        <Words
          active={mounted}
          segments={[
            { text: 'Built for the era of' },
            { text: 'two energy systems.', italic: true },
          ]}
        />
      </h1>

      {/* Lede — rise 16px fade 600ms at 300ms delay */}
      <Rise delay={300} y={16} duration={600}>
        <p className="mt-5 max-w-2xl text-[17px] leading-[1.6] text-muted-foreground md:text-lg">
          Meridian Energy Intelligence was founded on a simple observation: the organizations
          that run on oil data are the same ones that now must master solar. We serve both —
          rigorously, independently, and in one place.
        </p>
      </Rise>
    </section>
  )
}

/** §7 — Closing statement: word-by-word masked slide-up at 30% viewport. */
function Closing() {
  const [ref, inView] = useInView<HTMLDivElement>(0.3)

  return (
    <section className="mx-auto max-w-[1200px] px-6 py-24 text-center md:px-10">
      <div ref={ref}>
        <p className="mx-auto max-w-3xl font-display text-2xl italic leading-[1.35] text-muted-foreground md:text-[32px]">
          <Words
            active={inView}
            stagger={70}
            segments={[{ text: '“From crude to photons — measured, modeled, and delivered.”' }]}
          />
        </p>
        <p
          className="mt-6 font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground/70"
          style={{
            opacity: inView ? 1 : 0,
            transition: 'opacity 500ms ease-out 500ms',
          }}
        >
          Meridian Energy Intelligence · Est. 2019
        </p>
      </div>
    </section>
  )
}

export default function About() {
  return (
    <>
      <Hero />
      <MissionSection />
      <Methodology />
      <Timeline />
      <Leadership />
      <ContactSection />
      <Closing />
    </>
  )
}
